<!DOCTYPE html>
<?php
require_once("../ih_html.php");
require_once("../ih_defines.php");
require_once("../ih_scripts.php");
require_once("../SensorClass.php");
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="stylesheet" type="text/css" href="/corning/style/style.css" />
<!-- link rel="stylesheet" type="text/css" href="../ih.css" / -->
<title>Corning Hyperspectral</title>
<script src="/web-files/dtjava.js"></script>
</head>
<body>
<?php displayMenu();?>
<div class="main">
   <div class="pageTitle">
      Pre-Mission Check
   </div>
    <p>
<?php
	$sensor = new Sensor( "ih", IH_PROPSERVER_FILE );

   if( !$sensor->Connect2PropertyServer( "ih", IH_PROPSERVER_FILE ) ) {
		$stMessage = $sensor->GetLastErrorMessage();
		return;
	}
	else
	{
		echo "The following properties <span class=\"error\">DO NOT</span> match the expected values:<br />";
		echo "<div class=\"containerPropDefs\">";
		echo "<span class=\"emphasis\">Property Name</span>";
		echo "<p class=\"parameters\">Expected Value<br />";
		echo "Actual Value</p>";
		echo "</div>";
	}

   $filename = "expected_sys_params";
   GetProfileSysStatus("ih", $filename);

?>
</div>
</p>
</body>
</html>
