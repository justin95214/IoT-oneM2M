<!DOCTYPE html>
<?php
require_once("../ih_html.php");
require_once("../ih_defines.php");
require_once("../SensorClass.php");
require_once("../ih_scripts.php"); 
require_once("../includes/phpPropServer.php");
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="stylesheet" type="text/css" href="/corning/style/style.css" />
<script language="JavaScript" src="../ih.js" type="text/javascript"></script>
<title>Corning Hyperspectral</title>
<script src="/web-files/dtjava.js"></script>
</head>
<body>
<?php displayMenu();?>
<div class="main">
   <div id="contents">
      <div class="pageTitle">Property Server</div>
<?php
   $ih = new Sensor( "ih", IH_PROPSERVER_FILE );
   $ih->Connect2PropertyServer( "ih", IH_PROPSERVER_FILE );
   
   if (!isset($_POST['host']))
      $host = $ih->GetPropServerHostName();
   else
      $host = $_POST['host'];
      
   if (!isset($_POST['port']))
      $port = $ih->GetPropServerPortNum();
   else
      $port = $_POST['port'];
?>

    <div id="properties">
      <form name="params" method="post" action="ih_PropertiesUpdate.php">
<?php
	// We need to make "host" and "port" hidden variables so that this information is passed when
	// the user would like to update parameters.
	echo "<input name='host' type='hidden' value=$host>";
	echo "<input name='port' type='hidden' value=$port>";   	
   	
	$propServer = new phpPropServer($host, $port);

	// Get all parameters
	$array = $propServer->GetAllProperties();
	if( $array == -1 )
	{	
      $error = "Failed to open socket to '".$host."'.  Please verify that property server is running.";
		echo "<span class=\"error\">ERROR:</span> ".$error."<br />";
		return;
	}

	$previousCategory = null;
	$index = 0;

	for($i=0; $i < $propServer->iCount; ++$i)
	{
		$description = $array[$i][0]; 
		
		if( $description == null )
         continue;

		$value = $array[$i][1];

		//	Determine the category
		$category = $propServer->GetCategoryName( $array[$i][0] );
		
		if( strcasecmp($previousCategory, $category) )
		{
			$previousCategory = $category;

$header=<<<HEADER
	<p class="PropHeader">
	$category
HEADER;
	echo $header;
	echo "</p>";
		}

		$strlen = strlen($value) + 5;
		if( $strlen < 45 ) {
		   $strlen = 45;
		} 

$parameters=<<<PARAMETERS
	<p>
		<input type="checkbox" name="parameters[]" value="$description.$index"><a href="javascript:openWindow('/corning/doc/doc_PropDefs.html#$description')">$description</a><br />
		<input type="text" name="values[]" value="$value" size="25">
	</p>
PARAMETERS;
	echo $parameters;

	  ++$index;
	}

	echo "<p class=\"PropHeader\">";
	echo "Add New Parameter";
	echo "</p>";

$empty=<<<EMPTYBOX
		<input name="parameters[]" type="checkbox" value="empty" />
		<input name="emptyDescription" type="text" size="21" />
		<br />
		<input name="emptyValue" type="text" size="25" />
EMPTYBOX;
	echo $empty;

?>
        <div class="container">
          <div align="center">
            <table>
              <tr>
              <td><input class="button" name="Update" type="submit" value="Update"></td>
              </tr>
              <tr>
              <td><input class="button" name="button" type="button" onclick="javascript:SetAllCheckBoxes('params', 'parameters[]', 1)" value="Check All"></td>
              </tr>
              <tr>
              <td><input class="button" name="button" type="button" onclick="javascript:SetAllCheckBoxes('params', 'parameters[]', 0)" value="Uncheck all"></td>
              </tr>
            </table>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>
