<!DOCTYPE html>
<?php
require_once("../ih_html.php");
require_once("../ih_scripts.php");
require_once("../SensorClass.php");
require_once("../includes/phpPropServer.php");
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="stylesheet" type="text/css" href="/corning/style/style.css" />
<title>Corning Hyperspectral</title>
<script src="/web-files/dtjava.js"></script>
</head>
<body>
<?php displayMenu();?>
<div class="main">
  <div id="contents">
    <div align="center">
     <div class="pageTitle">Sensor Updated Properties</div>
    <form name="form" method="post" action="ih_Properties.php">
<?php
   // Retrieve host name and port number.  If either the host name or port number is not provided send an
   // error message to the user.

	$host = $_POST["host"];
	$port = $_POST["port"];

	if( $host == null || $port == null )
	{
	   echo "Please go back and provide a host name and/or port number";
	   return;
	}
	
	echo "<input name='host' type='hidden' value=$host>";
	echo "<input name='port' type='hidden' value=$port>";   

	$phpPropServer = new phpPropServer($host, $port);

	// Retrieve all parameters and the corresponding values that need to be updated.
	$parameters = $_POST["parameters"];
	$values = $_POST["values"];

	// Determine the array size
	$arraySize = count($parameters);

	// Loop thru and create a two-dimensional array to store all parameter names and values.
	// Parameter names will be stored in cell $a[$i][0] and parameter values will be stored
	// in cell $a[$i][1], where $i is the cell index.
	
   // Print to table

	for( $i = 0; $i < $arraySize; ++$i )
	{
	   // Parse for the paramter name and the corresponding index number
	   $lastPeriod = strrpos($parameters[$i], ".");
	   $aParamNamesValues[$i][0] = substr( $parameters[$i], 0, $lastPeriod );
	   
	   $index = substr( $parameters[$i], $lastPeriod+1 );
	   $aParamNamesValues[$i][1] = $values[$index];
	   
	   if( $aParamNamesValues[$i][0] != null && $aParamNamesValues[$i][1] == null )
	   {
	      $paramName = $aParamNamesValues[$i][0];
	      
$deletedrow=<<<DELETEDROW
		<p class="propertyform">$paramName</p>
		<p>Deleted</p>
DELETEDROW;
	      echo $deletedrow;
	   }
	}
	
	// Check to see if the empty text fields contain information
	
	if( strstr( $parameters[$arraySize-1], "empty" ) )
	{
	   $aParamNamesValues[$arraySize][0] = $_POST["emptyDescription"];
	   $aParamNamesValues[$arraySize][1] = $_POST["emptyValue"];
	}

   // Set Value
   $aResponse = $phpPropServer->SetProperty($aParamNamesValues);

   $aCount = count( $aResponse );

   for( $i=0; $i<$aCount; ++$i )
   {
      $paramName = $aResponse[$i][0];
      $paramValue = $aResponse[$i][1];

$row=<<<ROW
		<p class="propertyform">$paramName</p>
		$paramValue
ROW;
      echo $row;
   }
?>
      <div class="container">
        <input class="button" type="submit" name="Submit" value="Return">
      </div>
      </div>
    </form>
  </div>
</div>
</body>
</html>
