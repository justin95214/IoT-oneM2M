<?php
include_once(__DIR__."/../corning/includes/phpPropServer.php");
include_once(__DIR__."/../corning/includes/phpSockets.php");
include_once(__DIR__."/../corning/viewers/event_scripts.php");
include_once("ih_defines.php");

function displayMenu()
{  
   verifyEula();
?>
<script>
function toggleChildren(id) {
   //determine the next toggle state
   var elem = document.getElementById(id);
   var nextState = "block";
   if(!elem)
      alert("error: not found!");
   else {
      if(elem.style.display == "block")
         nextState = "none";
   }

   //close open menus
   var subCatBoxElement = document.getElementsByClassName('sub_cat_box');
   for (var i = 0; i < subCatBoxElement.length; i++)
      subCatBoxElement[i].style.display = "none";

   //set the desired menu
   if (elem)
      elem.style.display = nextState;
      
}

function setStatusPage() {
   //close open menus
   var subCatBoxElement = document.getElementsByClassName('sub_cat_box');
   for (var i = 0; i < subCatBoxElement.length; i++)
      subCatBoxElement[i].style.display = "none";

   window.location.href = "/corning/status/status.html";
}
</script>


<div class="menu">
   <ul id="menu2">
      <!-- STATUS TAB -->
      <?php
      $use = getStatusValue("page.status.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      if (strcasecmp ($use, "true") == 0)
      {
      ?>
      <li class="menu">
         <a href="javascript: setStatusPage();">Status</a>
      </li>
      <?php
      }
      ?>

      <!-- CONTROL TAB -->
      <?php
      $use = getStatusValue("page.control.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      if (strcasecmp ($use, "true") == 0)
      {
      ?>
      <li class="menu">
         <a href="javascript: toggleChildren('controlBox');">Control</a>
         <div class="sub_cat_box" id="controlBox">
            <ul class="scroll">
               <li class="scroll">
                  <a href="/corning/control/control_System.html">System</a>
               </li>
               <li class="scroll">
                  <a href="/corning/control/control_Sensor.html">Sensor</a>
               </li>
            </ul>
         </div>
      </li>
      <?php
      }
      ?>

      <!-- VIEWERS TAB -->
      <?php
      $use = getStatusValue("page.viewers.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      if (strcasecmp ($use, "true") == 0)
      {
      ?>
      <li class="menuView">
         <a href="javascript: toggleChildren('viewBox');">Viewers</a>
         <div class="sub_cat_box" id="viewBox">
            <ul class="scroll">

               <?php
               $use = getStatusValue("page.viewers.display.eventViewer", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
                  $eventTracksFile = GetFilePropertyValue("C:/CorningHsi/config/parameters.xml", "eventTracksFile");
                  if ($eventTracksFile == "")
                     $eventTracksFile = "C:CorningHsi/eventConfig/EventTracks.xml";

                  if(createEventJnlp("../viewers/inputEventViewer.jnlp", $eventTracksFile, "../viewers/EventViewer2.jnlp"))
                  {
                  ?>
                  <li class="scroll">
                        <a href="../viewers/EventViewer2.jnlp">Event Viewer</a>
                  </li>
                  <?php
                  }
               }
               ?>

               <?php
               $use = getStatusValue("page.viewers.display.navigation", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
                  if(createJnlp("../viewers/inputNavigation.jnlp", "../viewers/Navigation.jnlp"))
                  {
                  ?>
                  <li class="scroll">
                     <a href="../viewers/Navigation.jnlp">Navigation</a>
                  </li>
                  <?php
                  }
               }
               ?>

               <?php
               $use = getStatusValue("page.viewers.display.swirHistogram", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
                  if(createJnlp("../viewers/inputSwirHistogram.jnlp", "../viewers/swirHistogram.jnlp"))
                  {
                  ?>
                  <li class="scroll">
                     <a href="../viewers/swirHistogram.jnlp">SWIR Histogram</a>
                  </li>
                  <?php
                  }
               }
               ?>

               <?php
               $use = getStatusValue("page.viewers.display.swirWaterfall", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
                  if(createJnlp("../viewers/inputSwirWaterfall.jnlp", "../viewers/swirWaterfall.jnlp"))
                  {
                  ?>
                  <li class="scroll">
                     <a href="../viewers/swirWaterfall.jnlp">SWIR Waterfall</a>
                  </li>
                  <?php
                  }
               }
               ?>

               <?php
               $use = getStatusValue("page.viewers.display.vnirHistogram", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
                  if(createJnlp("../viewers/inputVnirHistogram.jnlp", "../viewers/vnirHistogram.jnlp"))
                  {
                  ?>
                  <li class="scroll">
                     <a href="../viewers/vnirHistogram.jnlp">VNIR Histogram</a>
                  </li>
                  <?php
                  }
               }
               ?>

               <?php
               $use = getStatusValue("page.viewers.display.vnirWaterfall", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
                  if(createJnlp("../viewers/inputVnirWaterfall.jnlp", "../viewers/vnirWaterfall.jnlp"))
                  {
                  ?>
                  <li class="scroll">
                     <a href="../viewers/vnirWaterfall.jnlp">VNIR Waterfall</a>
                  </li>
                  <?php
                  }
               }
               ?>

               <?php
               $use = getStatusValue("page.viewers.display.log", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
                  if(createJnlp("../viewers/inputLogViewer.jnlp", "../viewers/logViewer.jnlp"))
                  {
                  ?>
                  <li class="scroll">
                     <a href="../viewers/logViewer.jnlp">Log</a>
                  </li>
                  <?php
                  }
               }
               ?>
            </ul>
         </div>
      </li>
      <?php
      }
      ?>

      <!-- ALIGN TAB -->
      <?php
      $use = getStatusValue("page.align.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      if (strcasecmp ($use, "true") == 0)
      {
      ?>
      <li class="menu">
         <a href="/corning/align/mmq_alignment.html">Align</a>
      </li>
      <?php
      }
      ?>

      <!-- UTILITY TAB -->
      <?php
      $use = getStatusValue("page.util.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      if (strcasecmp ($use, "true") == 0)
      {
      ?>
      <li class="menu">
         <a href="javascript: toggleChildren('utilBox');">Util</a>
         <div class="sub_cat_box" id="utilBox">
            <ul class="scroll">
               <li class="scroll">
                  <a href="/corning/util/gsdCalculator.html">GSD Calculator</a>
               </li>

               <!-- magnetometer cal menu item -->
               <?php
               $use = getStatusValue("page.util.magnetometerCal.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
               ?>
               <li class="scroll">
                  <a href="/corning/util/magnetometer_calibration.html">Mag Calibration</a>
               </li>
               <?php
               }
               ?>
            </ul>
         </div>
      </li>
      <?php
      }
      ?>

      <!-- CONFIG TAB -->
      <?php
      $use = getStatusValue("page.config.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      if (strcasecmp ($use, "true") == 0)
      {
      ?>
      <li class="menu">
         <a href="javascript: toggleChildren('configBox');">Config</a>
         <div class="sub_cat_box" id="configBox">
            <ul class="scroll">
               <li class="scroll">
                  <a href="/corning/config/commonConfig.html">Common</a>
               </li>
               <li class="scroll">
                  <a href="/corning/config/activeConfig.html">Active</a>
               </li>
               <li class="scroll">
                  <a href="/corning/config/cameraConfig.html">Sensor</a>
               </li>
               <!-- data selection menu item -->
               <?php
               $use = getStatusValue("page.config.dataSelector.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
               ?>
               <li class="scroll">
                  <a href="/corning/config/dataSelector.html">Data Selector</a>
               </li>
               <?php
               }
               ?>
               <!-- band selection menu item -->
               <?php
               $use = getStatusValue("page.config.bandSelector.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
               if (strcasecmp ($use, "true") == 0)
               {
               ?>
               <li class="scroll">
                  <a href="/corning/config/bandSelector.html">Band Selector</a>
               </li>
               <?php
               }
               ?>

            </ul>
         </div>
      </li>
      <?php
      }
      ?>

   </ul>
</div>
<?php
}

//	===========================================================================
function createJnlp($jnlpInputFile, $jnlpOuputFile)
//	===========================================================================
{
   $success = false;

   $isJnlpInputFile = file_exists($jnlpInputFile);
   if ($isJnlpInputFile)
   {
      $jnplInputHandle = fopen($jnlpInputFile, 'r');
      $jnplOutHandle = fopen($jnlpOuputFile, 'w');
      if ($jnplInputHandle && $jnplOutHandle)
      {
         while (($line = fgets($jnplInputHandle)) !== false)
         {
            if (strstr($line, "<!--add IP address-->"))
               addIpAddress($line, $jnplOutHandle);
            else
               fwrite($jnplOutHandle, $line);
         }
         fclose($jnplInputHandle);
         fclose($jnplOutHandle);
         $success = true;
      }
   }
   
   return $success;
}



//	===========================================================================
function createEventJnlp($jnlpInputFile, $eventTracks, $jnlpOuputFile)
//	===========================================================================
{
   $success = false;

   $isJnlpInputFile = file_exists($jnlpInputFile);
   $isEventTracks = file_exists($eventTracks);
   if ($isJnlpInputFile && $isEventTracks)
   {
      $jnplInputHandle = fopen($jnlpInputFile, 'r');
      $jnplOutHandle = fopen($jnlpOuputFile, 'w');
      if ($jnplInputHandle && $jnplOutHandle)
      {
         while (($line = fgets($jnplInputHandle)) !== false)
         {
            if (strstr($line, "<!--add IP address-->"))
               addIpAddress($line, $jnplOutHandle);
            else if (strstr($line, "<!--parseEventsFileToJnlp-->"))
               parseEventsFileToJnlp($eventTracks, $jnplOutHandle);
            else
               fwrite($jnplOutHandle, $line);
         }
         fclose($jnplInputHandle);
         fclose($jnplOutHandle);
         $success = true;
      }
   }
   
   return $success;
}

//	===========================================================================
function GetExecutorResponse($socketObj)
//	===========================================================================
{
        $message = '';
	while(true)
	{
	  $message = $message.$socketObj->ReadMessage();
	  
	  if( strpos($message, "</exec>") != 0 ){
	     break;
	  }
	  else {
	     continue;
	  }
	}

	if(ParseXML($message, "<result>", "</result>") != 0){
		return false;
	}
	else {
	   return true;
	}
}

//	===========================================================================
function getField($xmlData, $fieldName)
//	===========================================================================
{
   $value = "";
   $i = stripos($xmlData, "<$fieldName>");
   if ($i !== false)
   {
      $i += (strlen($fieldName) + 2);
      $j = stripos($xmlData, "</$fieldName>");
      if (($j !== false) && ($j > $i))
      {
         $value = substr($xmlData, $i, $j-$i);
      }
   }
   return $value;
}

/*
function getStatusValue($xmlKey, $filename)
{
   $start = 0;
   $end = 0;
   $key;
   $cnt = 0;
   $config = "";

}
*/

//	===========================================================================
// function $xmlValue getStatusField($xmlKey, $fieldName)
//	===========================================================================
function getStatusValue($xmlKey, $filename)
{
   $start = 0;
   $end = 0;
   $key;
   $cnt = 0;
   $config = "";
   
   //parse the xml key
   do{
      $end = strpos($xmlKey, ".", $start);

      if ($end)
         $key[$cnt] = substr($xmlKey, $start, $end - $start);
      else
         $key[$cnt] = substr($xmlKey, $start);
      
      $start = $end + 1;   
      $cnt += 1;
   }while ($end);   
   
   //parse the value from the file
   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $config = fread($handle, 20000);
      $x = 0;
      while ($x < $cnt)
      {
         $config = getField($config, $key[$x]);
         $x++;
      }
   }
   
   fclose($handle);
   return $config;
}


//	===========================================================================
function GetFilePropertyValue($filename, $stPropertyName)
//	===========================================================================
{
   $stParameterName = null;
   $stParameterValue = null;
     
   $mode = 'r';
   $length = 4096;

   if(!file_exists($filename)) {
		return false;
	}


	@ $fp = fopen($filename, $mode);

	if(!$fp) {
		return false;
	}

	//  If the file was found and successfully opened, begin parsing through file.
	while(!feof( $fp ))
	{
		$stBuffer = fgets($fp, $length);

		//	Explode the buffer into an array
		//$aTempArray = explode(" ", $stBuffer);

		//	Determine if the $buffer contains a property
		//if(strstr($aTempArray[0], "<property") != false)
		if(strstr($stBuffer, "<property") != false)
		{
			// Parse through property and determine what the expected value is.
			ParseProperty($stBuffer, $stParameterValue, $stParameterName);

			if(strcmp($stPropertyName, $stParameterName) == 0) 
			{
			   if( $stParameterValue == null ) {
			      $stParameterValue = "None";
			   }

			   fclose($fp);
			   return $stParameterValue;
			}
      }
   }

   fclose($fp);
   return false;
}

//	===========================================================================
function GetProperty($sensor, $propertyname)
//	===========================================================================
{
	switch($sensor)
	{
		case "ih":
			$propserverIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.ip");
			$propserverPort = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.port");
			break;
   }
	
   $propServer = new phpPropServer($propserverIP, $propserverPort);
   
   if( $propServer->Connect2PropServer() == -1 ) {
      return -1;
   }
   
   return $propServer->GetProperty($propertyname);
}

//	===========================================================================
function GetProfile($system, $profile)
//	===========================================================================
{
	// Determine whether we are requesting the name of the active profile or
	//	all profiles 
	switch($profile)
	{
		case "active":
			$msg = "<?xml version=\"1.0\" ?><get/>";
			break;
		case "all":
			$msg = "<?xml version=\"1.0\" ?><get name=\"*\"/>";
			break;
		default:
	}
	
	//	Determine which sensor the message is being sent to
	switch($system)
	{
		case "hsi":
			$execIP = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.exec.ip");
			$execPort = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.exec.port");
			break;
		case "pan":
			$execIP = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.exec.ip");
			$execPort = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.exec.port");
			break;
		case "ih":
			$execIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.exec.ip");
			$execPort = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.exec.port");
			break;
	}
   
	//	Open socket to executor and send message
	$executor = new phpSockets($execIP, $execPort);
			
	if($executor->OpenSocket(2) == -1) {
		return "<span class=\"error\">ERROR</span>: Failed to open socket to the executor on the ".$system." computer on ".$execIP.":".$execPort;
	}

   $executor->SendMessage($msg);
	
	// Parse message
	$profileCount = 0;
	$profiles = null;
	$value = null;
	
	while(true)
	{
	  $returnMsg = $executor->ReceiveMessage();
	  
	  if( strcmp("</get>", $returnMsg) == -2 )
	     break;

     if(strstr($returnMsg, "<profile") != false)
     {
        //	Parse property.
		  ParseProperty($returnMsg, $profiles[$profileCount], $value);
		  ++$profileCount;
	  }
	}
	
	if ($profile == "all")
	{
      $orderedProfiles = null;
	   OrderProfiles($profiles, $orderedProfiles, $profileCount);
	   return $orderedProfiles;
	}
	
	return $profiles;
}

//	===========================================================================
function GetProfileSysStatus($sensor, $filename)
//	===========================================================================
{  
   // Send message to executor
   
   switch ($sensor)
   {
      case "hsi":
         $propIP = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.propserver.ip");
         $propPort = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.propserver.port");
         break;
      case "pan":
         $propIP = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.propserver.ip");
         $propPort = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.propserver.port");
         break;
      case "ih":
         $propIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.ip");
         $propPort = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.port");
         break;
   }

   $prop = new phpPropServer($propIP, $propPort);
   
   $returnArray = $prop->Compare($filename);
   
	if(is_string($returnArray) && strpos($returnArray, "Unable to compare") > 0 ){
      echo "<span class=\"error\">Unable to compare \"".$filename.".xml\". Please check to make sure that file exists.</span>";
      return;
   }
   
   $iCount = count($returnArray);
   
   for( $i=0; $i < $iCount; ++$i )
   {
      $parameterName = $returnArray[$i][0];
      
      if( $returnArray[$i][1] == null ){
         $actual = "No value or no such property";
      }
      else{
         $actual = $returnArray[$i][1];
      }
  
      $expected = $returnArray[$i][2];
 
$print=<<<PRINT
	<div class="containerPropDefs">
   <span class="emphasis"><a href="javascript:openWindow('../doc/doc_PropDefs.html#$parameterName')">$parameterName</a></span>
 	<p class="parameters">$expected<br />
	$actual</p>
	</div>
PRINT;
   echo $print;
   }
}

//	===========================================================================
function IsPropServerRunning($sensor)
//	===========================================================================
{
   switch($sensor)
   {
      case "ih":
         $propserverIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.ip");
         $propserverPort = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.port");
         break;
   }
   
   $propServer = new phpPropServer($propserverIP, $propserverPort);
   
   if( $propServer->Connect2PropServer() == -1 ) {
      return false;
   }
   else {
      $propServer->DisconnectFromPropServer();
      return true;
   } 
}

//	===========================================================================
function IsSystemReady($sensor, $filename)
//	===========================================================================
{
   // Send message to executor
   
   switch ($sensor)
   {
      case "hsi":
         $propIP = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.propserver.ip");
         $propPort = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.propserver.port");
         break;
      case "pan":
         $propIP = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.propserver.ip");
         $propPort = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.propserver.port");
         break;
      case "ih":
         $propIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.ip");
         $propPort = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.port");
         break;
   }

   $prop = new phpPropServer($propIP, $propPort);
   
   $returnArray = $prop->Compare($filename);
   
	if( is_string($returnArray) && strpos($returnArray, "Unable to compare") > 0 ){
      return false;
   }

   if( count($returnArray) > 0 ){
      return false;
   }
   else{
      return true;
   }
}
//	===========================================================================
function OrderProfiles($tempProfiles, &$profiles, $count)
//	===========================================================================
{
   //order profiles by exposure time
   $loaded = null;         //array to list the indexes of the loaded profiles
   $loadedIndex = 0;
   $nonMsProfile = null;
   $nonMsIndex = 0;
   $res = 0;
   $profIndex = 0; 
   
   for ($x = 0; $x < $count; $x++)
   {
      //find the smallest exposure in the profiles
      $idx = -1;
      $smallest = 10000000;
      
      for ($y = 0; $y < $count; $y++)
      {
         //find ms for milliseconds
         $endPos = strpos($tempProfiles[$y], "ms");
         if ($endPos != false)
         {
            $startPos = $endPos - 1;
            $val = 0;
            while (true)
            {
               $val = substr($tempProfiles[$y], $startPos, 1);
               if (($val >= '0' && $val <= '9') || $val == '.')
               {
                  $startPos--;
               }
               else
               {
                  $startPos++;
                  break;
               }
            }
            //convert to microseconds
            $res = floatval(substr($tempProfiles[$y], $startPos, $endPos - $startPos));
            $res = (int)($res*1000);
            
            //find the smallest value not yet loaded
            if ($res < $smallest)
            {
               $found = false;
               for ($i = 0; $i < $loadedIndex; $i++)
               {
                  if ($loaded[$i] == $y)
                  {
                     $found = true;
                     break;                  
                  }
               }
               if ($found == false)
               {
                  $smallest = $res;
                  $idx = $y;
               }
            }
         }
         //could not find so add to temp non-timed list
         //only need to do this once
         else if ($x == 0) 
         {
            $nonMsProfile[$nonMsIndex] = $tempProfiles[$y];
            $nonMsIndex++;
         }
      }
      
      //if we found a value, load it
      if ($idx >= 0)
      {
         $loaded[$loadedIndex] = $idx;
         $loadedIndex++;
         $profiles[$profIndex] = $tempProfiles[$idx];
         $profIndex++;
      }
   }
   
   //add any profiles without exposure times
   for ($x = 0; $x < $nonMsIndex; $x++)
   {
      $profiles[$profIndex] = $nonMsProfile[$x];
      $profIndex++;
   }
}

//	===========================================================================
function ParseXML( $xmlMsg, $startTag, $endTag )
//	===========================================================================
{
	//	Find the "result" tag and readjust the start and end position so that we can retrieve 
	//	the "result" value.
	
	$start = strpos($xmlMsg, $startTag);
	$end = strpos ($xmlMsg, $endTag, $start);
	$start = $start + strlen($startTag);
	$length = ($end - $start);
   $value = substr($xmlMsg, $start, $length);
	return $value;
}

//	===========================================================================
function ParseProperty($stBuffer, &$stParameterValue, &$stParameterName)
//	===========================================================================
{
	//	Find the "name" tag and readjust the start and end position so that we can retrieve 
	//	the "name" description and store it in the array.
	
	$start = strpos($stBuffer, "name=\"");
	$end = strpos ($stBuffer, '=');
	
	$start = $end + 1;
	$end = strpos($stBuffer, '"', $start + 1);
	$length = ($end - $start);
	
	$stParameterName = substr($stBuffer, $start + 1, $length - 1);
	
	//	Find the "value" tag and readjust the start and end position so that we can retrieve 
	//	the "value" description and store it in the array.
	
	$start = strpos($stBuffer, "value=\"", $end + 1);
	$end = strpos($stBuffer, '=', $start);
	
	$start = $end + 1;
	$end = strpos($stBuffer, '"', $start + 1);
	$length = ($end - $start);
	
	$stParameterValue = substr($stBuffer, $start + 1, $length - 1);
}

//	===========================================================================
function PowerSystemOff($sensor = null)
//	===========================================================================
{
	switch($sensor)
	{
		case "d1":
			$message = StopPAN(false);
			$message = "<br />".$message."<br />".StopHSI();
			break;
		case "ih":
			$message = StopIH(false);
			break;
	}
	return $message;
}

//	===========================================================================
function PowerSystemOn($sensor=null)
//	===========================================================================
{
	switch($sensor)
	{
		case "d1":
			$message = StartHSI();
			$message = "<br />".$message."<br />".StartPAN();
			break;
		case "ih":
			$message = StartIH();
			break;
	}
	
	return $message;
}

//	===========================================================================
function PrintForm($filename)
//	===========================================================================
{
   $name = null;
   $value = null;
     
   $mode = 'r';
   $length = 4096;

	@ $fp = fopen($filename, $mode);

	
	//  If the file was found and successfully opened, begin parsing through file.
	while(!feof( $fp ))
	{
		$stBuffer = fgets($fp, $length);

		//	Explode the buffer into an array
		$aTempArray = explode(" ", $stBuffer);

		//	Determine if the $buffer contains a property
		if(strstr($aTempArray[0], "<property") != false)
		{
			// Parse through property and determine what the expected value is.
			ParseProperty($stBuffer, $value, $name);

			if(strcmp($name, "configured") == 0) {
			   continue;
			}
			else {
$parameters=<<<PARAMETERS
            <p>
            $name
            <input name="parameters[]" type="hidden" value="$name" />
            <br />
            <input type="text" name="values[]" value="$value" />
            </p>
PARAMETERS;
      		echo $parameters;
			}
      }
   }
   fclose($fp);
}

//	===========================================================================
function SetProperty($sensor, $propertyname)
//	===========================================================================
{
	switch($sensor)
	{
		case "hsi":
			$propserverIP = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.propserver.ip");
			$propserverPORT = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.propserver.port");
			break;
		case "pan":
			$propserverIP = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.propserver.ip");
			$propserverPORT = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.propserver.port");
			break;
		case "ih":
			$propserverIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.ip");
			$propserverPORT = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.propserver.port");
			break;
   }

   $propServer = new phpPropServer($propserverIP, $propserverPORT);
   
   if( $propServer->Connect2PropServer() == -1 ) {
      return -1;
   }
   
   return $propServer->SetProperty($propertyname);
}

//	===========================================================================
function SetProfile($system, $profile)
//	===========================================================================
{
	// Form message
	$msg = null;
	$msg = "<?xml version=\"1.0\" ?><set name=\"".$profile."\"/>";

	//	Determine which sensor the message is being sent to
	switch($system)
	{
		case "hsi":
			$execIP = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.exec.ip");
			$execPort = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.exec.port");
			break;
		case "pan":
			$execIP = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.exec.ip");
			$execPort = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.exec.port");
			break;
		case "ih":
			$execIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.exec.ip");
			$execPort = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.exec.port");
			break;
	}
	
	//	Open socket to executor and send message
	$executor = new phpSockets($execIP, $execPort);

	if($executor->OpenSocket(2) == -1) {
		return "<span class=\"error\">ERROR</span>: Failed to open socket to the executor on the ".$system." computer on ".$execIP.":".$execPort;
	}
	
	$executor->SendMessage($msg);
	
	// Parse message
	$profileCount = 0;
	$profiles = null;
	$profiles = null;
	$value = null;
	
	while(true)
	{
	  $returnMsg = $executor->ReceiveMessage();

      
	  
	  if( strcmp("</set>", $returnMsg) == -2 )
	     break;

     if(strstr($returnMsg, "<profile") != false)
     {
        //	Parse property.
		  ParseProperty($returnMsg, $profiles[$profileCount], $value);
		  ++$profileCount;
	  }
	}
	
	return $profiles;
}

//	===========================================================================
function StartIH()
//	===========================================================================
{
   // Make sure that we only have one version of the Iron Horse sensor software running
   // by killing everything first
   StopIH();
   
   // Power off HSI	
   $IHcompIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.exec.ip");
   $IHcompPort = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.exec.port");

   $ihExec = new phpSockets($IHcompIP, $IHcompPort);
   
   if($ihExec->OpenSocket(3) == -1) {
      return "<span class=\"error\">ERROR</span>: Failed to open socket to computer on ".$IHcompIP.":".$IHcompPort;
   }

	//	Start HSI pipeline
	$ihExec->SendMessage(IH_START);
   sleep(2);


	if( !GetExecutorResponse($ihExec) ) {
           $ihExec->CloseSocket(); 
	   return "Failed to start sensor software";
	}

	$ihExec->CloseSocket();
	
	return "Sensor software started.";
}

//	===========================================================================
function StartHSI()
//	===========================================================================
{
   // Make sure that we only have one version of the HSI sensor software running
   // by killing everything first
   StopHSI();
   
   // Power off HSI	
   $HSIcompIP = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.exec.ip");
   $HSIcompPort = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.exec.port");

   $hsiExec = new phpSockets($HSIcompIP, $HSIcompPort);
   
   if($hsiExec->OpenSocket(3) == -1) {
      return "<span class=\"error\">ERROR</span>: Failed to open socket to HSI computer on ".$HSIcompIP.":".$HSIcompPort;
   }

	//	Start HSI support
/*	$hsiExec->SendMessage(HSI_SUPPORT_START);
	sleep(2);
	if( !GetExecutorResponse($hsiExec) ){
	   return "Failed to start HSI support software";
	}
*/	
	//	Start HSI pipeline
	$hsiExec->SendMessage(HSI_START);
   sleep(2);
	if( !GetExecutorResponse($hsiExec) ) {
	   return "Failed to start HSI sensor software";
	}

	$hsiExec->CloseSocket();
	
	return "HSI sensor software started.";
}

//	===========================================================================
function StartPAN()
//	===========================================================================
{
   // Make sure that we only have one version of the PAN sensor software running
   // by killing everything first
   StopPAN(true);
	
	//	Power off PAN
   $PANcompIP = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.exec.ip");
   $PANcompPort = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.exec.port");

   $panExec = new phpSockets($PANcompIP, $PANcompPort);
   
   if($panExec->OpenSocket(3) == -1) {
      return "<span class=\"error\">ERROR</span>: Failed to open socket to PAN computer on ".$PANcompIP.":".$PANcompPort;
   }

	//	Start PAN support
/*	$panExec->SendMessage(PAN_SUPPORT_START);
   sleep(2);
	if( !GetExecutorResponse($panExec) ){
	   return "Failed to start PAN support software";  
	}
*/	
	$panExec->SendMessage(PAN_START);
   sleep(2);
	if( !GetExecutorResponse($panExec) ) {
	   return "Failed to start PAN sensor software";
	}

	$panExec->CloseSocket();
	
	return "PAN sensor software started.";  
}

//	===========================================================================
function StopIH()
//	===========================================================================
{
  
	// Power off HSI
   $IHcompIP = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.exec.ip");
   $IHcompPort = GetFilePropertyValue(IH_PROPSERVER_FILE, "ih.exec.port");

   $ihExec = new phpSockets($IHcompIP, $IHcompPort);
   
   if($ihExec->OpenSocket(3) == -1) {
      return "<span class=\"error\">ERROR</span>: Failed to open socket to computer on ".$IHcompIP.":".$IHcompPort;
   }

	//	Kill HSI pipeline
	$ihExec->SendMessage(IH_KILL);
   sleep(2);
	if( !GetExecutorResponse($ihExec) ) {
	   return "Failed to kill sensor software";
	}
	
	$ihExec->CloseSocket();
	
	return "Sensor software killed.";
}

//	===========================================================================
function StopHSI()
//	===========================================================================
{
	// Power off HSI
   $HSIcompIP = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.exec.ip");
   $HSIcompPort = GetFilePropertyValue(HSI_PROPSERVER_FILE, "hsi.exec.port");

   $hsiExec = new phpSockets($HSIcompIP, $HSIcompPort);
   
   if($hsiExec->OpenSocket(3) == -1) {
      return "<span class=\"error\">ERROR</span>: Failed to open socket to HSI computer on ".$HSIcompIP.":".$HSIcompPort;
   }

	//	Kill HSI pipeline
	$hsiExec->SendMessage(HSI_KILL);
   sleep(2);
	if( !GetExecutorResponse($hsiExec) ) {
	   return "Failed to kill HSI sensor software";
	}
	
	//	Kill HSI support
/*	$hsiExec->SendMessage(HSI_SUPPORT_KILL);
   sleep(2);
	if( !GetExecutorResponse($hsiExec) ){
	   return "HSI pipeline killed.\nFailed to kill HSI support";
	}
*/	
	$hsiExec->CloseSocket();
	
	return "HSI sensor software killed.";
}

//	===========================================================================
function StopPAN($wait)
//	===========================================================================
{
	//	Power off PAN
   $PANcompIP = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.exec.ip");
   $PANcompPort = GetFilePropertyValue(PAN_PROPSERVER_FILE, "pan.exec.port");

   $panExec = new phpSockets($PANcompIP, $PANcompPort);

   if($panExec->OpenSocket(3) == -1) {
      return "<span class=\"error\">ERROR</span>: Failed to open socket to PAN computer on ".$PANcompIP.":".$PANcompPort;
     }

     //	Kill PAN pipeline
     if( $wait ){
     $panExec->SendMessage(PAN_KILL);
     sleep(2);
     if( !GetExecutorResponse($panExec) ) {
     return "Failed to kill PAN sensor software";
     }
     }
     else{
     $panExec->SendMessage(PAN_KILL_NOWAIT);
     }
     //	Kill PAN support
     /*	$panExec->SendMessage(PAN_SUPPORT_KILL);
     sleep(2);
     if( !GetExecutorResponse($panExec) ){
     return "PAN pipeline killed.\nFailed to kill PAN support";
     }
     */
     $panExec->CloseSocket();

     return "PAN sensor software killed.";
     }

function getEulaState()
{
   $filePath = "C:/CorningHsi/htdocs/corning/eula/status.txt";
   $handle = fopen($filePath, "r");
   $fileContents = fread($handle, filesize($filePath));
   fclose($handle);

   $status = "Declined";
   if (strpos($fileContents, "New") === 0)
     $status = "New"; 
   if (strpos($fileContents, "Accepted") === 0)
     $status = "Accepted"; 

   return $status;
}

function verifyEula()
{
   $status = getEulaState();   
   if ($status == "New")
   {
      header("Location: /corning/eula/eula.html");
      exit();
   }
   else if($status != "Accepted")
   {
      echo "EULA PREVIOUSLY DECLINED<br>";
      exit();
   }
}
?>