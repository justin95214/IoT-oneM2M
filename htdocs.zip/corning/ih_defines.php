<?php
//	=========================== FILE NAMES ===========================
//	=========================== FILE NAMES ===========================
define( "PROPSERVER_FILE", "../web_parameters.xml", false );
define( "IH_PROPSERVER_FILE", PROPSERVER_FILE, false );


//	=========================== PROPERTY NAMES ===========================
//	=========================== PROPERTY NAMES ===========================
define( "CONTROL_IP", "ih.control.ip", false );
define( "CONTROL_PORT", "ih.control.port", false );


//	=========================== XML MESSAGE FORMATS ===========================
//	=========================== XML MESSAGE FORMATS ===========================
define( "IH_START", "<?xml version=\"1.0\" ?><exec command=\"startup\" mode=\"wait\"/>", false );
define( "IH_KILL", "<?xml version=\"1.0\" ?><exec command=\"shutdown\" mode=\"wait\"/>", false );
define( "IH_KILL_NOWAIT", "<?xml version=\"1.0\" ?><exec command=\"shutdown\" />", false );

//	=========================== MENU TABS ===========================
//	=========================== MENU TABS ===========================
define ( "TAB1", "Status", true );
define ( "TAB2", "Control", true );
define ( "TAB3", "Viewer2", true );
define ( "TAB4", "Alignment", true );
define ( "TAB5", "Config", true );
?>