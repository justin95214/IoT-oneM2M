<?php
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/../ih_scripts.php");
include_once(__DIR__."/../ih_defines.php");
include_once("config_scripts.php");

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetXmlValue($profile, $fileName, $key, $value)
//	===========================================================================
{
   $returnValue = 1;
   $path = getenv("PROFILE_HOME");
   if (!$path)
      $returnValue = -3;

   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);
   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 4000);
      fclose($handle);
   
      //find the frame rate
      $key = "\"$key\"";
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\"", $startInt);
         $buf3 = substr($message, $endInt);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

	return $returnValue;
}

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to all key value pairs within the file.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to view.
*  @param $key    - this is an array of keys to be ouput by this function.
*  @param $value  - this is an array of values to be ouput by this function.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function GetAllXmlValues($fileName)
//	===========================================================================
{
   $path = getenv("PROFILE_HOME");
   $profile = GetProfile("ih", "active");

   if (!$path)
      return "error -3";
      
   $filename = sprintf("%s\\%s\\%s", $path, $profile[0], $fileName);
   
   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 4000);
     
      $startInt = strpos($message, "<property name"); 
      $count = 0;   
     
      while($startInt != false)
      {
         //parse the key
         $startInt = strpos($message, "name=", $startInt);
         $startInt = $startInt + 6;
         $endInt = strpos($message, "\"", $startInt);
         $len = $endInt - $startInt;
         $keyValue[$count][0] = substr($message, $startInt, $len); 
        
         //parse the key
         $startInt = strpos($message, "value=", $startInt);
         $startInt = $startInt+7;  
         $endInt = strpos($message, "\"", $startInt);
         $len = $endInt - $startInt;
         $keyValue[$count][1] = substr($message, $startInt, $len);
         $count++;
        
		   if (strpos($message, "<property name", $startInt) == false)
		      break;  
	   }
   } 
   else
      return -1;
        
   fclose($handle);

	return $keyValue;
}

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $properties - this is an array of the key value pairs to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetXmlValues($fileName, $property, $count)
//	===========================================================================
{
   $returnValue = 1;
   $path = getenv("PROFILE_HOME");
   if (!$path)
      $returnValue = -3;
      
    $profile = GetProfile("ih", "active");
  
   $filename = sprintf("%s\\%s\\%s", $path, $profile[0], $fileName);
   $handle = fopen($filename, 'r');
   
   if ($handle)
   {
      $newFile = '';
      $message = fread($handle, 4000);
      fclose($handle);
   
      //find the frame rate
      for ($x = 0; $x < $count; $x++)
      {
         $startInt = strpos($message, $property[$x][0]);
         if ($startInt)
         {
            $startInt = strpos($message, 'value=', $startInt);
            $startInt = $startInt + 7;
            $buf1 = substr($message, 0, $startInt);
            $buf2 = $property[$x][1];
            $endInt = strpos($message, "\"", $startInt);
            $buf3 = substr($message, $endInt);
            
            $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
            $message = $newFile;
         }
      }
      
      $handle = fopen($filename, 'w');
      if ($handle)
      {
         fwrite($handle, $newFile);
         fclose($handle);
      }
      else
         $returnValue = -4;
   }
   else
      $returnValue = -1;

	return $returnValue;
}
