<?php
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/../ih_defines.php");
include_once("cameraConfig_vars.php");
include_once("config_scripts.php");

/*	===========================================================================
*  This method opens an PCF file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to view.
*  @param $key - this is the key used to search for the value.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function GetPcfValue($profile, $fileName, $key)
//	===========================================================================
{
   $path = getenv("PROFILE_HOME");
   if (!$path)
      return -3;
      
   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);
   
   $key = $key.",";

   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = $startInt + strlen($key);
         
         $endInt = strpos($message, "\n", $startInt);
         $len = $endInt - $startInt;
         $value = substr($message, $startInt, $len);
         trim($value);
      }
      else
         $value = -2;
   }
   else
      $value = -1;
   
   fclose($handle);

	return $value;
}

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetXmlValue($profile, $fileName, $key, $value)
//	===========================================================================
{
   $key = "\"$key\"";
   $returnValue = 1;
   $path = getenv("PROFILE_HOME");
   if (!$path)
      $returnValue = -3;

   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);
   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);
   
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\"", $startInt);
         $buf3 = substr($message, $endInt);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

	return $returnValue;
}

/*	===========================================================================
*  This method opens an PCF file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetPcfValue($profile, $fileName, $key, $value)
//	===========================================================================
{
   $returnValue = 1;
   $path = getenv("PROFILE_HOME");
   if (!$path)
      $returnValue = -3;
      
   $key = $key.",";   

   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);
   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);
   
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = $startInt + strlen($key);
         while ($message[$startInt] == ' ')
            $startInt++;   

         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\n", $startInt);
         $buf3 = substr($message, $endInt-1);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

	return $returnValue;
}

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current subkey within a module or service (type)
*  with the given name.  It then replaces the value for this key with $value.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to view.
*  @param $type - type of module 'service' or 'module'.
*  @param $name - name of 'service' or 'module'.
*  @param $subkey - this is the item to return.
*  @param $value - this is the itme to return.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function SetXmlValue4($profile, $fileName, $type, $subkey, $value)
//	===========================================================================
{
   $path = getenv("PROFILE_HOME");
   $returnValue = -2;
   if (!$path)
      return -3;
      
   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);

   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);

      //find start of service or module
      $typeTag = sprintf("<%s", $type);
      $startIndex = strpos($message, $typeTag);
      $count = 0;
      while($count < 35 && $startIndex > 0)
      {
         //find end of service or module
         $endIndex = strpos($message, ">", $startIndex);
         $slash = strpos($message, "/", $startIndex);
         if (($slash + 1) != $endIndex)
         {
            //check name of service or module
            $endTag = sprintf("</%s", $type);
            $endIndex  = strpos($message, $endTag, $startIndex);

            //get the desired value
            $sub = sprintf("<%s>", $subkey);
            $subkeyPos = strpos($message, $sub, $startIndex);
            if ($subkeyPos > 0 && $subkeyPos < $endIndex)
            {
               $returnValue = 0;
               $startVal = strpos($message, ">", $subkeyPos) + 1;
               $buf1 = substr($message, 0, $startVal);
               $endVal = strpos($message, "<", $subkeyPos + 1);
               $buf2 = substr($message, $endVal);
               $handle = fopen($filename, 'w');
               $newFile = sprintf("%s%s%s", $buf1, $value, $buf2);
               if ($handle)
               {
                  fwrite($handle, $newFile);
                  fclose($handle);

                  //reload the message buffer
                  $message = $newFile;
               }
               else
               {
                  $returnValue = -4;
                  break;
               }
            }
         }
         $count++;
         $startIndex = strpos($message, $typeTag, $endIndex);     
      }
   }
   else
      $returnValue = -1;
  
	return $returnValue;
}

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current subkey within a module or service (type)
*  with the given name.  It then replaces the value for this key with $value.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to view.
*  @param $type - type of module 'service' or 'module'.
*  @param $name - name of 'service' or 'module'.
*  @param $subkey - this is the item to set.
*  @param $value - this is the value to set item to.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function SetXmlValue3($profile, $fileName, $type, $name, $subkey, $value)
//	===========================================================================
{
   $path = getenv("PROFILE_HOME");
   $returnValue = -2;
   if (!$path)
      return -3;
      
   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);

   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);

      //find start of service or module
      $typeTag = sprintf("<%s", $type);
      $startIndex = strpos($message, $typeTag);
      $count = 0;
      while($count < 35 && $startIndex > 0)
      {
         //find end of service or module
         $endIndex = strpos($message, ">", $startIndex);
         $slash = strpos($message, "/", $startIndex);
         if (($slash + 1) != $endIndex)
         {
            //check name of service or module
            $endTag = sprintf("</%s", $type);
            $endIndex  = strpos($message, $endTag, $startIndex);

            $found = false;
            $nameSub = sprintf("name=\"%s\"", $name);
            $namePos = strpos($message, $nameSub, $startIndex);
            if ($namePos > 0 && $namePos < $endIndex)
               $found = true;
            
            $nameSub = sprintf("<%s>", $name);
            $namePos = strpos($message, $nameSub, $startIndex);
            if ($namePos > 0 && $namePos < $endIndex)
               $found = true;

            if ($found)
            {
               //get the desired value
               $sub = sprintf("<%s>", $subkey);
               $subkeyPos = strpos($message, $sub, $startIndex);
               if ($subkeyPos > 0 && $subkeyPos < $endIndex)
               {
                  $returnValue = 0;
                  $startVal = strpos($message, ">", $subkeyPos) + 1;
                  $buf1 = substr($message, 0, $startVal);
                  $endVal = strpos($message, "<", $subkeyPos + 1);
                  $buf2 = substr($message, $endVal);
                  $handle = fopen($filename, 'w');
                  $newFile = sprintf("%s%s%s", $buf1, $value, $buf2);
                  if ($handle)
                  {
                     fwrite($handle, $newFile);
                     fclose($handle);

                     //reload the message buffer
                     $message = $newFile;
                  }
                  else
                  {
                     $returnValue = -4;
                     break;
                  }
               }
            }
         }
         $count++;
         $startIndex = strpos($message, $typeTag, $endIndex);     
      }
   }
   else
      $returnValue = -1;
  
	return $returnValue;
}

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current subkey within a module or service (type)
*  with the given name.  It then replaces the value for this key with $value.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to view.
*  @param $type - type of module 'service' or 'module'.
*  @param $name - name of 'service' or 'module'.
*  @param $subkey - this is the item to return.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function GetXmlValue2($profile, $fileName, $type, $subkey)
//	===========================================================================
{
   $path = getenv("PROFILE_HOME");
   $returnValue = -2;
   if (!$path)
      return -3;
      
   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);
   if (file_exists($filename))
   {
      $handle = fopen($filename, 'r');
      if ($handle)
      {
         $message = fread($handle, 20000);
         fclose($handle);

         //find start of service or module
         $typeTag = sprintf("<%s", $type);
         $startIndex = strpos($message, $typeTag);
         $count = 0;
         while($count < 35 && $startIndex > 0)
         {
            //find end of service or module
            $endIndex = strpos($message, ">", $startIndex);
            $slash = strpos($message, "/", $startIndex);
            if (($slash + 1) != $endIndex)
            {
               //check name of service or module
               $endTag = sprintf("</%s", $type);
               $endIndex  = strpos($message, $endTag, $startIndex);

               //get the desired value
               $sub = sprintf("<%s>", $subkey);
               $subkeyPos = strpos($message, $sub, $startIndex);
               if ($subkeyPos > 0 && $subkeyPos < $endIndex)
               {
                  $startVal = strpos($message, ">", $subkeyPos) + 1;
                  $endVal = strpos($message, "<", $startVal);
                  $returnValue = substr($message, $startVal, $endVal-$startVal);
                  break;
               }
            }
            $count++;
            $startIndex = strpos($message, $typeTag, $endIndex);     
         }
      }
   }
   else
      $returnValue = -1;
  
	return $returnValue;
}

/*	===========================================================================
*  This method opens the vnir_config.xml configuration file within the given profile. 
*  It then reads the file to find current VNIR frame rate and returns it.
*  @param $profile - this is the name of the profile to view.
*  @return - the VNIR frame rate in HZ.
*/
function GetVnirRate($profile)
//	===========================================================================
{
   $value = 0;
   
   $use = getStatusValue("page.config.vnir.rate", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   if (stristr($use, "alliedVision"))
      $value = GetXmlValue($profile, 'vnir_config.xml', 'FrameRate');
   else if (stristr($use, "pointGrey"))
      $value = GetXmlValue($profile, 'vnir_config.xml', 'FrameRate');
   else if (stristr($use, "ximea"))
   {
      $allow = GetXmlValue($profile, "parameters.xml", "vnir.framerate.set");
      if ($allow === "true")
         $value = GetXmlValue($profile, "parameters.xml", "vnir.framerate");
      else 
         $value = false;

   }
   return $value;
}

/*	===========================================================================
*  This method returns the maximum vnir rate based on the specific camera.
*  @param $profile - this is the name of the profile to view.
*  @return - the maximum VNIR frame rate in HZ.
*/
function GetMaxVnirRate($profile)
//	===========================================================================
{
/*
      $use = getStatusValue("page.config.vnir.rate", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      if (stristr($use, "pointGrey"))
      {
          $mode = GetXmlValue($profile, "vnir_config.xml", "Mode");
          if ($mode == 0)
            $maxRate = 84;
          else if ($mode == 1)
            $maxRate = 100;
            $maxRate = 140;
      }
      else
         //check for maximum values based on the height
*/
      $maxRate = getStatusValue("page.config.vnir.maxRate", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");

      return $maxRate;
}

/*	===========================================================================
*  This method returns the maximum exposure based on the indicated frame rate 
*  and the specific camera.
*  @param $frameRate - the frame rate for to use when determining the max exposure.
*  @return - the maximum VNIR exposure in milliseconds.
*/
function GetMaxVnirExposure($frameRate)
//	===========================================================================
{
   $use = getStatusValue("page.config.vnir.rate", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   if (stristr($use, "alliedVision"))
   {
      $maxExposure = 100000000;
      if ($frameRate > 0)
      {
         $maxExposure = 1/$frameRate - .000040;
         $maxExposure = $maxExposure*1000; 
      }
   }
   else if (stristr($use, "pointGrey") || stristr($use, "ximea"))
   {
      $maxExposure = 100000000;
      if ($frameRate > 0)
      {
         $maxExposure = 1/$frameRate - .000200;
         $maxExposure = $maxExposure*1000; 
      }
   }

   return $maxExposure;
}

/*	===========================================================================
*  This method is used to set the VNIR frame rate.  It opens the vnir_config.xml
*  configuration file within the given profile. It then reads the file, parsing out
*  the old frame rate and rewriting the file with the new frame rate.
*  @param $profile - this is the name of the profile to change.
*  @param $rate - the VNIR frame rate in HZ.
*  @return - greater than 0 on success, 0 or less on failure.
*/
function SetVnirRate($profile, $rate)
//	===========================================================================
{
   $rateStr = sprintf("%.0f", $rate);
   $isSet = false;
   $value = -1;

   $use = getStatusValue("page.config.vnir.rate", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   if (stristr($use, "alliedVision"))
   {
      $value = SetXmlValue($profile, "vnir_config.xml", "FrameRate", $rateStr);
      if ($value == 1)
         $isSet = true;
   }
   else if (stristr($use, "pointGrey"))
   {
      $value = SetXmlValue($profile, "vnir_config.xml", "FrameRate", $rateStr);
      if ($value == 1)
         $isSet = true;
   }
   else if (stristr($use, "ximea"))
   {
      $value = SetXmlValue($profile, "parameters.xml", "vnir.framerate", $rateStr);
      if ($value == 1)
         $isSet = true;
   }
   
   return $value;
}

/*	===========================================================================
*  This method opens the vnir_config.xml configuration file within the given profile. 
*  It then reads the file to find current VNIR exposure and returns it.
*  @param $profile - this is the name of the profile to view.
*  @return - the VNIR exposure in microseconds.
*/
function GetVnirExposure($profile)
//	===========================================================================
{
   $value = 0;
   
   $use = getStatusValue("page.config.vnir.exposure", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   if (stristr($use, "alliedVision"))
   {
      $value = GetXmlValue($profile, "vnir_config.xml", "ExposureValue");
      $value = $value/1000.0;
   }
   if (stristr($use, "pointGrey"))
   {
      $value = GetXmlValue($profile, "vnir_config.xml", "Exposure");
      $value = $value;
   }
   if (stristr($use, "ximea"))
   {
      $allow = GetXmlValue($profile, "parameters.xml", "vnir.exposure.set");
      if ($allow === "true")
      {
         $value = GetXmlValue($profile, "parameters.xml", "vnir.exposure");
         $value = $value/1000.0;
      }
      else 
         $value = false;
   }

   return $value;
}

/*	===========================================================================
*  This method is used to set the VNIR exposure.  It opens the vnir_config.xml
*  configuration file within the given profile. It then reads the file, parsing out
*  the old exposure and rewriting the file with the new exposure.
*  @param $profile - this is the name of the profile to change.
*  @param $rate - the VNIR exposure in microseconds.
*  @return - greater than 0 on success, 0 or less on failure.
*/
function SetVnirExposure($profile, $exposure)
//	===========================================================================
{
   $isSet = false;
   $use = getStatusValue("page.config.vnir.exposure", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   //echo "use = $use profile = $profile exposure = $exposure \n";	
   if (stristr($use, "aliedVision"))
   {
      $exposure = $exposure*1000; 
      $exposureStr = sprintf("%.0f", $exposure);
      $value = SetXmlValue($profile, "vnir_config.xml", "ExposureValue", $exposureStr);
      if ($value == 1)
         $isSet = true;
   }
   else if (stristr($use, "pointGrey"))
   {
      $exposure = $exposure*1000; 
      $exposureStr = sprintf("%.0f", $exposure);
      $value = SetXmlValue($profile, "vnir_config.xml", "Exposure", $exposureStr);
      if ($value == 1)
         $isSet = true;
   }
   else if (stristr($use, "ximea"))
   {
      $exposure = $exposure*1000; 
      $exposureStr = sprintf("%.0f", $exposure);
      $value = SetXmlValue($profile, "parameters.xml", "vnir.exposure", $exposureStr);
      if ($value == 1)
         $isSet = true;
   }

   return $value;
}

/*	===========================================================================
*  This method opens the swir_config.xml configuration file within the given profile. 
*  It then reads the file to find current SWIR frame rate and returns it.
*  @param $profile - this is the name of the profile to view.
*  @return - the SWIR frame rate in HZ.
*/
function GetSwirRate($profile)
//	===========================================================================
{
   $value = -1;
   
   $use = getStatusValue("page.config.swir.rate", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   if (stristr($use, "airs"))
   {
      $allow = GetXmlValue($profile, "parameters.xml", "swir.framerate.set");
      if ($allow === "true")
         $value = GetXmlValue($profile, "parameters.xml", "swir.framerate");
      else 
         $value = false;
   }
   else if (stristr($use, "xenics"))
   {
      $useFg = getStatusValue("page.config.swir.frameGrabber", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      $useMode = GetXmlValue($profile, 'swir_config.xml', 'CaptureMode'); 
      if (stristr($useFg, "activeSilicon") && $useMode == 3)
      {
         $value = GetPcfValue($profile, 'swir.pcf', 'PHX_LINETRIG_TIMER_PERIOD');
         if ($value > 0)
            $value = 1/$value*1000000;
      }
      else
         $value = GetXmlValue($profile, 'swir_config.xml', 'SensFrameRate');
   }
   else if (stristr($use, "raptor"))
   {
      $useFg = getStatusValue("page.config.swir.frameGrabber", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      $useExternalTrig = GetXmlValue($profile, 'swir_config.xml', 'externalTrig'); 
      if (stristr($useExternalTrig, "false"))
      {
         $value = GetXmlValue($profile, 'swir_config.xml', 'frameRate');
      }   
   }
   else if (stristr($use, "goodrich"))
   {
      $useFg = getStatusValue("page.config.swir.frameGrabber", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      $useMode = GetXmlValue($profile, 'swir_config.xml', 'TRIG:MODE'); 
      if (stristr($useFg, "activeSilicon") && $useMode == 0)
      {
         $value = GetXmlValue($profile, 'swir_config.xml', 'FRAME:PERIOD');
         //10989000 is the pixel rate on the goodrich camera
         if ($value > 0)
         $value = round(10989000/$value);  
      }
   }
      
   return $value;
}

/*	===========================================================================
*  This method is used to set the SWIR frame rate.  It opens the swir_config.xml
*  configuration file within the given profile. It then reads the file, parsing out
*  the old frame rate and rewriting the file with the new frame rate.
*  @param $profile - this is the name of the profile to change.
*  @param $rate - the SWIR frame rate in HZ.
*  @return - greater than 0 on success, 0 or less on failure.
*/
function SetSwirRate($profile, $rate)
//	===========================================================================
{
   $rateStr = sprintf("%.2f", $rate);
   $isSet = false;
   $value = -1;

   $use = getStatusValue("page.config.swir.rate", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   //Xenics Camera   
   if (stristr($use, "xenics"))
   {
      //set rate via frame grabber
      $useFg = getStatusValue("page.config.swir.frameGrabber", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      $useMode = GetXmlValue($profile, 'swir_config.xml', 'CaptureMode'); 
      if (stristr($useFg, "activeSilicon") && $useMode == 3 && $rate > 0)
      {
         $pd = 1/$rate*1000000;  
         $pdStr = sprintf("%.0f", $pd);
         $value = SetPcfValue($profile, "swir.pcf", "PHX_LINETRIG_TIMER_PERIOD", $pdStr);
         if ($value == 1)
            $isSet = true;
      }
      //set rate via the camera
      else
      {
         $value = SetXmlValue($profile, "swir_config.xml", "SensFrameRate", $rateStr);
         if ($value == 1)
            $isSet = true;
      }
   }
   else if (stristr($use, "raptor"))
   {
      $useFg = getStatusValue("page.config.swir.frameGrabber", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      $useExternalTrig = GetXmlValue($profile, 'swir_config.xml', 'externalTrig'); 
      if (stristr($useExternalTrig, "false"))
      {
         $value = SetXmlValue($profile, "swir_config.xml", "frameRate", $rateStr);
         if ($value == 1)
            $isSet = true;
      }   
   }
   else if (stristr($use, "goodrich"))
   {
      $useFg = getStatusValue("page.config.swir.frameGrabber", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      $useMode = GetXmlValue($profile, 'swir_config.xml', 'TRIG:MODE'); 
      if ($useMode == 0)
      {
         $framePeriodStr = round(10989000/$rate);
         $value = SetXmlValue($profile, "swir_config.xml", 'FRAME:PERIOD', $framePeriodStr);
         if ($value == 1)
            $isSet = true;
      }
   }
   else if (stristr($use, "airs"))
   {
      $value = SetXmlValue($profile, "parameters.xml", "swir.framerate", $rateStr);
      if ($value == 1)
         $isSet = true;
   }

   return $value;
}

/*	===========================================================================
*  This method opens the swir_config.xml configuration file within the given profile. 
*  It then reads the file to find current SWIR exposure and returns it.
*  @param $profile - this is the name of the profile to view.
*  @return - the SWIR exposure in microseconds.
*/
function GetSwirExposure($profile)
//	===========================================================================
{
   $value = -1;
   
   $use = getStatusValue("page.config.swir.exposure", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   if (stristr($use, "airs"))
   {
      $allow = GetXmlValue($profile, "parameters.xml", "swir.exposure.set");
      if ($allow === "true")
      {
         $value = GetXmlValue($profile, "parameters.xml", 'swir.exposure');
         $value = $value/1000.0;
      }
      else 
         $value = false;
   }
   if (stristr($use, "xenics"))
   {
      $value = GetXmlValue($profile, 'swir_config.xml', 'IntegrationTime');
      $value = $value/1000.0; 
   }
   if (stristr($use, "raptor"))
   {
      $value = GetXmlValue($profile, 'swir_config.xml', 'exposure');
      $value = $value/1000.0; 
   }
   else if (stristr($use, "goodrich"))
   {
      $value = GetXmlValue($profile, 'swir_config.xml', 'EXP');
       if ($value > 0)
      {
         //10989000 is the pixel rate on the goodrich camera
         //exposure = (EXP+28)/pixelrate.  * 1000000 to convert to microseconds
         $value = round(($value+28)*1000000/10989000);
         $value = $value/1000;
      }
   }
   
   return $value;
}

/*	===========================================================================
*  This method is used to set the SWIR exposure.  It opens the swir_config.xml
*  configuration file within the given profile. It then reads the file, parsing out
*  the old exposure and rewriting the file with the new exposure.
*  @param $profile - this is the name of the profile to change.
*  @param $rate - the SWIR exposure in microseconds.
*  @return - greater than 0 on success, 0 or less on failure.
*/
function SetSwirExposure($profile, $exposure)
//	===========================================================================
{
   $value = 0;
   
   $exposure = $exposure*1000; 
   $exposureStr = sprintf("%.0f", $exposure);
   
   $isSet = false;
   $use = getStatusValue("page.config.swir.exposure", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   if (stristr($use, "airs"))
   {
      $value = SetXmlValue($profile, "parameters.xml", "swir.exposure", $exposureStr);
      $isSet = true;
   }
   else if (stristr($use, "xenics"))
   {
      $value = SetXmlValue($profile, "swir_config.xml", "IntegrationTime", $exposureStr);
      $isSet = true;
   }
   else if (stristr($use, "raptor"))
   {
      $value = SetXmlValue($profile, "swir_config.xml", "exposure", $exposureStr);
      $isSet = true;
   }
   else if (stristr($use, "goodrich"))
   {
      $exp = round($exposure*(10989000/1000000) - 28);
      $value = SetXmlValue($profile, "swir_config.xml", 'EXP', $exp);        
      $isSet = true;
   }

   return $value;
}

/*	===========================================================================
*  This method is used to get the temporal bin count. It opens the swir.xml
*  configuration file within the given profile. It then finds the first temporalbin services 
*  and gets the the 'count' for this service.  If the service is not available,
*  it returns a negatvie value.
*  @param $profile - this is the name of the profile to change.
*  @return - greater than 0 on success, 0 or less on failure.
*/
function GetTemporalBinCount($profile)
//	===========================================================================
{
   $value = getXmlValue2($profile, "swir.xml", "module", "binCount");
   return $value;
}

/*	===========================================================================
*  This method is used to set the temporal bin count.  It opens the swir.xml
*  configuration file within the given profile. It then finds all temporalbin services 
*  and sets the 'count' for these services.
*  @param $profile - this is the name of the profile to change.
*  @param $count - the number of lines to accumulate into a single line.
*  @return - greater than 0 on success, 0 or less on failure.
*/
function SetTemporalBinCount($profile, $count)
//	===========================================================================
{
   $value = SetXmlValue4($profile, "swir.xml", "module", "binCount", $count);
   return $value;
}




/*	===========================================================================
*  This method opens the parameters.xml configuration file. 
*  It then reads the file to find the current rotary scan rate and returns it.
*  @param $profile - this is the name of the profile to view.
*  @return - the rotary scan rate in degrees per second..
*/
function GetXmlProperty($profile, $key)
//	===========================================================================
{
   $value = 0;
   $file = "../config";

   $value = GetXmlValue($profile, 'parameters.xml', $key);
   if ($value < 0)
      $value = GetXmlValue($file, 'parameters.xml', $key);

   return $value;
}

/*	===========================================================================
*  This method opens the parameters.xml configuration file. 
*  It then reads the file to find the current rotary scan rate and returns it.
*  @param $profile - this is the name of the profile to view.
*  @return - the rotary scan rate in degrees per second..
*/
function SetXmlProperty($profile, $key, $value)
//	===========================================================================
{
   $retValue = 0;
   $file = "../config";

   $retValue = SetXmlValue($profile, 'parameters.xml', $key, $value);
   if ($retValue < 0)
      $retValue = GetXmlValue($file, 'parameters.xml', $key, $value);

   return $retValue;
}

?>