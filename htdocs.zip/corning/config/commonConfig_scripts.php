<?php
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/../ih_scripts.php");
include_once(__DIR__."/../ih_defines.php");
include_once("config_scripts.php");

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writing.
*/
function SetXmlValue($profile, $fileName, $key, $value)
//	===========================================================================
{
   $path = "c:\\corningHsi\\config";
   $parametersFilename = sprintf("%s\\%s", $path, "parameters.xml");

   $returnValue = 1;

   $handle = fopen($parametersFilename, 'r');
   if ($handle)
   {
      $message = fread($handle, 4000);
      fclose($handle);
   
      //find the frame rate
      $key = "\"$key\"";
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\"", $startInt);
         $buf3 = substr($message, $endInt);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

	return $returnValue;
}

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to all key value pairs within the file.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to view.
*  @param $key    - this is an array of keys to be output by this function.
*  @param $value  - this is an array of values to be output by this function.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function GetAllXmlValues($fileName)
//	===========================================================================
{
   $path = "c:\\corningHsi\\config";
   $commonConfigFilename = sprintf("%s\\%s", $path, "commonConfig.xml");
   $parametersFilename = sprintf("%s\\%s", $path, "parameters.xml");
   
   $comHandle = fopen($commonConfigFilename, 'r');
   $parHandle = fopen($parametersFilename, 'r');
   if ($comHandle && $parHandle)
   {

      $comMessage = fread($comHandle, 4000);
      $parmMessage = fread($parHandle, 10000);
      fclose($comHandle);
      fclose($parHandle);
      $startKey = strpos($comMessage, "<key>");
      $count = 0;
      while ($startKey > 0)
      {
         $startKey += 5;  //strlen of <key>
         $endKey = strpos($comMessage, "</key", $startKey);
         $keyValid = FALSE;
         $key = FALSE;
         if ($startKey > 0 && $endKey > $startKey)
         {
            $keyValid = TRUE;   
            $key = substr($comMessage, $startKey, $endKey-$startKey);
         }
         
         $startValue = strpos($parmMessage, "<property name=\"".$key);
         if ($startValue !== FALSE)
         {
            $startValue = strpos($parmMessage, "value=", $startValue) + 7;
            $endValue = strpos($parmMessage, "\"", $startValue);

            $value = FALSE;  
            if ($endValue > $startValue)
               $value = substr($parmMessage, $startValue, $endValue-$startValue);

            if ($key !== FALSE && $value !== FALSE)
            {
               $keyValue[$count][0] = $key; 
               $keyValue[$count][1] = $value;
               $count++; 
            }
         }
         $startKey = strpos($comMessage, "<key>", $startKey);
      }     
   }

	return $keyValue;
}

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $properties - this is an array of the key value pairs to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writing.
*/
function SetXmlValues($property, $count)
//	===========================================================================
{
   $returnValue = 1;
   $path = "c:\\corningHsi\\config";
   $parametersFilename = sprintf("%s\\%s", $path, "parameters.xml");
   $handle = fopen($parametersFilename, 'r');
   
   if ($handle)
   {
      $newFile = '';
      $message = fread($handle, 10000);
      fclose($handle);
   
      //find the frame rate
      for ($x = 0; $x < $count; $x++)
      {
         $key = "name=\"".$property[$x][0]."\"";
         $value = $property[$x][1];
         $startInt = strpos($message, $key);
         if ($startInt)
         {
            $startInt = strpos($message, 'value=', $startInt);
            $startInt = $startInt + 7;
            $buf1 = substr($message, 0, $startInt);
            $buf2 = $property[$x][1];
            $endInt = strpos($message, "\"", $startInt);
            $buf3 = substr($message, $endInt);
            
            $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
            $message = $newFile;
         }
      }
      
      $handle = fopen($parametersFilename, 'w');
      if ($handle)
      {
         fwrite($handle, $newFile);
         fclose($handle);
      }
      else
         $returnValue = -4;
   }
   else
      $returnValue = -1;

	return $returnValue;
}
