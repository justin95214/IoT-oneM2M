<?php
include_once("../ih_scripts.php");
include_once("activeConfig_scripts.php");

$post = "";
foreach ($_REQUEST as $key => $value)
{
   if (is_array($value))
   {
      foreach($value as $item)
      {
         $post = $post . $key . "=" . $item . "<br>";
      }
   }
   else
   {
      $post = $post . $key . "=" . $value . "<br>";
   }
}
//echo $post;

$count = $_POST["count"];
$index = 0;
$propArray = '';
for ($x = 0; $x < intval($count); $x++)
{
   $checkBx = "checkBx".$x."=";
   $pos = strpos($post, $checkBx); 
   $key = '';
   $value = '';
   
   if (strlen($pos))
   {
      //find the key for checked item 
      $beg = strpos($post, "=", $pos);
      $beg = $beg+1;
      $end = strpos($post, "<", $beg);
      $len = $end - $beg;
      $key = substr($post, $beg, $len);
      $k = $key."=";
      $k = str_replace(".", "_", $k);
      
      //find the value for the key
      $pos = strpos($post, $k);  
      if (strlen($key))
      {
         //find the value for the key
         $beg = strpos($post, "=", $pos);
         $beg = $beg+1;
         $end = strpos($post, "<", $beg);
         $len = $end - $beg;
         $value = substr($post, $beg, $len);
      }
      if (strlen($key) && strlen($value))
      {
         $propArray[$index][0] = $key;
         $propArray[$index][1] = $value;
         $index++;
      }
   }
}
if ( $index > 0)
{
   for ($x = 0; $x < intval($count); $x++)
   {
      if(strcmp($propArray[$x][0], "rotary.scan.angle") == 0)
      {
         //value check
         if ($propArray[$x][1] > 60)
            $propArray[$x][1] = 60;
         if ($propArray[$x][1] < 7.5)
            $propArray[$x][1] = 7.5;
      }
   }

   SetXmlValues("activeConfig.xml", $propArray, $index);
   SetProperty("ih", $propArray);
}

echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=activeConfig.html'\>";
?> 