<?php
include_once("../ih_scripts.php");
include_once("dataSelector_scripts.php");

$post = "";
foreach ($_REQUEST as $key => $value)
{
   if (is_array($value))
   {
      foreach($value as $item)
      {
         $post = $post . $key . "=" . $item . "<br>";
      }
   }
   else
   {
      $post = $post . $key . "=" . $value . "<br>";
   }
}
//echo $post;

$rawImgFile = $_POST['rawImgFile'] == 'on' ? "true" : "false";
$rawNavData = $_POST['rawNavData'] == 'on' ? "true" : "false";
$calImgFile = $_POST['calImgFile'] == 'on' ? "true" : "false";
$calNavData = $_POST['calNavData'] == 'on' ? "true" : "false";
$selectImgFile = $_POST['selectImgFile'] == 'on' ? "true" : "false";
$selectNavData = $_POST['selectNavData'] == 'on' ? "true" : "false";

setUseRawImage($rawImgFile);
setUseRawNav($rawNavData);
setUseCalImage($calImgFile);
setUseCalNav($calNavData);
setUseSelectImage($selectImgFile);
setUseSelectNav($selectNavData);

echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=dataSelector.html'\>";
?> 