<?php
define("BAND_SELECTOR_FILE", "C:\\CorningHsi\\config\\bandSelection.xml", false);
define("PROP_FILE", "C:\\CorningHsi\\config\\parameters.xml", false);
define("BAND_SELECTOR_SENSOR", "vnir", false);

if(!isset($_SESSION)) 
{ 
   session_start(); 
}  

if (!isset($_SESSION['pause_']))
	$_SESSION['pause_'] = 0;
	
if (!isset($_SESSION['curSelectedName_']))
	$_SESSION['curSelectedName_'] = "new";

if (!isset($_SESSION['active2xName_']))
	$_SESSION['active2xName_'] = "";

if (!isset($_SESSION['active4xName_']))
	$_SESSION['active4xName_'] = "";

if (!isset($_SESSION['curBinning_']))
	$_SESSION['curBinning_'] = 2;
?>