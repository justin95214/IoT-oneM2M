<?php
include_once("../ih_scripts.php");
include_once("commonConfig_scripts.php");

$post = "";
foreach ($_REQUEST as $key => $value)
{
   if (is_array($value))
   {
      foreach($value as $item)
      {
         $post = $post . $key . "=" . $item . "<br>";
      }
   }
   else
   {
      $post = $post . $key . "=" . $value . "<br>";
   }
}
//echo $post;

$count = $_POST["count"];
$validIp = $_POST["validIp"];
$restoreDefault = $_POST["restoreDefault"];
if ($restoreDefault == "true")
{
   shell_exec("xcopy C:\CorningHsi\backup\config C:\CorningHsi\config /i /f /y /r /c");
   shell_exec("xcopy C:\CorningHsi\backup\profiles C:\CorningHsi\profiles /i /f /y /r /c /s");
}
else
{
   $index = 0;
   $propArray = '';
   for ($x = 0; $x < intval($count); $x++)
   {
      $checkBx = "checkBx".$x."=";
      $pos = strpos($post, $checkBx); 
      $key = '';
      $value = '';
   
      if (strlen($pos))
      {
         //find the key for checked item 
         $beg = strpos($post, "=", $pos);
         $beg = $beg+1;
         $end = strpos($post, "<", $beg);
         $len = $end - $beg;
         $key = substr($post, $beg, $len);
         $k = $key."=";
         $k = str_replace(".", "_", $k);
      
         //find the value for the key
         $pos = strpos($post, $k);  
         if (strlen($key))
         {
            //find the value for the key
            $beg = strpos($post, "=", $pos);
            $beg = $beg+1;
            $end = strpos($post, "<", $beg);
            $len = $end - $beg;
            $value = substr($post, $beg, $len);
         }

         $validEntry = true;
         if (($key == 'sys.ip' || $key == 'sys.subnet.mask') && $validIp == "false")
            $validEntry = false;

         if ($validEntry && strlen($key) && strlen($value))
         {
            $propArray[$index][0] = $key;
            $propArray[$index][1] = $value;
            $index++;
         }
      }
   }

   if ($validIp == 'true')
   {
      $propArray[$index][0] = 'sys.ip.reset';
      $propArray[$index][1] = 'true';
   }

   if ( $index > 0)
   {
      SetXmlValues($propArray, $index);
   }

   if ($validIp == 'true')
   {
      system(setNic);
   }
}
echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=commonConfig.html'\>";
?> 