<?php
//include_once("../ih_scripts.php");
include_once("bandSelector_scripts.php");
include 'bandSelector_vars.php';

/*
$post = "";
foreach ($_REQUEST as $key => $value){
   if (is_array($value)){
      foreach($value as $item)
         $post = $post . $key . "=" . $item . "<br>";
   }else{
      $post = $post . $key . "=" . $value . "<br>";
   }
}
echo "$post<p>";
*/

$saveSet = ($_POST['saveSet'] == "true"); 
$deleteSet = ($_POST['deleteSet'] == "true");  
$changeSet = ($_POST['changeSet'] == "true");  
$changeBinning = ($_POST['changeBin'] == "true");  

$curSelectedName = $_POST['curSelectedName'];
$bandSetName = $_POST['bandSet'];
$selectedActive = $_POST['selectedActive'];
$totalBandCount =  $_POST['totalBandCount']; 
$bin =  $_POST['bin'];
$_SESSION['pause_'] = 5;

$binning = 2;
if ($bin == "bin4")
   $binning = 4;

if ($saveSet == true)
{
   $changedActiveName = false;
   if (($binning == 2 && $_SESSION['active2xName_'] != $selectedActive) ||
       ($binning == 4 && $_SESSION['active4xName_'] != $selectedActive))
   {
      $changedActiveName = true;
      $bands = getBands($binning, $selectedActive);
      $usePropServer = true;
      $usePropFile = true;
      $useBandSelectorFile = true;
      setActiveName(BAND_SELECTOR_FILE, $selectedActive, $binning, $bands, $usePropServer, $usePropFile, $useBandSelectorFile);
   }

   //add a new band set
   if ($curSelectedName == "new")
   {
      $bandArray = array();

      if ($bandSetName == false)
      {
         if ($changedActiveName == false)
         {
            echo "<h3>Missing 'Set' name.</h3><br>";
            $_SESSION['pause_'] = 5;
         }
      }         
      else if (strcasecmp($bandSetName,"new") == 0)
      {
         echo "<h3>Illegal 'Set' name.</h3><br>";
         $_SESSION['pause_'] = 5;
      }         
      else
      {   
         for ($x = 0; $x < $totalBandCount; $x++)
         {
            $num = $x + 1;
            $band = "band".$num;
            $set = $_POST[$band];

            if ($set == "on")
            {
               $y = $x + 1;   
               $bandArray[$x] = true; 
            }
            else
               $bandArray[$x] = false; 
         }
         $bandList = createBandList($bandArray, $totalBandCount);
         addBandSet($bandSetName, $bandList, $binning, "false");
         $_SESSION['curSelectedName_'] = $bandSetName;
      }
   }
   //updae an existing band set
   else
   {
      for ($x = 0; $x < $totalBandCount; $x++)
      {
         $num = $x + 1;
         $band = "band".$num;
         $set = $_POST[$band];

         if ($set == "on")
         {
            $y = $x + 1;   
            $bandArray[$x] = true; 
         }
         else
            $bandArray[$x] = false; 
      }
      $bandList = createBandList($bandArray, $totalBandCount);
      changeBandSet($bandSetName, $bandList, $binning);

      if ($selectedActive == $bandSetName)
      {
         $usePropServer = true;
         $usePropFile = true;
         $useBandSelectorFile = true;
         setActiveName(BAND_SELECTOR_FILE, $selectedActive, $binning, $bandList, $usePropServer, $usePropFile, $useBandSelectorFile);
      }
   }
}

if ($deleteSet == true)
{
  
   deleteBandSet($bandSetName, $binning);
   $_SESSION['curSelectedName_'] = "new";
}


if ($changeSet == true)
{
   $_SESSION['curSelectedName_'] = $_POST['curSelectedName'];
}

if ($changeBinning == true)
{
   $bin = $_POST['bin'];

   if ($bin == "bin4")
      $_SESSION['curBinning_'] = 4;
   else
      $_SESSION['curBinning_'] = 2;

   $_SESSION['curSelectedName_'] = "new";
}

echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=bandSelector.html'\>";

?> 