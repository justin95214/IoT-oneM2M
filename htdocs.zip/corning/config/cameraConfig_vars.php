<?php
include_once(__DIR__."/../ih_defines.php");

if(!isset($_SESSION)) 
{ 
   session_start(); 
}  

if (!isset($_SESSION['pause_']))
	$_SESSION['pause_'] = 0;
	
if (!isset($_SESSION['profile_']))
	$_SESSION['profile_'] = "";

if (!isset($_SESSION['vnirRate_']))
	$_SESSION['vnirRate_'] = "";

if (!isset($_SESSION['vnirExposure_']))
	$_SESSION['vnirExposure_'] = 0;

if (!isset($_SESSION['swirRate_']))
	$_SESSION['swirRate_'] = "";

if (!isset($_SESSION['swirExposure_']))
	$_SESSION['swirExposure_'] = 0;

if (!isset($_SESSION['rotaryScanRate_']))
	$_SESSION['rotaryScanRate_'] = -1;
   
if (!isset($_SESSION['accumulateCount_']))
	$_SESSION['accumulateCount_'] = 0;
   
if (!isset($_SESSION['eventTracksFile_']))
	$_SESSION['eventTracksFile_'] = "";  
?>