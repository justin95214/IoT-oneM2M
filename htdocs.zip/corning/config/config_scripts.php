<?php
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/../ih_defines.php");

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $profile - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to view.
*  @param $key - this is the key used to search for the value.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function GetXmlValue($profile, $fileName, $key)
//	===========================================================================
{
   $key = "\"$key\"";
   $path = getenv("PROFILE_HOME");
   if (!$path)
      return -3;
      
   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);

   $handle = fopen($filename, 'r');
   if ($handle != NULL)
   {
   
      $message = fread($handle, 20000);
      
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $endInt = strpos($message, "\"", $startInt);
         $len = $endInt - $startInt;
         $value = substr($message, $startInt, $len);
      }
      else
         $value = -2;
   }
   else
      $value = -1;
   
   fclose($handle);

	return $value;
}

/*	===========================================================================
*  This method opens an XML file. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $filename - this is the name of the XML file to view.
*  @param $key - this is the key used to search for the value.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function GetXmlValueFile($filename, $key)
//	===========================================================================
{
   if (!$filename)
      return -3;
      
   $handle = fopen($filename, 'r');
   if ($handle)
   {
   
      $message = fread($handle, 20000);
      
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $endInt = strpos($message, "\"", $startInt);
         $len = $endInt - $startInt;
         $value = substr($message, $startInt, $len);
      }
      else
         $value = -2;
   }
   else
      $value = -1;
   
   fclose($handle);

	return $value;
}

/*	===========================================================================
*  This method opens an XML file with the given filename. 
*  It then reads the file to find current key and sets the corresponding value.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetXmlValueFile($filename, $key, $value)
//	===========================================================================
{
   $returnValue = 1;
   if (!$filename)
      $returnValue = -3;

   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);
   
      //find the frame rate
      $key = "\"$key\"";
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\"", $startInt);
         $buf3 = substr($message, $endInt);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

	return $returnValue;
}

?>
