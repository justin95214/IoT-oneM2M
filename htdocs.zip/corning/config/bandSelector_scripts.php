<?php
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/../ih_defines.php");
include_once("../ih_scripts.php");

/*	===========================================================================
*  getBands2Xbinning  looks for an XML bandSet entry with 2x binning and the given bandSet name.  
*  If found it returns a string representing the selected bands for this set.
*  @param $name - the name of the bandSet to find.
*  @return -  String that represents the selected bands.  I.E. 10,20,25-30,66,123,129-133.
*             False on failure.
*/
function getBands2Xbinning($name)
//	===========================================================================
{
   $ret = getBands(2, $name);
   return $ret;
}

/*	===========================================================================
*  getBands4Xbinning  looks for an XML bandSet entry with 4x binning and the given bandSet name.
*  If found it returns a string representing the selected bands for this set.
*  @param $name - the name of the bandSet to find.
*  @return -  String that represents the selected bands.  I.E. 10,20,25-30,66,123,129-133.
*             False on failure.
*/
function getBands4Xbinning($name)
//	===========================================================================
{
   $ret = getBands(4, $name);
   return $ret;
}

/*	===========================================================================
*  getBands looks for an XML bandSet entry with the specified binning and set name.  If
* found it returns a string representing the selected bands for this set.
*  @param $seletedName - the name of the bandSet to find.
*  @param $selectedBinning - the name of the bandSet to find.
*  @return -  String that represents the selected bands.  I.E. 10,20,25-30,66,123,129-133.
*             False on failure.
*/
function getBands($selectedBinning, $seletedName)
//	===========================================================================
{
   $filename = BAND_SELECTOR_FILE;
   $handle = fopen($filename, 'r');
   $bands = "not found";   
   $index = 0;
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);

      $bandSet = getParam($message, "bandSet", $index);
      while ($bandSet != false)
      {
         $binning = getParam($bandSet, "binning", 0);
         if ($binning != false && $binning == $selectedBinning)
         {

            $name = getParam($bandSet, "name", 0);
            if ($name != false && $name == $seletedName)
            {
               $bands = getParam($bandSet, "bands", 0);
               break;
            }
         }
         $bandSet = getParam($message, "bandSet", $index);
         $index++;
      }
   }
   else
      $bands = false;

   return $bands;
}

/*	===========================================================================
*  getSpectralResolution2Xbinning  Returns the spectral resolution for 2x binning.
*  @return -  the spectral resolution to 2 decimal places.
*             False on failure.
*/
function getSpectralResolution2Xbinning()
//	===========================================================================
{
   $ret = getSpedctralResolution("C:\\CorningHsi\\config\\vnir_2xBands.xml");
   return $ret;
}

/*	===========================================================================
*  getSpectralResolution2Xbinning  Returns the spectral resolution for 4x binning.
*  @return -  the spectral resolution to 2 decimal places.
*             False on failure.
*/
function getSpectralResolution4Xbinning()
//	===========================================================================
{
   $ret = getSpedctralResolution("C:\\CorningHsi\\config\\vnir_4xBands.xml");
   return $ret;
}

/*	===========================================================================
*  getSpedctralResolution  Returns the spectral resolution as determined by
* reading the sensor configuration file.
*  @sensorConfigFile  - the sensor configuration file to be used to determine the
                        spectral resolution.
*  @return -  the spectral resolution to 2 decimal places.
*             False on failure.
*/
function getSpedctralResolution($sensorConfigFile)
//	===========================================================================
{
   if ($sensorConfigFile == false)
      return false;

   $handle = fopen($sensorConfigFile, 'r');
   $numBands = 0;
   $accumlatedDifference = 0;
   $lastBandFlt = 0;
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);

      $key = "name=\"waveLengths\"";
      $startIdx = strpos($message, $key);
      if ($startIdx == false)
         return false;

      $key = "value=";
      $startIdx = strpos($message, $key, $startIdx);
      if ($startIdx == false)
         return false;

      $startIdx += strlen("value=");
      $key = "/>";
      $endIdx = strpos($message, $key, $startIdx);
      if ($endIdx == false)
         return false;

      $value = substr($message, $startIdx, $endIdx - $startIdx);
      $found = true;
      $startIdx = 0;
      $endIdx = 0;
      while ($found == true)
      {
         $endIdx = strpos($value, ",", $startIdx);
         if ($endIdx  == false)
             $endIdx = strpos($value, "\"", $startIdx);

         if ($endIdx == false)
            break;
      
         $band = substr($value, $startIdx, $endIdx - $startIdx);

         //trim the beggining
         for ($x = 0; $x < strlen($band); $x++)
         {
            if ($band[0] < '0' || $band[0] > '9')
               $band = substr($band, 1);
            else 
               break;
         }

         //trim the end
         if (strlen($band))
         { 
            for ($x = strlen($band) - 1; $x > 0; $x--)
            {
               if ($band[$x] < '0' || $band[$x] > '9')
                  $band = substr($band, 0, strlen($band) - 1);
               else 
                  break;
            }
         }

         $bandFlt = floatval($band);
         $startIdx = $endIdx + 1;
         $numBands++;
         if ($numBands > 1)
            $accumlatedDifference += $bandFlt - $lastBandFlt;
 
        $lastBandFlt = $bandFlt;
      }
   }
   
   $resolution = 0;
   if ($numBands > 1)
      $resolution = $accumlatedDifference/($numBands - 1);

   return round($resolution, 2, PHP_ROUND_HALF_UP);
}

/*	===========================================================================
*  load2XNames Creates a 2X binning name list for inclusion in an HTML document.
*  The name corresponding to the currentSelection is set as selected for this list.
*  The names are derived from the BAND_SELECTOR_FILE file.
*  @param $currentSelection - the name of the bandSet to be selected.
*  @return -  The currentSelection if selected.
*/
function load2XNames($currentSelection)
//	===========================================================================
{
   $ret = loadListNames(2, $currentSelection);
   return $ret;
}

/*	===========================================================================
*  load4XNames Creates a 4X binning name list for inclusion in an HTML document.
*  The name corresponding to the currentSelection is set as selected for this list.
*  The names are derived from the BAND_SELECTOR_FILE file.
*  @param $currentSelection - the name of the bandSet to be selected.
*  @return -  The currentSelection if selected.
*/
function load4XNames($currentSelection)
//	===========================================================================
{
   $ret = loadListNames(4, $currentSelection);
   return $ret;
}

/*	===========================================================================
*  loadListNames Creates a binning name list for inclusion in an HTML document.
*  The name corresponding to the currentSelection is set as selected for this list.
*  The names are derived from the BAND_SELECTOR_FILE file.
*  @param $binning - the binning value to use in the the list.
*  @param $currentSelection - the name of the bandSet to be selected.
*  @return -  The currentSelection if selected.
*/
function loadListNames($binning, $currentSelection)
//	===========================================================================
{
   $selectedName = "new";
   $bandsFilename = BAND_SELECTOR_FILE;
   $names = getListOfNames($bandsFilename, $binning);
   $count = count($names);
   echo "<select style=\"width: 130px\" name=\"curSelectedName\" onchange=\"changeSelection()\">\n"; 
   echo "\t<option value=\"new\">new</option>\n";
   for ($x = 0; $x < $count; $x++)
   {
      if ($currentSelection != false && $names[$x] == $currentSelection)
      {
         $selectedName = $names[$x];
         echo "\t<option selected=\"selected\" value=\"$names[$x]\">$names[$x]</option>\n";
      }
      else
         echo "\t<option value=\"$names[$x]\">$names[$x]</option>\n";
   }
   echo "</select><br><br>\n";
   return $selectedName;
}

/*	===========================================================================
*  loadActive2XNames Creates a 2x binning name list for inclusion in an HTML document.
*  The name corresponding to the active setName is selected.  The active setName
*  is the set bandList that is to run on the system when binning is 2X.
*  @return - the setName that is active.
*/
function loadActive2XNames()
//	===========================================================================
{
   $setName = loadActiveListNames(2);
   return $setName;
}

/*	===========================================================================
*  loadActive4XNames Creates a 4x binning name list for inclusion in an HTML document.
*  The name corresponding to the active setName is selected.  The active setName
*  is the set bandList that is to run on the system when binning is 4X.
*  @return - the setName that is active.
*/
function loadActive4XNames()
//	===========================================================================
{
   $setName = loadActiveListNames(4);
   return $setName;
}

/*	===========================================================================
*  loadActiveListNames Creates a binning name list for inclusion in an HTML document.
*  The name corresponding to the active setName is selected.  The active setName
*  is the set bandList that is to run on the system for the selected binning.
*  The file BAND_SELECTOR_FILE is used to derive the list.
*  @return - the setName that is active.
*/
function loadActiveListNames($binning)
//	===========================================================================
{
   $bandsFilename = BAND_SELECTOR_FILE;
   $selectedName = getActiveName($bandsFilename, $binning);

   $names = getListOfNames($bandsFilename, $binning);
   $count = count($names);
   echo "<select name=\"selectedActive\" style=\"width: 130px\">\n"; 

   if ($selectedName == "none" || $selectedName == "unknownName")
      echo "<option value=\"$selectedName\">$selectedName</option>\n";

   for ($x = 0; $x < $count; $x++)
   {
      if ($names[$x] == $selectedName)
         echo "<option selected=\"selected\" value=\"$names[$x]\">$names[$x]</option>\n";
      else
         echo "<option value=\"$names[$x]\">$names[$x]</option>\n";
   }
   echo "</select><br><br>\n";

   return $selectedName;
}


/*	===========================================================================
*  getActiveName retrieves the name of the active setName for the given binning.
*  The active setName is the bandSet that is to run on the system for the selected binning.
*  @param $filename - the xml band selector file to derive the active setName from.
*  @param $selectedBinning - the binning value to use for the selection.
*  @return - the setName that is active.
*/
function getActiveName($filename, $selectedBinning)
//	===========================================================================
{
   $propBandList = false;
   $key = BAND_SELECTOR_SENSOR.".".$selectedBinning."Xbin.selectedBands";
   $name = "none";
   $bands = false;
   $useBandSelectorFile = false;

   //if property server is running use that as definitive band list
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
   {
      $propBandList = getProperty("ih", $key);
      if ($propBandList != false)
      {
         $name = "unknownName";
      }
   }

   $handle = fopen($filename, 'r');
   $index = 0;
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);

      $bandSet = getParam($message, "bandSet", $index);
      while ($bandSet != false)
      {
         $binning = getParam($bandSet, "binning", 0);
         if ($binning != false && $binning == $selectedBinning)
         {
            if ($propBandList != false)
            {
               $bands = getParam($bandSet, "bands", 0);
               if ($bands == $propBandList)
               {
                  $name = getParam($bandSet, "name", 0);
                  $active = getParam($bandSet, "active", 0);

                  if ($active == "true")
                     $useBandSelectorFile = false;
                  else
                     $useBandSelectorFile = true;

                  break;
               }
            }
            else
            {   
               $active = getParam($bandSet, "active", 0);
               if ($active == "true")
               {
                  $bands = getParam($bandSet, "bands", 0);
                  $name = getParam($bandSet, "name", 0);
                  $useBandSelectorFile = false;
                  break;
               }
            }
         }
         $bandSet = getParam($message, "bandSet", $index);
         $index++;
      }
   }

   if ($name != "none" && $name != "unknownName" && $bands != false)
   {
      $usePropServer = false;
      $usePropFile = true;
      setActiveName($filename, $name, $selectedBinning, $bands, $usePropServer, $usePropFile, $useBandSelectorFile);
   }

   return $name;
}


function setActiveName($filename, $name, $selectedBinning, $bands, $usePropServer, $usePropFile, $useBandSelectorFile)
{
   $key = BAND_SELECTOR_SENSOR.".".$selectedBinning."Xbin.selectedBands";
   if ($usePropServer == true)
   {
      $propServerRunning = IsPropServerRunning("ih");
      if ($propServerRunning != false)
      {
         $props[0][0] = $key;
         $props[0][1] = $bands;
         $propBandList = setProperty("ih", $props);
      }
   }

   if ($usePropFile == true)
   {
      SetXmlValue(PROP_FILE, $key, $bands);
   }

   if ($useBandSelectorFile == true)
   {
      $filename = BAND_SELECTOR_FILE;
      $handle = fopen($filename, 'r');
      if ($handle)
      {
         $message = fread($handle, 20000);
         fclose($handle);
         
         $fileStr = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
         $fileStr = $fileStr."<set>\n";

         $index = 0;
         $bandSet = getParam($message, "bandSet", $index);

         $bin = $selectedBinning;
         while ($bandSet != false)
         {
            $n = getParam($bandSet, "name", 0);
            $b = getParam($bandSet, "binning", 0);
            $a = getParam($bandSet, "active", 0);
            $l = getParam($bandSet, "bands", 0);
            if (strcasecmp($name, $n) == 0 && $bin == $b)
            {
               $fileStr = $fileStr."   <bandSet>\n";
               $fileStr = $fileStr."      <name>".$n."</name>\n";
               $fileStr = $fileStr."      <bands>".$l."</bands>\n";
               $fileStr = $fileStr."      <binning>".$b."</binning>\n";
               $fileStr = $fileStr."      <active>true</active>\n";
               $fileStr = $fileStr."   </bandSet>\n";
            }
            else if ($bin == $b)
            {
               $fileStr = $fileStr."   <bandSet>\n";
               $fileStr = $fileStr."      <name>".$n."</name>\n";
               $fileStr = $fileStr."      <bands>".$l."</bands>\n";
               $fileStr = $fileStr."      <binning>".$b."</binning>\n";
               $fileStr = $fileStr."      <active>false</active>\n";
               $fileStr = $fileStr."   </bandSet>\n";
            }
            else
            {
               $fileStr = $fileStr."   <bandSet>\n";
               $fileStr = $fileStr."      <name>".$n."</name>\n";
               $fileStr = $fileStr."      <bands>".$l."</bands>\n";
               $fileStr = $fileStr."      <binning>".$b."</binning>\n";
               $fileStr = $fileStr."      <active>".$a."</active>\n";
               $fileStr = $fileStr."   </bandSet>\n";
            }

            $index++;
            $bandSet = getParam($message, "bandSet", $index);
         }

         $fileStr = $fileStr."</set>\n";

         $handle = fopen($filename, 'w');
         if ($handle)
         {
            fwrite($handle, $fileStr);
            fclose($handle);
            $success = true;
         }
      }
   }
}


/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetXmlValue($filename, $key, $value)
//	===========================================================================
{
   $returnValue = 1;
   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);
   
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\"", $startInt);
         $buf3 = substr($message, $endInt);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
      {
         $startInt = strpos($message, "</set>");
         if ($startInt)
         {
            $buf1 = substr($message, 0, $startInt);
            $buf2 = "   <property name=\"".$key."\" value=\"".$value."\"/>\n";
            $buf3 = substr($message, $startInt);
         
            $handle = fopen($filename, 'w');
            $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
            if ($handle)
            {
               fwrite($handle, $newFile);
               fclose($handle);
            }
            else
               $returnValue = -4;
         }
      }
   }
   else
      $returnValue = -1;

	return $returnValue;
}


/*	===========================================================================
*  getListOfNames retrieves an array of names from the xml band selector file for the
*  indicated binning.
*  @param $filename - the xml band selector file to derive the setNames from.
*  @param $selectedBinning - the binning value to use for the selection.
*  @return - an array of setNames.
*/
function getListOfNames($filename, $selectedBinning)
{
   $handle = fopen($filename, 'r');
   $name = array();   
   $index = 0;
   $numFound = 0;
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);

      $bandSet = getParam($message, "bandSet", $index);
      while ($bandSet != false)
      {
         $binning = getParam($bandSet, "binning", 0);
         if ($binning != false && $binning == $selectedBinning)
         {
            $n = getParam($bandSet, "name", 0);
            if ($n == true)
            {
               $name[$numFound] = $n;
               $numFound++;
            }
            else
               break;
         }

         $index++;
         $bandSet = getParam($message, "bandSet", $index);
      }
   }
   else
      $name = false;

   return $name;
}

/*	===========================================================================
*  getParam is used to parse and XML string for the given value starting at
*  the occurrence as indicated by the index.
*  @param $xmlString - This is the string to parse the value from.
*  @param $key - this is the key to search for to find the indicated value.
*  @param $index - indicates which occurrence of the key/value pair to obtain.  
*                  This is a zero based index.
*  @return - the value for the given key and index.  False of failure.
*/
function getParam($xmlString, $key, $index)
{
   if ($xmlString == false || $key == false)
      return false;

   $offset = 0;
   $valueStartPos = strpos($xmlString, "<$key>", $offset);
   $valueStartPos += strlen("<$key>");
   $valueEndPos = strpos($xmlString, "</$key>", $offset);


   if ($valueEndPos == false)
      return false;

   for ($x = 0; $x < $index; $x++)
   {
      $offset = $valueEndPos + 1;
      $valueStartPos = strpos($xmlString, "<$key>", $offset);
      $valueStartPos += strlen("<$key>");
      $valueEndPos = strpos($xmlString, "</$key>", $offset);

      if ($valueEndPos == false)
         return false;
   }

   $value = substr($xmlString, $valueStartPos, $valueEndPos-$valueStartPos);
   return $value;
}

function loadBin2XBands($bandListStr)
//	===========================================================================
{
   $ret = loadBands("C:\\CorningHsi\\config\\vnir_2xBands.xml", $bandListStr);
}

function loadBin4XBands($bandListStr)
//	===========================================================================
{
   loadBands("C:\\CorningHsi\\config\\vnir_4xBands.xml", $bandListStr);
}


/*	===========================================================================
* loadBands parses the sensor configuration file and loads these values into
* the HTML document with associated check boxes indicating if the value is selected.
*  @param $sensorConfigFile - the filename of the configuration file used to obtain the
*                             bands.
*  @param $bandList - this is a string that represents the bands to be selected.
*  @return -  0 on success, false on error.
*/
function loadBands($sensorConfigFile, $bandListStr)
//	===========================================================================
{
   $bandCount = getBandCount($sensorConfigFile);
   $bandlist = getBandList($bandListStr, $bandCount);

   $handle = fopen($sensorConfigFile, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);
      
      $key = "name=\"waveLengths\"";
      $startIdx = strpos($message, $key);
      if ($startIdx == false)
         return false;

      $key = "value=";
      $startIdx = strpos($message, $key, $startIdx);
      if ($startIdx == false)
         return false;

      $startIdx += strlen("value=");
      $key = "/>";
      $endIdx = strpos($message, $key, $startIdx);
      if ($endIdx == false)
         return false;

      $value = substr($message, $startIdx, $endIdx - $startIdx);
      $found = true;
      $startIdx = 0;
      $endIdx = 0;
      $lineNum = 1;
      while ($found == true)
      {
         $endIdx = strpos($value, ",", $startIdx);
         if ($endIdx  == false)
             $endIdx = strpos($value, "\"", $startIdx);

         if ($endIdx == false)
            break;
      
         $band = substr($value, $startIdx, $endIdx - $startIdx);

         //trim the beggining
         for ($x = 0; $x < strlen($band); $x++)
         {
            if ($band[0] < '0' || $band[0] > '9')
               $band = substr($band, 1);
            else 
               break;
         }

         //trim the end
         if (strlen($band))
         { 
            for ($x = strlen($band) - 1; $x > 0; $x--)
            {
               if ($band[$x] < '0' || $band[$x] > '9')
                  $band = substr($band, 0, strlen($band) - 1);
               else 
                  break;
            }
         }

         $bandFlt = floatval($band);
         $bandFlt = round($bandFlt, 0, PHP_ROUND_HALF_UP);
         if ($bandlist[$lineNum - 1] == true)
           echo "<input type=\"checkbox\" id=\"band$lineNum\" name=\"band$lineNum\" checked/>$bandFlt &nbsp;&nbsp;";
         else 
           echo "<input type=\"checkbox\" id=\"band$lineNum\" name=\"band$lineNum\"/>$bandFlt &nbsp;&nbsp;";

         if ($lineNum%7 == 0)
            echo "<br>\n";   

         $lineNum++;
         $startIdx = $endIdx + 1;
      }
      $lineNum--;
      echo "<br><br>\n";  
      echo "<input type=\"hidden\" id=\"totalBandCount\" name=\"totalBandCount\" value=\"$lineNum\"/>\n";
   }   
   return 0;
}

/*	===========================================================================
* getBandCount accesses the sensor configuration file to determine the number of bands.
*  @param $sensorConfigFile - the filename of the configuration file used to obtain the
*                             number of bands.
*  @return -  the number of bands on success, false on error.
*/
function getBandCount($sensorConfigFile)
{
   $lineNum = 0;
   $handle = fopen($sensorConfigFile, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);
      
      $key = "name=\"waveLengths\"";
      $startIdx = strpos($message, $key);
      if ($startIdx == false)
         return false;

      $key = "value=";
      $startIdx = strpos($message, $key, $startIdx);
      if ($startIdx == false)
         return false;

      $startIdx += strlen("value=");
      $key = "/>";
      $endIdx = strpos($message, $key, $startIdx);
      if ($endIdx == false)
         return false;

      $value = substr($message, $startIdx, $endIdx - $startIdx);
      $found = true;
      $startIdx = 0;
      $endIdx = 0;
      while ($found == true)
      {
         $endIdx = strpos($value, ",", $startIdx);
         if ($endIdx  == false)
            $found = false;

         $lineNum++;
         $startIdx = $endIdx + 1;
      }
   }
   return $lineNum;
}

function getBandList($bandListStr, $bandCount)
{
   $list = array();
   for ($x = 0; $x < $bandCount; $x++)
      $list[$x] = false;      

   $startIdx = 0;
   $endIdx = 0;
   $lineNum = 1;
   $found = true;
   while ($found == true)
   {
      $endIdx = strpos($bandListStr, ",", $startIdx);
      if ($endIdx == false)
      {
         $found = false;
         $endIdx = strlen($bandListStr); 
      }

      $seg = substr($bandListStr, $startIdx, $endIdx - $startIdx);
      $dashPos = strpos($seg, "-", 0);
      if ($dashPos != false)
      {
         $numBeg = substr($seg, 0, $dashPos);
         $dashPos++;
         $numEnd = substr($seg, $dashPos);
         for ($x=$numBeg-1; $x < $numEnd; $x++)
            $list[$x] = true;
      }
      else   
         $list[$seg - 1] = true;

      $startIdx = $endIdx + 1;
   }

   return $list;
}


function createBandList($bandArray, $totalBands)
{
   $list = "";

   $startRange = -1;
   for ($x = 0; $x < $totalBands; $x++)
   {
      if ($bandArray[$x] == true)
      {
         if ($x + 1 == $totalBands ||
            ($x + 1 < $totalBands && $bandArray[$x+1] == false) )
         {
            if (strlen($list) > 0)
               $list = $list.",";

            $band = $x + 1;
            if ($startRange < 0)
               $list = $list.$band;
            else
               $list = $list.$startRange."-".$band;

            $startRange = -1;
         }
         else if ($x + 1 < $totalBands && $startRange < 0)
         {
            $startRange = $x + 1;
         }
      }
   }
   return $list;
}


function addBandSet($name, $bandList, $bin, $active)
{
   $success = false;

   if (getXmlBandSetEntry($name, $bin) == false)
   {  
      $filename = BAND_SELECTOR_FILE;
      $handle = fopen($filename, 'r');
      if ($handle)
      {
         $message = fread($handle, 20000);
         fclose($handle);

         $startPos = strpos($message, "</set>") ; 
          if($startPos > 0 )
         {
            $message = substr($message, 0, $startPos);
            $message = $message."   <bandSet>\n";
            $message = $message."      <name>".$name."</name>\n";
            $message = $message."      <bands>".$bandList."</bands>\n";
            $message = $message."      <binning>".$bin."</binning>\n";
            $message = $message."      <active>".$active."</active>\n";
            $message = $message."   </bandSet>\n";
            $message = $message."</set>\n";

            $handle = fopen($filename, 'w');
            if ($handle)
            {
               fwrite($handle, $message);
               fclose($handle);

               $success = true;
            }
         }
      }
   }
   return $success;
}

function changeBandSet($name, $bandList, $bin)
{
   $success = false;

   if (getXmlBandSetEntry($name, $bin) == true)
   {  
      $filename = BAND_SELECTOR_FILE;
      $handle = fopen($filename, 'r');
      if ($handle)
      {

         $message = fread($handle, 20000);
         fclose($handle);
         
         $fileStr = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
         $fileStr = $fileStr."<set>\n";

         $index = 0;
         $bandSet = getParam($message, "bandSet", $index);

         while ($bandSet != false)
         {

            $n = getParam($bandSet, "name", 0);
            $b = getParam($bandSet, "binning", 0);
            $a = getParam($bandSet, "active", 0);
            if (strcasecmp($name, $n) == 0 && $bin == $b)
            {
               $fileStr = $fileStr."   <bandSet>\n";
               $fileStr = $fileStr."      <name>".$name."</name>\n";
               $fileStr = $fileStr."      <bands>".$bandList."</bands>\n";
               $fileStr = $fileStr."      <binning>".$bin."</binning>\n";
               $fileStr = $fileStr."      <active>".$a."</active>\n";
               $fileStr = $fileStr."   </bandSet>\n";
            }
            else
            {
               $bandSet = trim($bandSet);
               $fileStr = $fileStr."   <bandSet>\n";
               $fileStr = $fileStr."      ".$bandSet."\n";
               $fileStr = $fileStr."   </bandSet>\n";
            }

            $index++;
            $bandSet = getParam($message, "bandSet", $index);

         }

         $fileStr = $fileStr."</set>\n";

         $handle = fopen($filename, 'w');
         if ($handle)
         {
            fwrite($handle, $fileStr);
            fclose($handle);
            $success = true;
         }
      }
   }
   return $success;
}


function getXmlBandSetEntry($name, $selectedBinning)
{
   $filename = BAND_SELECTOR_FILE;
   $handle = fopen($filename, 'r');
   $index = 0;
   $found = false;
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);

      $bandSet = getParam($message, "bandSet", $index);
      while ($bandSet != false)
      {
         $binning = getParam($bandSet, "binning", 0);
         if ($binning != false && $binning == $selectedBinning)
         {
            $n = getParam($bandSet, "name", 0);
            if ($n != false && $n == $name)
            {
               $found = true;
               break;
            }
         }
         $index++;
         $bandSet = getParam($message, "bandSet", $index);
      }
   }

   if ($found == true)
      return $bandSet;
   else
      return false;
}

function deleteBandSet($name, $bin)
{
   $success = false;

   if (getXmlBandSetEntry($name, $bin) == true)
   {  
      $filename = BAND_SELECTOR_FILE;
      $handle = fopen($filename, 'r');
      if ($handle)
      {
         $message = fread($handle, 20000);
         fclose($handle);
         
         $fileStr = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
         $fileStr = $fileStr."<set>\n";

         $index = 0;
         $bandSet = getParam($message, "bandSet", $index);
         while ($bandSet != false)
         {
            $n = getParam($bandSet, "name", 0);
            $b = getParam($bandSet, "binning", 0);
            if (strcasecmp($name, $n) != 0 || $bin != $b)
            {
               $bandSet = trim($bandSet);
               $fileStr = $fileStr."   <bandSet>\n";
               $fileStr = $fileStr."      ".$bandSet."\n";
               $fileStr = $fileStr."   </bandSet>\n";
            }

            $index++;
            $bandSet = getParam($message, "bandSet", $index);
         }

         $fileStr = $fileStr."</set>\n";

         $handle = fopen($filename, 'w');
         if ($handle)
         {
            fwrite($handle, $fileStr);
            fclose($handle);
            $success = true;
         }
      }
   }
   return $success;
}
?>