<?php
include_once("../ih_scripts.php");
include_once("cameraConfig_scripts.php");

/* Enable this code if you want to see the posted variables and their values.
$post = "";
foreach ($_REQUEST as $key => $value)
{
   if (is_array($value))
   {
      foreach($value as $item)
         $post = $post . $key . "=" . $item . "<br>";
   }
   else
   {
      $post = $post . $key . "=" . $value . "<br>";
   }
}
echo "$post<p>";
*/

include 'cameraConfig_vars.php';
$pause_ = 0;
$changedProfile = $_POST['changedProfile'];
$profileName = $_POST['profileName'];
$vnirExposure = $_POST['vnirExposure'];
$vnirFrameRate = $_POST['vnirFrameRate'];
$swirExposure = $_POST['swirExposure'];
$swirFrameRate = $_POST['swirFrameRate'];
$rotaryScanRate = $_POST['rotaryScanRate'];
$accumulateCount = $_POST['accumulateCount'];

if (strcmp($changedProfile, "false") == 0)
{
   $accumulateCount_ = $_SESSION['accumulateCount_'];
   if (is_numeric($accumulateCount) && $accumulateCount > 0 && $accumulateCount != $accumulateCount_)
   {
      SetTemporalBinCount($profileName, $accumulateCount);
   }
   
   $swirRate_ = $_SESSION['swirRate_'];
   if ($swirFrameRate != -1 && $swirFrameRate != $swirRate_)
   {
      //check for maximum values based on the height
      $maxRate = getStatusValue("page.config.swir.maxRate", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
      
      if (floatval($swirFrameRate) > $maxRate)
      {
         echo "<h3>SWIR maximum frame rate is $maxRate</h3><br>";
         $pause_ = $pause_ + 5;
         $swirFrameRate = $maxRate;
      }

      $value = SetSwirRate($profileName, $swirFrameRate);
      if ($value == -3)
      {
         echo "<h3>Environmental variable 'PROFILE_HOME' not set.</h3><br>";
      }
      else if ($value == -2)
      {
         echo "<h3>Missing key value pair for SWIR frame rate in 'swir_config.xml' in '${profileName}' profile.</h3><br>";
         $pause_ = $pause_ + 5;
      }
      else if ($value == -4)
      {
         echo "<h3>Unable to write to 'swir_config.xml' or 'swir.xml' in '${profileName}' profile.  Check File Permission</h3><br>";
         $pause_ = $pause_ + 5;
      }
   }

   //find the max exposure in milliseconds
   $maxExposure = 100000000;
   if ($swirFrameRate > 0)
   {
      $maxExposure = 1/$swirFrameRate - .000040;
      $maxExposure = $maxExposure*1000; 
   }
   
   if (isset($swirFrameRate) && round($swirExposure, 3) > round($maxExposure, 3))
   {
      $maxStr = sprintf("%.3f", $maxExposure);
      echo "<h3>SwirExposure ($swirExposure) can't exceed max of $maxStr</h3><br>";
      $swirExposure = $maxExposure;
      $pause_ = $pause_ + 5;
   }
   
   $swirExposure_ = $_SESSION['swirExposure_'];
   if ($swirExposure != $swirExposure_)
   {
      $value = SetSwirExposure($profileName, $swirExposure);
      if ($value == -3)
      {
         echo "<h3>Environmental variable 'PROFILE_HOME' not set.<br>";
      }
      else if ($value == -2)
      {
         echo "<h3>Missing key value pair for SWIR exposure in 'swir_config.xml' in '${profileName}' profile.</h3><br>";
         $pause_ = $pause_ + 5;
      }
      else if ($value == -4)
      {
         echo "<h3> Unable to write to 'swir_config.xml' in '${profileName}' profile.  Check File Permission </h3><br>";
         $pause_ = $pause_ + 5;
      }
   }

   $vnirRate_ = $_SESSION['vnirRate_'];
   if ($vnirFrameRate != -1 && $vnirFrameRate != $vnirRate_)
   {
      $maxRate = GetMaxVnirRate($profileName);
      if (floatval($vnirFrameRate) > $maxRate)
      {
         echo "<h3>VNIR maximum frame rate is $maxRate</h3><br>";
         $pause_ = $pause_ + 5;
         $vnirFrameRate = $maxRate;
      }
     
      $value = SetVnirRate($profileName, $vnirFrameRate);
      if ($value == -3)
      {
         echo "<h3>Environmental variable 'PROFILE_HOME' not set.</h3><br>";
      }
      else if ($value == -2)
      {
         echo "<h3>Missing key value pair for VNIR frame rate in 'vnir_config.xml' in '${profileName}' profile.</h3><br>";
         $pause_ = $pause_ + 5;
      }
      else if ($value == -4)
      {
         echo "<h3>Unable to write to 'vnir_config.xml' or 'vnir.xml' in '${profileName}' profile.  Check File Permission</h3><br>";
         $pause_ = $pause_ + 5;
      }
   }

   $maxExposure = GetMaxVnirExposure($vnirFrameRate);
   if (round($vnirExposure, 3) > round($maxExposure, 3))
   {
      $maxStr = sprintf("%.3f", $maxExposure);
      echo "<h3>VnirExposure ($vnirExposure) can't exceed max of $maxStr</h3><br>";
      $vnirExposure = $maxExposure;
      $pause_ = $pause_ + 5;
   }
   
   $vnirExposure_ = $_SESSION['vnirExposure_'];
   if ($vnirExposure != $vnirExposure_)
   {
      $value = SetVnirExposure($profileName, $vnirExposure);
      if ($value == -3)
      {
         echo "<h3>Environmental variable 'PROFILE_HOME' not set.<br>";
      }
      else if ($value == -2)
      {
         echo "<h3>Missing key value pair for VNIR exposure in 'vnir_config.xml' in '${profileName}' profile.</h3><br>";
         $pause_ = $pause_ + 5;
      }
      else if ($value == -4)
      {
         echo "<h3> Unable to write to 'vnir_config.xml' in '${profileName}' profile.  Check File Permission </h3><br>";
         $pause_ = $pause_ + 5;
      }
   }

   $useRotary = getStatusValue("page.config.rotary.use", $_SERVER['DOCUMENT_ROOT']."/corning/interfaceConfig.xml");
   $curRotaryScanRate = $_SESSION['rotaryScanRate_'];
   if (stristr($useRotary, "true") && $rotaryScanRate != $curRotaryScanRate)
   {
      $value = SetXmlProperty($profileName, "rotary.scan.rate", $rotaryScanRate);
      if ($value == -3)
      {
         echo "<h3>Environmental variable 'PROFILE_HOME' not set.<br>";
      }
      else if ($value == -2)
      {
         echo "<h3>Missing key value pair for 'rotaty.scan.rate' in 'parameters.xml' file.</h3><br>";
         $pause_ = $pause_ + 5;
      }
      else if ($value == -4)
      {
         echo "<h3> Unable to write 'rotary.scan.rate' to 'parameters.xml' file. Check File Permission </h3><br>";
         $pause_ = $pause_ + 5;
      }
   }
}
$_SESSION['profile_'] = $profileName;

$_SESSION['pause_'] = $pause_;
echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=cameraConfig.html'\>";
?> 