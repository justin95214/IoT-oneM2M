<?php
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/../ih_defines.php");
include_once("config_scripts.php");

/*	===========================================================================
*  This method retrieves the property for use raw imagery from the xml
* parameters.xml file.  This property indicates that the system should
* save raw imagery to disk.
* @return - true if selected for use.  False if not.
*/
function getUseRawImage()
//	=========================================================================== 
{
   $key = "vnir.rawData.save";
   $use = "false";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
      $use = getProperty("ih", $key);
   else
      $use = GetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key);

   return $use;
}

/*	===========================================================================
*  This method sets the property for use raw imagery from the xml
* parameters.xml file.  This property indicates that the system should
* save raw imagery to disk.
* @use - true if selected for use.  False if not.
*/
function setUseRawImage($use)
//	=========================================================================== 
{
   $key = "vnir.rawData.save";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
   {
      $props[0][0] =  $key;
      $props[0][1] = $use;
      setProperty("ih", $props);
   }
   SetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key, $use);
}

/*	===========================================================================
*  This method retrieves the property for use raw nav from the xml
*  parameters.xml file.  This property indicates that the system should
*  save navigation data in the raw imagery folder.
*  @return - true if selected for use.  False if not.
*/
function getUseRawNav()
//	=========================================================================== 
{
   $key = "vnir.rawNavData.save";
   $use = "false";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
      $use = getProperty("ih", $key);
   else
      $use = GetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key);

   return $use;
}

/*	===========================================================================
*  This method sets the property for use raw nav from the xml
* parameters.xml file.  This property indicates that the system should
* save the navigation files associated with the raw imagery to disk.
* @use - true if selected for use.  False if not.
*/
function setUseRawNav($use)
//	=========================================================================== 
{
   $key = "vnir.rawNavData.save";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
   {
      $props[0][0] =  $key;
      $props[0][1] = $use;
      setProperty("ih", $props);
   }

   SetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key, $use);
}

/*	===========================================================================
*  This method retrieves the property for use raw imagery from the xml
* parameters.xml file.  This property indicates that the system should
* save calibrated imagery to disk.
* @return - true if selected for use.  False if not.
*/
function getUseCalImage()
//	=========================================================================== 
{
   $key = "vnir.calData.save";
   $use = "false";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
      $use = getProperty("ih", $key);
   else
      $use = GetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key);

   return $use;
}

/*	===========================================================================
*  This method sets the property for use cal imagery from the xml
* parameters.xml file.  This property indicates that the system should
* save raw imagery to disk.
* @use - true if selected for use.  False if not.
*/
function setUseCalImage($use)
//	=========================================================================== 
{
   $key = "vnir.calData.save";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
   {
      $props[0][0] =  $key;
      $props[0][1] = $use;
      setProperty("ih", $props);
   }
   SetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key, $use);
}

/*	===========================================================================
*  This method retrieves the property for use calibrated nav from the xml
*  parameters.xml file.  This property indicates that the system should
*  save navigation data in the calibrated imagery folder.
*  @return - true if selected for use.  False if not.
*/
//	=========================================================================== 
function getUseCalNav()
{
   $key = "vnir.calNavData.save";
   $use = "false";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
      $use = getProperty("ih", $key);
   else
      $use = GetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key);

   return $use;
}
         
/*	===========================================================================
*  This method sets the property for use cal nav from the xml
* parameters.xml file.  This property indicates that the system should
* save the navigation files associated with the raw imagery to disk.
* @use - true if selected for use.  False if not.
*/
function setUseCalNav($use)
//	=========================================================================== 
{
   $key = "vnir.calNavData.save";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
   {
      $props[0][0] =  $key;
      $props[0][1] = $use;
      setProperty("ih", $props);
   }
   SetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key, $use);
}


/*	===========================================================================
*  This method retrieves the property for use select imagery from the xml
* parameters.xml file.  This property indicates that the system should
* save imagery with selected bands to disk.
* @return - true if selected for use.  False if not.
*/
function getUseSelectImage()
//	=========================================================================== 
{
   $key = "vnir.selectData.save";
   $use = "false";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
      $use = getProperty("ih", $key);
   else
      $use = GetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key);

   return $use;
}

/*	===========================================================================
*  This method sets the property for use select imagery from the xml
* parameters.xml file.  This property indicates that the system should
* save selected band imagery to disk.
* @use - true if selected for use.  False if not.
*/
function setUseSelectImage($use)
//	=========================================================================== 
{
   $key = "vnir.selectData.save";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
   {
      $props[0][0] =  $key;
      $props[0][1] = $use;
      setProperty("ih", $props);
   }
   SetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key, $use);
}

/*	===========================================================================
*  This method retrieves the property for use selected nav from the xml
*  parameters.xml file.  This property indicates that the system should
*  save navigation data in the selected band imagery folder.
*  @return - true if selected for use.  False if not.
*/
//	=========================================================================== 
function getUseSelectNav()
//	=========================================================================== 
{
   $key = "vnir.selectNavData.save";
   $use = "false";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
      $use = getProperty("ih", $key);
   else
      $use = GetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", $key);

   return $use;
}

/*	===========================================================================
*  This method sets the property for use select nav from the xml
* parameters.xml file.  This property indicates that the system should
* save the navigation files associated with the select band imagery to disk.
* @use - true if selected for use.  False if not.
*/
function setUseSelectNav($use)
//	=========================================================================== 
{
   $key = "vnir.selectNavData.save";
   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
   {
      $props[0][0] =  $key;
      $props[0][1] = $use;
      setProperty("ih", $props);
   }

   SetXmlValueFile("C:\\CorningHsi\\config\\parameters.xml", "vnir.selectNavData.save", $use);
}

?>
