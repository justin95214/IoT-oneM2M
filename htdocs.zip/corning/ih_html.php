<?php
include_once("ih_defines.php");

function showImage($color)
{
	switch($color)
	{
		case 'green':
			echo "<img src=\"../images/green.gif\" alt=\"Green\" />\n";
			break;
		case 'red':
			echo "<img src=\"../images/red.gif\" alt=\"Red\" />\n";
			break;
		case 'yellow':
			echo "<img src=\"../images/yellow.gif\" alt=\"Yellow\" />\n";
			break;
	}
}
?>