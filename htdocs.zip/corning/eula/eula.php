<?php

require_once("../ih_defines.php");
require_once("../ih_scripts.php");
require_once("../SensorClass.php");

function rrmdir($dir)
{
   //Careful not to delete everything 
   if (strstr($dir, "C:/CorningHsi/") && is_dir($dir))
   { 
      $objects = scandir($dir); 
      foreach ($objects as $object)
      { 
         if ($object != "." && $object != "..")
         { 
            if (filetype($dir."/".$object) == "dir")
               rrmdir($dir."/".$object); 
            else
               unlink($dir."/".$object); 
         } 
     } 
     reset($objects); 
     rmdir($dir); 
   } 
} 

//	Determine sensor type
$sensor = $_POST["sensor"];
	
// Retrieve variables
$eulaReponse = $_POST["eulaResponse"];

if ($eulaReponse == "Accept")
{
   $status = getEulaState();
   if ($status == "New")
   {
      $filePath = "C:/CorningHsi/htdocs/corning/eula/status.txt";
      $date = date("F j, Y, g:i a");                 
      $accepted = "Accepted $date\n";
      $handle = fopen($filePath, "w");
      $fileContents = fwrite($handle, $accepted);
      fclose($handle);

      echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=/corning/control/control_system.html'\>";
   }
   else if ($status == "Declined")
   {
      echo "EULA previously declined<br>";
   } 
   else if ($status == "Accepted")
   {
      //previously accepted
      echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=/corning/control/control_system.html'\>";
   }
 
echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=/corning/control/control_system.html'\>";
}

if ($eulaReponse == "Decline")
{
   echo "EULA has been declined<br>";

   rrmdir("C:/CorningHsi/bin");

   $filePath = "C:/CorningHsi/htdocs/corning/eula/status.txt";
   $date = date("F j, Y, g:i a");                 
   $declined = "Declined $date\n";
   $handle = fopen($filePath, "w");
   $fileContents = fwrite($handle, $declined);
   fclose($handle);
}
?>