<?php
/*	===========================================================================
*  This method opens an event tracks XML file. 
*  It then reads the file, parses the event information and echos it
*  so it can be included in the eventViewer.jnlp file.
*  @param $fileName - this is the name and path of the event tracks XML file.
*  @return -   0 on success, -1 if the file does not exist, 
*              -2 if the file could not be opened.
*/
function addIpAddress($line, $jnplOutHandle)
//	===========================================================================
{
   $pos = strpos($line, "<!--add IP address-->");
   $str1 = substr($line, 0, $pos);
   fwrite($jnplOutHandle, $str1);

   $srvAddr = $_SERVER['SERVER_ADDR'];
   if (strcmp($srvAddr, "127.0.0.1") == 0 || strcmp($srvAddr, "::1") == 0)
      $srvAddr = "Localhost";

   fwrite($jnplOutHandle, $srvAddr);

   $pos += strlen("<!--add IP address-->");
   $str2 = substr($line, $pos);
   fwrite($jnplOutHandle, $str2);
}


/*	===========================================================================
*  This method opens an event tracks XML file. 
*  It then reads the file, parses the event information and echos it
*  so it can be included in the eventViewer.jnlp file.
*  @param $fileName - this is the name and path of the event tracks XML file.
*  @return -   0 on success, -1 if the file does not exist, 
*              -2 if the file could not be opened.
*/
function parseEventsFileToJnlp($filename, $outFileHandle)
//	===========================================================================
{  
   $returnVal = 0;
   $paramLen = 0;

   if (file_exists($filename))
   {
      $file = fopen($filename, "r");
      if ($file)
      {
         $data = fread($file, 20000);
         fclose ($file);
         $fov = getXmlField2($data, "fov");
         if (strlen($fov) > 0)
         {
            $paramStr = "      <fx:param name=\"fov\" value=\".$fov.\"/>\r\n";
            fwrite($outFileHandle, $paramStr);
            $paramLen += strlen($paramLen);
         }
         $x = 1;
         while(($track = getXmlField2Ex($data, "track", $x)) == true)
         {
            $name = getXmlField2($track, "name");
            $units = getXmlField2($track, "units");
            $leadin = getXmlField2($track, "leadin");
            
            $i = 1;
            $latLonStr = "";
            while(($latlon = getXmlField2Ex($track, "latlon", $i)) == true)
            {
               if ($i > 1)
                  $latLonStr .= ',';
               $latLonStr .= $latlon; 
               $i++;
            }
            
            if ($name && $latLonStr)
            {
               $paramStr = "      <fx:param name=\"track".$x."_name\" value=\"$name\"/>\r\n";
               fwrite($outFileHandle, $paramStr);
               $paramLen += strlen($paramLen);
               if (strlen($units) > 0)
               {
                  $paramStr = "      <fx:param name=\"track".$x."_units\" value=\"$units\"/>\r\n";
                  fwrite($outFileHandle, $paramStr);
                  $paramLen += strlen($paramLen);
               }
               
               if (strlen($leadin) > 0)
               {
                  $paramStr = "      <fx:param name=\"track".$x."_leadIn\" value=\"$leadin\"/>\r\n";
                  fwrite($outFileHandle, $paramStr);
                  $paramLen += strlen($paramLen);
               }
               
               $paramStr = "      <fx:param name=\"track".$x."_latlon\" value=\"$latLonStr\"/>\r\n";
               fwrite($outFileHandle, $paramStr);
               $paramLen += strlen($paramLen);
            }
            $x++;
         }
         $x = 1;
         while(($area = getXmlField2Ex($data, "area", $x)) == true)
         {
            $name = getXmlField2($area, "name");
            $color = getXmlField2($area, "color");

            $i = 1;
            $latLonStr = "";
            while(($latlon = getXmlField2Ex($area, "latlon", $i)) == true)
            {
               if ($i > 1)
                  $latLonStr .= ',';
               $latLonStr .= $latlon; 
               $i++;
            }
            if ($name && $latLonStr)
            {
               $paramStr = "      <fx:param name=\"area".$x."_name\" value=\"$name\"/>\r\n";
               fwrite($outFileHandle, $paramStr);
               $paramLen += strlen($paramLen);
               if (strlen($color) > 0)
               {
                  $paramStr = "      <fx:param name=\"area".$x."_color\" value=\"$color\"/>\r\n";
                  fwrite($outFileHandle, $paramStr);
                  $paramLen += strlen($paramLen);
               }
               $paramStr = "      <fx:param name=\"area".$x."_latlon\" value=\"$latLonStr\"/>\r\n";
               fwrite($outFileHandle, $paramStr);
               $paramLen += strlen($paramLen);
            }   
            $x++;
         }
      }
      else
         $returnVal = -2;

      // Check if file has been updated.  If so, ensure parameter size is different.
      // Bug with java webstart applications only reliably update jnlp files when its size is 
      // different from previous size.

      //We need to update only once per update of the web page.  I believe if the version
      //is mismatched between jar and jnlp, a second request to the server is done.
      $filename2 = "C:/Apache2.2/htdocs/novasol/sensor/Tools/metaEvent.xml";
      if (file_exists($filename2))
      {
         $file2 = fopen($filename2, "r");
         if ($file2)
         {
            $data = fread($file2, 1000);
            fclose ($file2);
            $index = (int)getXmlField2($data, "index");
            $lastFileTime = (int)getXmlField2($data, "fileTime");
            $lastParamSize = (int)getXmlField2($data, "paramSize");
         
            $fileTime = filemtime($filename);

            //if file has been updated but results in same size parameters 
            //add a parameter to change the size
            if ($fileTime != $lastFileTime && $paramLen == $lastParamSize)
            {
               $paramStr = "      <fx:param name=\"paramSize\" value=\"".$paramLen."\"/>\r\n";
               fwrite($outFileHandle, $paramStr);
            }

            if ($fileTime !== $lastFileTime && $index%2 == 1)
            {
               SetXmlValue2($filename2, "fileTime", $fileTime);   
               SetXmlValue2($filename2, "paramSize", $paramLen);
            }
            
            SetXmlValue2($filename2, "index", ++$index);
         }
      }
   }
   else
      $returnVal = -1;
      
   return $returnVal;
}

function getXmlField2($data, $tag)
{
   $stag = "<".$tag.">";
   $etag = "</".$tag.">";
   $i = strpos($data, $stag);
   $j = strpos($data, "$etag");
   if (($i >= 0) && ($j > $i))
   {
      $i = $i + strlen($tag) + 2;
      $value = substr($data, $i, $j-$i);
      return $value;
   }
   return false;
}
   
function getXmlField2Ex($data, $tag, $index)
{
   $stag = "<".$tag.">";
   $etag = "</".$tag.">";

   for ($x = 1; $x < $index; $x++)
   {
      $idx = strpos($data, $stag);
      if ($idx == false)
         return false;
      
      $data = substr($data, $idx + 1);
   }

   $i = strpos($data, "$stag");
   $j = strpos($data, "$etag", $i);
   if ($i && ($i >= 0) && $j && ($j > $i))
   {
      $i = $i + strlen($tag) + 2;
      $value = substr($data, $i, $j-$i);
      return $value;
   }
   return false;
}

/*	===========================================================================
*  This method opens an XML file within the given profile.
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetXmlValue2($filename, $key, $value)
/*	===========================================================================*/
{
   $returnValue = 1;
   $startTag = "<".$key.">";
   $endTag = "</".$key.">";

   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 4000);
      fclose($handle);

      $startInt = strpos($message, $startTag);
      if ($startInt)
      {
         $startInt += strlen($startTag);
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, $endTag, $startInt);
         $buf3 = substr($message, $endInt);

         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

   return $returnValue;
}
 
?>
   