// JavaScript Document

// ===================================================================
// ===================================================================
var request = null;

function createRequest()
{
	try{
		request = new XMLHttpRequest();
		//alert( "Request Object created" );
	}	catch( trymicrosoft ) {
		try{
			request = new ActiveXObject( "Msxml2.XMLHTTP" );
			//alert( "ActiveX Object created ... Msxml2" );
		}	catch( othermicrosoft ) {
			try{
				request = new ActiveXObject( "Microsoft.XMLHTTP" );
				//alert( "ActiveX Object created ... Microsoft" );
			}	catch( failed ) {
				request = null;
			}
		}
	}
	
	if( request == null ) {
		alert( "Error creating request object!" );
	}
}

// ===================================================================
function changeProfile(sensor)
// ===================================================================
{
	var url="control_SystemProfile.php";
	var data=null;
	
	//	String together the data that is needed
//	alert("Entered method");
	
	for(i=0; i<document.hsiProfiles.hsiRadio.length; ++i){
		if (document.hsiProfiles.hsiRadio[i].checked==true){
			option = i;
			break; //exist for loop, as target acquired.
		}
	}

	switch(sensor){
		case "hsi":
//			alert("Case HSI");
			data =	"sensor=" + sensor +	
						"&profile=" + document.hsiProfiles.hsiRadio[option].value;
//			alert(document.hsiProfiles.hsiRadio[option].value);
			break;
		case "pan":
			data =	"sensor=" + sensor + 
						"&profile=" + document.getElementById("panRadio").value;
			break;
		default: alert("Cannot execute command. Invalid sensor type.");
			return;
	}
	
	createRequest();

	try {
		request.open("POST", url, true);
		request.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

		switch(sensor){
			case "hsi":
				request.onreadystatechange = updateHSIProfile;
				break;
			case "pan":
				request.onreadystatechange = updatePANProfile;
				break;			
		}
		
		request.send(data);
   } catch (e) {
      alert("Exception:" + e);
      request = null;
   }     
}

// ===================================================================
function commandSensor(sensor, command)
// ===================================================================
{
	if(document.getElementById("sendTo").value == 0){
		//alert("sendTo = image");
		var url="control_Image.php";
	}
	else{
		//alert("sendTo = sensor");
		var url="control_Sensor.php";
	}
	var data=null;
	
	//	String together the data that is needed
	switch(sensor){
		case "hsi":
			data =	"sensor=" + sensor + "&command=" + command +	
						"&hsiHost=" + document.getElementById("hsiHost").value +
						"&hsiPort=" + document.getElementById("hsiPort").value +
						"&hsiTarget=" + document.getElementById("hsiTarget").value +
						"&hsiPass=" + document.getElementById("hsiPass").value +
						"&hsiRate=" + document.getElementById("hsiRate").value +
						"&calibrate=" + document.getElementById("calibrate").value;
			break;
		case "pan":
			data =	"sensor=" + sensor + "&command=" + command +	
						"&panHost=" + document.getElementById("panHost").value +
						"&panPort=" + document.getElementById("panPort").value +
						"&panTarget=" + document.getElementById("panTarget").value +
						"&panPass=" + document.getElementById("panPass").value;
			break;
		case "ih":
			data =	"sensor=" + sensor + "&command=" + command +	
						"&ihHost=" + document.getElementById("ihHost").value +
						"&ihPort=" + document.getElementById("ihPort").value +
						"&ihTarget=" + document.getElementById("ihTarget").value +
						"&ihPass=" + document.getElementById("ihPass").value +
						"&ihFOV=" + document.getElementById("ihFOV").value +
						"&ihScans=" + document.getElementById("ihScans").value +
						"&ihFrames=" + document.getElementById("ihFrames").value +
						"&calibrate=" + document.getElementById("calibrate").value;
			break;
		default: alert("Cannot execute command. Invalid sensor type.");
			return;
	}
/*	
	createRequest();

	try {
		request.open("POST", url, true);
		request.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

		switch(sensor){
			case "hsi":
				request.onreadystatechange = updateHSI;
				break;
			case "pan":
				request.onreadystatechange = updatePAN;
				break;
			case "ih":
				request.onreadystatechange = updateIH;
				break;
		}
		
		request.send(data);
   } catch (e) {
      alert("Exception:" + e);
      request = null;
   }
*/
}

// ===================================================================
function getMissionStatus()
// ===================================================================
{
	var url="status_mission.php";
	var data=null;
	
	createRequest();
	
	try {
		request.open("POST", url, true);
		request.setRequestHeader('Content-Type','text/xml');
		request.onreadystatechange = updateMissionStatus;
		request.send(data);
   } catch (e) {
      alert("Exception:" + e);
      request = null;
   }     
}

// ===================================================================
function updateIH()
// ===================================================================
{
	if( request.readyState == 4) {
		// Check the HTTP response status code to see if request was successful
		//	200 is the standard HTTP result code for success
		if( request.status != 200 ) {
			alert( "Communication error: " + request.responseText );
			return;
		}
		var message = request.responseText;
		var messgaeArray = message.split(";");
		
		if(messgaeArray[0])
		{
		   var newMessage = messgaeArray[0];
		   //strip of invalid leading chars
		   for(x = 0; x< 5; x++)
		   {
            if (newMessage.charAt(0) < '!')
   		      newMessage = newMessage.substring(1);
	      }	      
		   replaceText(document.getElementById("ihMessage"), newMessage);
		}
		else
		   replaceText(document.getElementById("ihMessage"), "");

		if(messgaeArray[1])
		   replaceText(document.getElementById("ihMessage1"), messgaeArray[1]);
		else
		   replaceText(document.getElementById("ihMessage1"), "");
		   
		if(messgaeArray[2])
		   replaceText(document.getElementById("ihMessage2"), messgaeArray[2]);
		else
		   replaceText(document.getElementById("ihMessage2"), "");
		   
		if(messgaeArray[3])
		   replaceText(document.getElementById("ihMessage3"), messgaeArray[3]);
		else
		   replaceText(document.getElementById("ihMessage3"), "");
		   
		if(messgaeArray[4])
		   replaceText(document.getElementById("ihMessage4"), messgaeArray[4]);
		else
		   replaceText(document.getElementById("ihMessage4"), "");
	}
}

// ===================================================================
function updateHSI()
// ===================================================================
{
/**
	if( request.readyState == 4) {
		// Check the HTTP response status code to see if request was successful
		//	200 is the standard HTTP result code for success
		if( request.status != 200 ) {
			alert( "Communication error: " + request.responseText );
			return;
		}
	
		var message = request.responseText;
		replaceText(document.getElementById("hsiMessage"), message);
	}
**/
}

// ===================================================================
function updateHSIProfile()
// ===================================================================
{
	if( request.readyState == 4) {
		// Check the HTTP response status code to see if request was successful
		//	200 is the standard HTTP result code for success
		if( request.status != 200 ) {
			alert( "Communication error: " + request.responseText );
			return;
		}
	
		var message = request.responseText;
		replaceText(document.hsiProfiles.hsiActiveProfile, message);
		request = null;
	}
}

// ===================================================================
function updateMissionStatus()
// ===================================================================
{
	if( request.readyState == 4) {
		// Check the HTTP response status code to see if request was successful
		//	200 is the standard HTTP result code for success
		if( request.status != 200 ) {
			alert( "Communication error: " + request.responseText );
			return;
		}

		var msg = request.responseText;
		
		//	Parse XML message to get status information
/*		var xmlDoc = request.responseXML;
		
		var hsiFrameCount = xmlDoc.getElementsByTagName("hsiFrameCount")[0];
		var hsiError = xmlDoc.getElementsByTagName("hsiError")[0];
		var hsiErrorText = xmlDoc.getElementsByTagName("hsiErrorText")[0];
		
		var panSnapCount = xmlDoc.getElementsByTagName("panSnapCount")[0];
		var panError = xmlDoc.getElementsByTagName("panError")[0];
		var panErrorText = xmlDoc.getElementsByTagName("panErrorText")[0];
*/		
		var hsiFrameCount = getField(msg, "hsiFrameCount");
		var hsiError = getField(msg, "hsiError");
		var hsiErrorText = getField(msg, "hsiErrorText");
		var hsiBitStatus = getField(msg, "hsiBitStatus");
		var hsiBitStatusText = getField(msg, "hsiBitStatusText");
		
		var panSnapCount = getField(msg, "panSnapCount");
		var panError = getField(msg, "panError");
		var panErrorText = getField(msg, "panErrorText");
		var panBitStatus = getField(msg, "panBitStatus");
		var panBitStatusText = getField(msg, "panBitStatusText");


		//	Update page with new status information
		var idHsiFrameCount = document.getElementById("framecount");
		var idHsiError = document.getElementById("hsierrors");
		var idHsiErrorText = document.getElementById("hsierrortext");
		var idHsiBitStatus = document.getElementById("hsibit");
		var idHsiBitStatusText = document.getElementById("hsibittext");
		
		var idPanSnapCount = document.getElementById("snapcount");
		var idPanError = document.getElementById("panerrors");
		var idPanErrorText = document.getElementById("panerrortext");
		var idPanBitStatus = document.getElementById("panbit");
		var idPanBitStatusText = document.getElementById("panbittext");


		replaceText(idHsiFrameCount, hsiFrameCount);
		replaceText(idHsiError, hsiError);
		replaceText(idHsiErrorText, hsiErrorText);
		replaceText(idHsiBitStatus, hsiBitStatus);
		replaceText(idHsiBitStatusText, hsiBitStatusText);		

		replaceText(idPanSnapCount, panSnapCount);
		replaceText(idPanError, panError);
		replaceText(idPanErrorText, panErrorText);
		replaceText(idPANBitStatus, panBitStatus);
		replaceText(idPanBitStatusText, panBitStatusText);		

		missionStatusCheck();
	}
}

function missionStatusCheck()
{
   if (document.getElementById("missionCheck").checked)     
   {
      getMissionStatus();
   }
}



// ===================================================================
function updatePAN()
// ===================================================================
{
	if( request.readyState == 4) {
		// Check the HTTP response status code to see if request was successful
		//	200 is the standard HTTP result code for success
		if( request.status != 200 ) {
			alert( "Communication error: " + request.responseText );
			return;
		}
	
		var message = request.responseText;
		replaceText(document.getElementById("panMessage"), message);
	}
}

// ===================================================================
function openWindow(url)
// ===================================================================
{
	window.open(url, 'newWin', 'toolbar=no,location=no,scrollbars=yes,menubar=no,resizable=no,width=550,height=300');
}


// ===================================================================
function openWindow2(url, name, width, height)
// ===================================================================
{
   var props = 'toolbar=no,location=no,scrollbars=yes,menubar=no,resizable=no,width=' + width + ',height=' + height;
   window.open(url, name, props);
}

// ===================================================================
function openWindow3(url, name, width, height, left, top)
// ===================================================================
{
   var props = 'toolbar=no,titlebar=no,location=no,scrollbars=no,menubar=no,\
                resizable=no,status=no,directories=no,width=' + width + 
                ',height=' + height + ',left=' + left + ',top=' + top;
   window.open(url, name, props);
}

// ===================================================================
function SetAllCheckBoxes(FormName, FieldName, CheckValue)
// ===================================================================
{
	if(!document.forms[FormName])
		return;
		
	var objCheckBoxes = document.forms[FormName].elements[FieldName];
	if(!objCheckBoxes)
		return;
		
	var countCheckBoxes = objCheckBoxes.length;
	if(!countCheckBoxes)
		objCheckBoxes.checked = CheckValue;
	else
		// set the check value for all check boxes
		for(var i = 0; i < countCheckBoxes; i++)
			objCheckBoxes[i].checked = CheckValue;
}

// ===================================================================
function replaceText(el, text)
// ===================================================================
{
  if (el != null) {
    clearText(el);
    var newNode = document.createTextNode(text);
    el.appendChild(newNode);
  }
}

// ===================================================================
function clearText(el)
// ===================================================================
{
  if (el != null) {
    if (el.childNodes) {
      for (var i = 0; i < el.childNodes.length; i++) {
        var childNode = el.childNodes[i];
        el.removeChild(childNode);
      }
    }
  }
}

// ===================================================================
function getText(el)
// ===================================================================
{
  var text = "";
  if (el != null) {
    if (el.childNodes) {
      for (var i = 0; i < el.childNodes.length; i++) {
        var childNode = el.childNodes[i];
        childNode.normalize();
        if (childNode.nodeType == Node.TEXT_NODE) {
          text = text + childNode.data;
        }
      }
    }
  }
  return text;
}

// ===================================================================
function getField(xmlData, fieldName)
// ===================================================================
{
  var value = "";
  var i = xmlData.indexOf("<" + fieldName + ">");
  if (i >= 0)
  {
     i += (fieldName.length + 2);
     var j = xmlData.indexOf("</" + fieldName + ">");
     if (j > i)
     {
        value = xmlData.substr(i, j-i);
     }
  }
  //alert("The value of field " + fieldName + " is " + value);
  return value;
} 