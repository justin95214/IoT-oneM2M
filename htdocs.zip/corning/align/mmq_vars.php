<?php
if(!isset($_SESSION)) 
{ 
   session_start(); 
}  

if (!isset($_SESSION['pause_']))
	$_SESSION['pause_'] = "0";
   
if (!isset($_SESSION['groundHeading_']))
	$_SESSION['groundHeading_'] = "0";

if (!isset($_SESSION['alignType_']))
	$_SESSION['alignType_'] = "ground";

if (!isset($_SESSION['headingRef_']))
	$_SESSION['headingRef_'] = "magnetic";
  
?>