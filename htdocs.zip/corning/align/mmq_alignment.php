<?php
include_once("../ih_scripts.php");

/* Enable this code if you want to see the posted variables and their values.
$post = "";
foreach ($_REQUEST as $key => $value) {
   if (is_array($value))
   {
      foreach($value as $item)
         $post = $post . $key . "=" . $item . "<br>";
   }
   else
   {
      $post = $post . $key . "=" . $value . "<br>";
   }
}
echo "$post<p>";
*/

/*	===========================================================================
*  This method opens an XML file within the given profile. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $path - this is the name of the profile to view.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetXmlValue($path, $fileName, $key, $value)
//	===========================================================================
{
   $returnValue = 1;
   if (!$path)
      $returnValue = -3;

   $filename = sprintf("%s\\%s", $path, $fileName);
   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 4000);
      fclose($handle);
   
      //find the frame rate
      $key = "\"$key\"";
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\"", $startInt);
         $buf3 = substr($message, $endInt);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

	return $returnValue;
}

include 'mmq_vars.php';
$alignType = $_POST['alignType'];
$doAlignment = $_POST['doAlignment'];
$autoAlign = $_POST['autoAlign'];
$headingHold = $_POST['headingHold'];

$headingHold = $headingHold ? "true" : "false";
$autoAlign = $autoAlign ? "true" : "false";

$groundHeading = 0;
$pause = 0;
$heading = 0;
$isMagnetic = "true";
$isError = false;

$groundHeading = $_POST['groundHeading'];
if ($groundHeading >= 0 && $groundHeading <= 360)
{
   $headingRef = $_POST['headingRef'];
   $heading = $groundHeading;
   if (strcmp($headingRef, "magnetic") != 0)
      $isMagnetic = "false";
}
else
{
   $isError = true;
   $pause += 5;
   echo "<h3>Heading Error: valid range is from 0 to 360 degrees</h3>";
}

if (IsPropServerRunning("ih"))
{
   if ($isError == false && strcmp($doAlignment, "true") == 0)
   {
      if ($alignType == "air")
      {
         $propArray[0][0] = "mmq_nav.align.type";     $propArray[0][1] = $alignType;
         $propArray[1][0] = "mmq_nav.align.reset";    $propArray[1][1] = "true";
      }
      else if ($alignType == "ground")
      {
         $propArray[0][0] = "mmq_nav.align.type";           $propArray[0][1] = $alignType;
         $propArray[1][0] = "mmq_nav.align.heading";        $propArray[1][1] = $heading;
         $propArray[2][0] = "mmq_nav.align.mag";            $propArray[2][1] = $isMagnetic;
         $propArray[3][0] = "mmq_nav.align.reset";          $propArray[3][1] = "true";
         $propArray[4][0] = "mmq_nav.align.heading.hold";   $propArray[4][1] = $headingHold;          
         SetXmlValue("C:\\config", "parameters.xml", "mmq_nav.align.heading", $heading);
         SetXmlValue("C:\\config", "parameters.xml", "mmq_nav.align.mag", $isMagnetic);
      }
      SetProperty("ih", $propArray);
      $profiles = GetProfile("ih", "active");
      SetXmlValue("C:/config", "parameters.xml", "mmq_nav.align.heading", $heading);

      echo "<h3>Alignment starting</h3>";
      $pause += 5;
   }
   else if ($isError == false)
   {
      $profiles = GetProfile("ih", "active");

      $propArray[0][0] = "mmq_nav.align.type";           $propArray[0][1] = $alignType;
      $propArray[1][0] = "mmq_nav.align.auto";           $propArray[1][1] = $autoAlign;
      $propArray[2][0] = "mmq_nav.align.heading";        $propArray[2][1] = $heading;
      $propArray[3][0] = "mmq_nav.align.mag";            $propArray[3][1] = $isMagnetic;
      $propArray[4][0] = "mmq_nav.align.heading.hold";   $propArray[4][1] = $headingHold;          
      SetXmlValue("C:\\config", "parameters.xml", "mmq_nav.align.auto", $autoAlign);
      SetXmlValue("C:\\config", "parameters.xml", "mmq_nav.align.heading", $heading);
      SetXmlValue("C:\\Config", "parameters.xml", "mmq_nav.align.type", $alignType);
      SetXmlValue("C:\\config", "parameters.xml", "mmq_nav.align.mag", $isMagnetic);
      
      SetProperty("ih", $propArray);
   }
}
else
{
   //record the values in paramters.xml even if property server not running
   if ($isError == false)
   {
      SetXmlValue("C:\\config", "parameters.xml", "mmq_nav.align.auto", $autoAlign);
      SetXmlValue("C:\\config", "parameters.xml", "mmq_nav.align.heading", $heading);
      SetXmlValue("C:\\Config", "parameters.xml", "mmq_nav.align.type", $alignType);
      SetXmlValue("C:\\config", "parameters.xml", "mmq_nav.align.mag", $isMagnetic);
   }

   echo "<h3>Error: property server not running</h3>";
   $pause += 5;
}

$_SESSION['headingRef_'] = $headingRef;
$_SESSION['alignType_'] = $alignType;
$_SESSION['groundHeading_'] = $groundHeading;
$_SESSION['pause_'] = $pause;

if ($isError == false && strcmp($doAlignment, "true") == 0)
{
   $_SESSION['pause_'] = 0;
   echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=../Status/status.html'\>";
}
else
{
   $_SESSION['pause_'] = $pause;
   echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=mmq_alignment.html'\>";
}
?>
