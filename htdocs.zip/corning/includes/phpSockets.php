<?php
class phpSockets
{
	//! Class variables.
	//! @param $hSocketOpen Stores the returned file pointer after a socket has been
	//! successfully opened
	private $hSocketOpen;
	//! @param $iErrno Stores the error number returned by methods
	private $iErrno;
	//! @param $iPort Port number to connect to
	private $iPort;
	//! @param $stBuffer Stores incoming messages
	private $stBuffer;
	//! @param $stErrStr Stores error message returned by methods
	private $stErrStr;
	//! @param $stHost Name of target machine
	private $stHost;

//! Constructor.
//! @param $phpHost Server name
//! @param $phpPort	Port number to connect to
//! @return NONE

	function phpSockets( $stHost, $iPort )
	{
		$this->stHost = $stHost;
		$this->iPort = $iPort;
		$this->hSocketOpen = NULL;
		$this->stErrStr = "No errors.";
	}

//! Closes the socket connection if a socket was previously established.
//! @return 0: If the socket has been successfully closed, -1: On socket failure

	public function CloseSocket()
	{
		if( $this->hSocketOpen )
		{
			@ $value = fclose( $this->hSocketOpen );

			if( !$value ) {
				return -1;
			}
			else {
				return 0;
			}
		}
		return 0;
	}

//! Returns the error message set by the last called method.
//! @return Returns the error message.

	public function GetErrorMessage()
	{
		return $this->stErrStr;
	}

//! Returns the name of the server that a socket connection has been established with.
//! @return Returns the host name.

	public function GetHostName()
	{
		return $this->stHost;
	}

//! Returns the port number that the socket is connected on.
//! @ return Returns the port number.

	public function GetPortNumber()
	{
		return $this->iPort;
	}

//! Opens an Internet or Unix domain socket.
//! @param $timeout	The amount of time allowed for a socket connection to be established
//! @return 0: If a socket connection was successfully established, -1: On socket failure

	public function OpenSocket( $iTimeout )
	{
		$this->hSocketOpen = fsockopen( $this->stHost, $this->iPort, $this->iErrno, $this->stErrStr, $iTimeout );

		if (!$this->hSocketOpen) {
			return -1;
		}
  		return 0;
	}

//! sets the read and write timeout for the socket.
//! @param $timeout	The amount of time in secondts to read or write.
//! @return 0: If successfully set, -1: On failure
	public function setTimeout( $iTimeout )
	{
	   $isSet = stream_set_timeout($this->hSocketOpen, $iTimeout); 

		if (!$isSet) {
			return -1;
		}
  		return 0;
	}


//! Receives incoming messages over the socket, assuming a socket connection has been
//! established.
//! @return	The contents of what was read from the socket

	public function ReceiveMessage()
	{
		$this->stBuffer = fgets( $this->hSocketOpen, 4096 );
		return $this->stBuffer;
	}

//! Receives incoming messages over the socket, assuming a socket connection has been
//! established.
//! @return	NONE

   public function ReadMessage()
	{
		$this->stBuffer = fread( $this->hSocketOpen, 4096 );

		return $this->stBuffer;
	}

//! Sends message over the socket, assuming a socket connection has been established.
//! @param $message Message that will be sent over the socket.
//! @return TRUE if the message has been successfully sent over the socket.  Otherwise,
//! the return value is FALSE.

	public function SendMessage( $message )
	{
		if( $this->hSocketOpen )
		{
			$success = fwrite( $this->hSocketOpen, $message, strlen($message) );

			if( !$success )
			{
				$this->stErrStr = "Failed to send message over socket.";
				return -1;
			}
			else
				return 0;
		}
		else
		{
			$this->stErrStr = "Socket not open.";
			return -1;
		}
	}
}
?>