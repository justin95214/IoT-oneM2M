<?php
/*COPYRIGHT (c) 2003-2005 by Innovative Technical Solutions, Inc.

                   All Rights Reserved.

                       N O T I C E

Under Federal copyright law, neither the software nor accompanying
documentation may be copied, photocopied, reproduced, translated,
or reduced to any electronic medium or machine-readable form, in
whole or in part, without the prior written consent of Innovative
Technical Solutions Inc., except in the manner described in the
documentation.
*/
?>
<?php
include_once("phpSockets.php");
?>

<?php
class phpPropServer
{
//! Public class variables
	//! @param $pSocket Pointer to an open socket.
	public $pSocket = null;
	//! @param $iCount Used with GetAllProperties to keep track of how many properties
	//! reside in the property server
	public $iCount = 0;

//! Private class variables
	//! @param $aArray A two-dimensional array that stores the names of the
	//! parameters in the $aArray[i][0] and the values of those parameters in
	//! $aArray[i][1] where i equals the cell number.  For use when retrieving
	//! all properties from the property server.
	private $aArray = null;
	//! @param $bSocketOpen Boolean value to indicate whether the socket to the property server has been open 
	private $bSocketOpen = false;
	//! @param $iPort Port number of property server
	private $iPort = null;
	//! @param $stErrorMsg Saves the last error message
	private $stErrorMsg = "No error message provided";
	//! @param $stHost Host name of property server
	private $stHost = null;
	//! @param $stReceiveBuffer Buffers incoming messages
	private $stRecvBuffer = null;
	//! @param $ParameterName Name of parameter retrieved from property server
	private $ParameterName = null;
	//! @param $ParameterValue Name of corresponding parameter value retrieved from property server
	private $ParameterValue = null;
	//! @param $ParameterExpected Expected value
	private $ParameterExpected = null;

//! Constructor.
//! Initializes parameters.
//! @param $host Target server name
//! @param $port Target server port number to connect to
//! @return 0: On success, -1: On failure

	function phpPropServer($host, $port)
	{
	   $this->stHost= $host;
	   $this->iPort = $port;
	   $this->pSocket = new phpSockets($this->stHost, $this->iPort);
	}


//! Creates a connection to the property server
//! @return 0: On success, -1: On failure

	function Connect2PropServer()
	{
	   if($this->pSocket == null)
	      return -1;

		if($this->pSocket->OpenSocket(1) == -1)
		{
   		$this->bSocketOpen = false;
         $this->stErrorMsg = $this->pSocket->GetErrorMessage();
         return -1;
		}
		else
		{
		   $this->bSocketOpen = true;
		   return 0;
		}
	}
	
	function DisconnectFromPropServer()
	{
      if($this->pSocket->CloseSocket() == -1)
      {
         $this->stErrorMsg = "Failed to close socket to property server.";
         $this->bSocketOpen = true;
         return -1;
      }
      else
      {
         $this->bSocketOpen = false;
         return 0;
      }
	}

//! Compares parameter values from a file with those of the property server.
//! @return

   public function Compare($filename)
   {
      // Prepare message
      $msg = "<?xml version=\"1.0\" ?><compare><file>".$filename."</file></compare>";

		//	Open socket to the property server and request all parameters.
      if(!$this->bSocketOpen)
      {
         if($this->Connect2PropServer() == -1)
            return -1;
      }

		//	Send message
		if($this->pSocket->SendMessage($msg) == -1)
		{
			$this->stErrorMsg = $this->pSocket->GetErrorMessage();
			return -1;
		}

		//	Receive message
		while(true)
		{
			$this->stRecvBuffer = $this->pSocket->ReceiveMessage();
			
			if( strpos($this->stRecvBuffer, "Unable to compare") > 0 )
			   return $this->stRecvBuffer;

			//	Explode the buffer into an array
			$aTempArray = explode(" ", $this->stRecvBuffer);

			//	We determine the end of the message by comparing the buffer with the string, "</check>".
			if(strstr($aTempArray[0], "</check>") != false) {
				break;
			}

			//	Determine if the $buffer contains a property
			if(strstr($aTempArray[0], "<property") != false)
			{		
				//	Parse property.
				$this->CompareValues();
				
				//  Make all letters lowercase letters
				$this->aArray[$this->iCount][0] = $this->ParameterName;
				$this->aArray[$this->iCount][1] = $this->ParameterValue;
				$this->aArray[$this->iCount][2] = $this->ParameterExpected;
				
				++$this->iCount;
			}
		}

		//	Close socket
      $this->DisconnectFromPropServer();
		return $this->aArray;    
   }

//! Retrieves all the properties from the property server.
//! @return A two-dimensional, alphabetically-sorted array; -1: On socket failure.

	public function GetAllProperties()
	{
		$this->iCount = 0;
		$stMessage = "<?xml version='1.0' ?><get><property name='*'/></get>";	
			
		//	Open socket to the property server and request all parameters.
      if(!$this->bSocketOpen)
      {
         if($this->Connect2PropServer() == -1)
            return -1;
      }

		//	Send message
		if($this->pSocket->SendMessage($stMessage) == -1)
		{
			$this->stErrorMsg = $this->pSocket->GetErrorMessage();
			return -1;
		}

		//	Receive message
		while(true)
		{
			$this->stRecvBuffer = $this->pSocket->ReceiveMessage();

			//	Explode the buffer into an array
			$aTempArray = explode(" ", $this->stRecvBuffer);

			//	We determine the end of the message by comparing the buffer with the string, "</get>".
			if(strstr($aTempArray[0], "/get") != false) {
				break;
			}

			//	Determine if the $buffer contains a property
			if(strstr($aTempArray[0], "<property") != false)
			{		
				//	Parse property.
				$this->ParseProperty();
				
				//  Make all letters lowercase letters
				$this->aArray[$this->iCount][0] = $this->ParameterName;
				$this->aArray[$this->iCount][1] = $this->ParameterValue;
				
				++$this->iCount;
			}
		}

		
		//	Sort array alphabetically
		array_multisort($this->aArray, SORT_ASC, SORT_REGULAR);

		//	Close socket
      $this->DisconnectFromPropServer();
		return $this->aArray;
	}


//! Retrieves the corresponding values of the properties identified by the property prefix
//! from the property server.
//! @param $stParamPrefix Property name prefix.
//! @return A two-dimensional, alphabetically-sorted array; -1: On socket failure.

	public function GetProperties($stParamPrefix)
	{
		//	Initialize variables
		$this->aArray = null;
	   $this->stRecvBuffer = null;
	   $this->ParameterValue = null;
		$stMessage = "<?xml version='1.0' ?><get><property name='".$stParamPrefix."'/></get>";
				
		//	Open socket to the property server and request all parameters.
      if(!$this->bSocketOpen)
      {
         if($this->Connect2PropServer() == -1)
            return -1;
      }

		if($this->pSocket->SendMessage($stMessage) == -1)
		{
			$this->stErrorMsg = $this->pSocket->GetErrorMessage();
			return -1;
		}

		//	Parse property
		while(true)
		{
			$this->stRecvBuffer = $this->pSocket->ReceiveMessage();

			//	Explode the buffer into an array
			$aTempArray = explode(" ", $this->stRecvBuffer);			

			//	We determine the end of the message by comparing the buffer with the string, "</get>".
			if(strstr($aTempArray[0], "/get") != false){
				break;
			}

			//	Determine if the $buffer contains a property
			if(strstr($aTempArray[0], "<property") != false) 
			{	
				$this->ParseProperty();
				$this->aArray[$this->iCount][0] = $this->ParameterName;
				$this->aArray[$this->iCount][1] = $this->ParameterValue;
				++$this->iCount;
			}
		}

		//	Sort array alphabetically
		array_multisort($this->aArray, SORT_ASC, SORT_REGULAR);

		//	Close socket
      $this->DisconnectFromPropServer();
		return $this->aArray;
	}


//! Retrieves the corresponding value of the property identified by the property name
//! from the property server.
//! @param $stPropertyName Property name.
//! @return Property value

	public function GetProperty($stParamName)
	{
		//	Initialize variables
	   $this->stRecvBuffer = null;
	   $this->ParameterValue = null;
	   $this->iCount = 0;
		$stMessage = "<?xml version='1.0' ?><get><property name=\"$stParamName\" /></get>";
				
		//	Open socket to the property server and request all parameters.
      if(!$this->bSocketOpen)
      {
         if($this->Connect2PropServer() == -1)
            return -1;
      }

		if($this->pSocket->SendMessage($stMessage) == -1)
		{
			$this->stErrorMsg = $this->pSocket->GetErrorMessage();
			return -1;
		}

		//	Parse property
		while(true)
		{
			$this->stRecvBuffer = $this->pSocket->ReceiveMessage();

			//	Explode the buffer into an array
			$aTempArray = explode(" ", $this->stRecvBuffer);			

			//	We determine the end of the message by comparing the buffer with the string, "</get>".
			if(strstr($aTempArray[0], "/get") != false){
				break;
			}

			//	Determine if the $buffer contains a property
			if(strstr($aTempArray[0], "<property") != false) {	
				$this->ParseProperty();
			}
		}

		//	Close socket
		$this->DisconnectFromPropServer();
		return $this->ParameterValue;
	}


//! Determines the category name for the given property.
//! @return Returns the category name.

	public function GetCategoryName($stParameter)
	{
		//	Local variables
		$end = null;
		$start = 0;
		
		$end = strpos($stParameter, '.');
		
		if($end) {	
			return substr($stParameter, $start, $end);
		}
		else {	// If the parameter name is the category name, return $stParameter
			return $stParameter;
		}
	}


//! Returns the last saved error message.
//! @return The last saved error message

	public function GetErrorMessage()
	{
		return $this->stErrorMsg;
	}


//! Sets the value for the selected parameters.
//! @param $aParamNameValues Two-dimensional array that contains the names and values of the parameters
//! that are to be changed.
//! @return A two-dimensional array.

	public function SetProperty($aParamNamesValues)
	{
		$this->iCount = 0;

		//	Determine the number of properties that needs to be set
		$aCount = count($aParamNamesValues);
		
		// Format message.
		$stMessage = "<?xml version=\"1.0\"?><set>";
		
		for( $i=0; $i<$aCount; ++$i ) {
		    $stMessage = $stMessage."<property name='".$aParamNamesValues[$i][0]."' value='".$aParamNamesValues[$i][1]."'/>";
		}
		
		$stMessage = $stMessage."</set>";


      // Open socket and send message to the property server
		if($this->pSocket->OpenSocket(1) == -1)
		{
			$this->stErrorMsg = $this->pSocket->GetErrorMessage();
			return -1;
		}

		if($this->pSocket->SendMessage($stMessage) == -1)
		{
			$this->stErrorMsg = $this->pSocket->GetErrorMessage();
			return -1;
		}

		while(true)
		{
			$this->stRecvBuffer = $this->pSocket->ReceiveMessage();

			//	Explode the buffer into an array
			$aTempArray = explode(" ", $this->stRecvBuffer);

			//	We determine the end of the message by comparing the buffer with the string, "</set>".
			if(strstr($aTempArray[0], "/set") != false) {
				break;
			}

			//	Determine if the $buffer contains a property
			if(strstr($aTempArray[0], "<property") != false)
			{
				//	Parse property.
				$this->ParseProperty();
				
				$this->aArray[$this->iCount][0] = $this->ParameterName;
				$this->aArray[$this->iCount][1] = $this->ParameterValue;
				
				++$this->iCount;
			}
		}
		
		//	Close socket
		$this->DisconnectFromPropServer();
		return $this->aArray;	
	}

	
//	******************************* PRIVATE FUNCTIONS *******************************
//	******************************* PRIVATE FUNCTIONS *******************************
//	******************************* PRIVATE FUNCTIONS *******************************

//! Parses the message string from the property server.  The format of the message from
//! the property server is important.  This method will not work properly if the format
//! differs.
//! @return NONE

	private function ParseProperty()
	{
		//	Find the "name" tag and readjust the start and end position so that we can retrieve 
		//	the "name" description and store it in the array.
		
		$start = strpos($this->stRecvBuffer, "name=\"");
		$end = strpos ($this->stRecvBuffer, '=');
		
		$start = $end + 1;
		$end = strpos($this->stRecvBuffer, '"', $start + 1);
		$length = ($end - $start);
		
		$this->ParameterName = substr($this->stRecvBuffer, $start + 1, $length - 1);
		
		//	Find the "value" tag and readjust the start and end position so that we can retrieve 
		//	the "value" description and store it in the array.
		
		$start = strpos($this->stRecvBuffer, "value=\"", $end + 1);
		$end = strpos($this->stRecvBuffer, '=', $start);
		
		$start = $end + 1;
		$end = strpos($this->stRecvBuffer, '"', $start + 1);
		$length = ($end - $start);
		
		$this->ParameterValue = substr($this->stRecvBuffer, $start + 1, $length - 1);
	}


	private function CompareValues()
	{
		//	Find the "name" tag and readjust the start and end position so that we can retrieve 
		//	the "name" description and store it in the array.
		
		$start = strpos($this->stRecvBuffer, "name=\"");
		$end = strpos ($this->stRecvBuffer, '=');
		
		$start = $end + 1;
		$end = strpos($this->stRecvBuffer, '"', $start + 1);
		$length = ($end - $start);
		
		$this->ParameterName = substr($this->stRecvBuffer, $start + 1, $length - 1);
		
		//	Find the "value" tag and readjust the start and end position so that we can retrieve 
		//	the "value" description and store it in the array.
		
		$start = strpos($this->stRecvBuffer, "value=\"", $end + 1);
		$end = strpos($this->stRecvBuffer, '=', $start);
		
		$start = $end + 1;
		$end = strpos($this->stRecvBuffer, '"', $start + 1);
		$length = ($end - $start);
		
		$this->ParameterValue = substr($this->stRecvBuffer, $start + 1, $length - 1);

		//	Find the "expected" tag and readjust the start and end position so that we can retrieve 
		//	the "expected" description and store it in the array.
		
		$start = strpos($this->stRecvBuffer, "expected=\"", $end + 1);
		$end = strpos($this->stRecvBuffer, '=', $start);
		
		$start = $end + 1;
		$end = strpos($this->stRecvBuffer, '"', $start + 1);
		$length = ($end - $start);
		
		$this->ParameterExpected = substr($this->stRecvBuffer, $start + 1, $length - 1);
	}
}
?>