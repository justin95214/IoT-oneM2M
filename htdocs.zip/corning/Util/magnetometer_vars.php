<?php
if(!isset($_SESSION)) 
   session_start(); 

if (!isset($_SESSION['logText_']))
	$_SESSION['logText_'] = "";

if (!isset($_SESSION['lastResponse_']))
	$_SESSION['lastResponse_'] = "";

if (!isset($_SESSION['isRunning_']))
	$_SESSION['isRunning_'] = "unknown";

if (!isset($_SESSION['state_']))
	$_SESSION['state_'] = "none";

if (!isset($_SESSION['calMode_']))
	$_SESSION['calMode_'] = "3d";

if (!isset($_SESSION['magMode_']))
	$_SESSION['magMode_'] = "";
?>