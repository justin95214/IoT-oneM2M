<?php
include_once(__DIR__."/../ih_scripts.php");
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/../ih_defines.php");
include_once(__DIR__."/magnetometer_vars.php");
include_once(__DIR__."/magnetometer_scripts.php");

$client_data = file_get_contents("php://input");
$newMagMode = getValue($client_data, "magMode");
$calMode = getValue($client_data, "calMode");
$_SESSION['calMode_'] = $calMode;

$collectData = getValue($client_data, "collectData");
$calibrateData = getValue($client_data, "calibrateData");
$commitData = getValue($client_data, "commitData");
$cancelData = getValue($client_data, "cancelData");

$magMode = $_SESSION['magMode_'] ;
if ($magMode != $newMagMode)
{
   SetXmlValueFile("C:/CorningHsi/config/parameters.xml", "navServer.magnetometer.accept", $newMagMode);
   $log = $_SESSION['logText_']; 
   $_SESSION['logText_'] = $log."<br>Set magnetometer use to: $newMagMode.";
   $_SESSION['magMode_'] = $newMagMode;
}

$propServerRunning = IsPropServerRunning("ih");
if ($propServerRunning != false)
{
   $key = "navServer.magnetometer.calibration.mode";
   $props[0][0] = $key;
   $props[0][1] = $calMode;
   setProperty("ih", $props);
}

$state = $_SESSION['state_'];

if ($collectData == "true")
{
   $isRunning = $_SESSION['isRunning_'];
   if ($isRunning == "false" || $isRunning == "unknown") 
   {
      stopCalibrationApp();
      sleep(1);
      startCalibrationApp();
      $_SESSION['isRunning_'] = "true";
   }

   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false && $state != collecting)
   {
      $key = "navServer.magnetometer.calibration.command";
      $val = "collect";
      $props[0][0] = $key;
      $props[0][1] = $val;

      $key1 = "navServer.magnetometer.calibration.mode";
      $props[1][0] = $key1;
      $props[1][1] = $calMode;
      setProperty("ih", $props);
      $_SESSION['state_'] = "collecting";
   }
}

if ($calibrateData == "true")
{
   if ($state == "collecting")
   {
      $propServerRunning = IsPropServerRunning("ih");
      if ($propServerRunning != false)
      {
         $key = "navServer.magnetometer.calibration.command";
         $val = "calibrate";
         $props[0][0] = $key;
         $props[0][1] = $val;
         setProperty("ih", $props);
      }
      $_SESSION['state_'] = "calibrating";
      sleep(1);
      $report = getCalibrationReport();
      $log = $_SESSION['logText_']; 
      $_SESSION['logText_'] = $log."<br>".$report;
   }
}

if ($commitData == "true")
{
   $key = "navServer.magnetometer.calibration.valid";
   $dataValid =  getProperty("ih", $key);
   if ($state == "calibrating" && $dataValid == "true")
   {
      $key = "navServer.magnetometer.calibration.command";
      $val = "commit";
      $props[0][0] = $key;
      $props[0][1] = $val;
      setProperty("ih", $props);
      $_SESSION['state_'] = "none";
   }
   else
   {
      $log = $_SESSION['logText_'];
      $_SESSION['logText_'] = $log."<br>Cannot commit invalid data.";
   }
}

if ($cancelData == "true")
{
   stopCalibrationApp();
   $_SESSION['isRunning_'] = "false";
   $_SESSION['logText_'] = "";
	$_SESSION['lastResponse_'] = "";
   $_SESSION['state_'] = "none";
}
?> 