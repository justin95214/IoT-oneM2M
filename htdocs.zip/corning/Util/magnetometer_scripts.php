<?php
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/../ih_defines.php");
include_once(__DIR__."/magnetometer_vars.php");

/*	===========================================================================
*  This checks for a change in the property server response.  If it has changed
* it appends that response to the log entry and returns it.
* @return - the log entries for the magnetometer calibration.
*/
function getLogText()
//	=========================================================================== 
{
   $logText = $_SESSION['logText_'];

   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning == true)
   {
      $key = "navServer.magnetometer.calibration.message";
      $response = getProperty("ih", $key);
   	$lastResponse = $_SESSION['lastResponse_'];
      if ($response != $lastResponse && strlen($response) > 0)
      {
         if (strlen($logText) == 0)
            $logText = $response;
         else
            $logText = $logText."<br>".$response;

         $_SESSION['logText_'] = $logText;
         $_SESSION['lastResponse_'] = $response;
      }
   }
   else
   {
      $_SESSION['logText_'] = "";
      $_SESSION['lastResponse_'] = "";
      $logText = "";
   }

   return $logText;
}

/*	===========================================================================
*  This reads the property server for clalibration report data.  It then formats
* the report as a string for display in the log text.
* @return - a report of the magnetometer calibration.
*/
function getCalibrationReport()
//============================================================================
{
   $report = "";

   $propServerRunning = IsPropServerRunning("ih");
   if ($propServerRunning != false)
   {
      setProperty(sysProp, "navServer.magnetometer.calibration.updated", "false");
      $key = "navServer.magnetometer.calibration.updated";
      $response = getProperty("ih", $key);
      if ($response == "false")
         return $report;

      $key = "navServer.magnetometer.calibration.quality";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = "Quality: ".$response.".<br>";

      $key = "navServer.magnetometer.calibration.confidence";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."Confidence: ".$response.".<br>";

      $cnt = 1;
      $key = "navServer.magnetometer.calibration.response";
      $key1 = $key.$cnt;
      $response = getProperty("ih", $key1);
      while ($response != "none")
      {
         $report = $report.$response.".<br>";
         $cnt += 1;
         $key1 = $key.$cnt;
         $response = getProperty("ih", $key1);
      }

      $key = "navServer.magnetometer.calibration.numPoints";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."Used Points: ".$response.".<br>";

      $key = "navServer.magnetometer.calibration.maxNumPoints";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."Max Points: ".$response.".<br>";

	   $report = $report."Magnetic field deviation report<br>";

      $key = "navServer.magnetometer.calibration.before.meanError";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."Before: mean ".$response.", ";

      $key = "navServer.magnetometer.calibration.before.stdError";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."std: ".$response.", ";

      $key = "navServer.magnetometer.calibration.before.maxError";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."max: ".$response."<br>";

      $key = "navServer.magnetometer.calibration.after.meanError";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."After: mean ".$response.", ";

      $key = "navServer.magnetometer.calibration.after.stdError";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."std: ".$response.", ";

      $key = "navServer.magnetometer.calibration.after.maxError";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."max: ".$response."<br>";

      $key = "navServer.magnetometer.calibration.meanAccuracy";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."Accuracy (deg): mean ".$response.", ";

      $key = "navServer.magnetometer.calibration.stdAccuracy";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."std: ".$response.", ";

      $key = "navServer.magnetometer.calibration.maxAccuracy";
      $response = getProperty("ih", $key);
      if ($response != "")
         $report = $report."max: ".$response."<br>";
   }

   return $report;
}

/*	===========================================================================
*  Calls the startup.bat file to start the log recorder, log server, property server,
* and the magnetometer calibration app.  The delay of 3 seconds is added to allow
* the applications to start and populate the property server.
*/
function startCalibrationApp()
//	=========================================================================== 
{
   //exec("start C:\\CorningHsi\\magneticCal\\startup.bat");
   popen("start C:\\CorningHsi\\magneticCal\\startup.bat", 'r');
   sleep (3);
}

/*	===========================================================================
*  Calls the shutdown.bat file to stop the log recorder, log server, property server,
* and the magnetometer calibration app.
*/
function stopCalibrationApp()
//	=========================================================================== 
{
   //exec("start C:\\CorningHsi\\magneticCal\\shutdown.bat");
   popen("start C:\\CorningHsi\\magneticCal\\shutdown.bat", 'r');
   sleep (3);
}

/*	===========================================================================
*  searches the seaarchStr and returen the value for the indicated string.
*  The search string should be in the format "key1=value1&key2=value2".
* @param searchStr - the string to search.
* @param key - the desired key.
* @return value - the value associated with the key if found, an empyt string if not found.
*/
function getValue($searchStr, $key)
{
   $value = "";
   if (strpos($searchStr, $key) >= 0)
   {
      $start = strpos($searchStr, $key);
      $start = strpos($searchStr, "=", $start) + 1;     
      $end = strpos($searchStr, "&", $start);
      if ($end == false)
         $end = strlen($searchStr);

      $value = substr($searchStr, $start, $end - $start);  
   }

   return $value;
}

/*	===========================================================================
*  This method opens an XML file. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $filename - this is the name of the XML file to view.
*  @param $key - this is the key used to search for the value.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function GetXmlValueFile($filename, $key)
//	===========================================================================
{
   if (!$filename)
      return -3;
      
   $handle = fopen($filename, 'r');
   if ($handle)
   {
   
      $message = fread($handle, 20000);
      
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $endInt = strpos($message, "\"", $startInt);
         $len = $endInt - $startInt;
         $value = substr($message, $startInt, $len);
      }
      else
         $value = -2;
   }
   else
      $value = -1;
   
   fclose($handle);

	return $value;
}

/*	===========================================================================
*  This method opens an XML file with the given filename. 
*  It then reads the file to find current key and sets the corresponding value.
*  @param $fileName - this is the name of the XML file to change.
*  @param $key - this is the key used to search for the value.
*  @param $value - this is the value to be set.
*  @return -   0 on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*                 -4 if the file could not be opened for writting.
*/
function SetXmlValueFile($filename, $key, $value)
//	===========================================================================
{
   $returnValue = 1;
   if (!$filename)
      $returnValue = -3;

   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);
   
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\"", $startInt);
         $buf3 = substr($message, $endInt);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

	return $returnValue;
}

?>