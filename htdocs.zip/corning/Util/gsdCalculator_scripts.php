<?php

/*	===========================================================================
*  This function recursively scans the specified directory for the given filenames.
* It opens and parses each file with the given filename for indicated frame rates.
* The framer rates are added to the return array as a set (no duplicates) and order
* before bing returned.
* @dir The directory to recursively search.
* @filename - the filenames to search for and parse
* @return - an array of the framer rates found.
*/
function getFramerates($dir, $filename)
//	=========================================================================== 
{
   $rates = array();
   $result = scandir($dir);
   foreach ($result as $file)
   {
      $fullFilename = $dir."/".$file; 
      if(is_dir($fullFilename) == TRUE)
      {
         if ($file != "." && $file != "..")
         {
            $rts = getFramerates($fullFilename, $filename);
            foreach($rts as $rate)
               array_push($rates, $rate);
         }
      }
      else if ($file == $filename)
      {
         $handle = fopen($fullFilename, 'r');
         if ($handle)
         {
            $data = fread($handle, 20000);
            fclose ($handle);
      
            $x = 1;
            while(($entry = getXmlFieldEx($data, "entry", $x)) == true)
            {
               $rate = getXmlField($entry, "rate");
               array_push($rates, $rate);
               $x++;
           }
         }
      }
   }

   $rates = array_unique($rates);
   asort($rates);

   return $rates;
}

function getXmlFieldEx($data, $tag, $index)
{
   $stag = "<".$tag.">";
   $etag = "</".$tag.">";

   for ($x = 1; $x < $index; $x++)
   {
      $idx = strpos($data, $stag);
      if ($idx == false)
         return false;
      
      $data = substr($data, $idx + 1);
   }

   $i = strpos($data, "$stag");
   $j = strpos($data, "$etag", $i);
   if ($i && ($i >= 0) && $j && ($j > $i))
   {
      $i = $i + strlen($tag) + 2;
      $value = substr($data, $i, $j-$i);
      return $value;
   }
   return false;
}


function getXmlField($data, $tag)
{
   $stag = "<".$tag.">";
   $etag = "</".$tag.">";
   $i = strpos($data, $stag);
   $j = strpos($data, "$etag");
   if (($i >= 0) && ($j > $i))
   {
      $i = $i + strlen($tag) + 2;
      $value = substr($data, $i, $j-$i);
      return $value;
   }
   return false;
}


?>