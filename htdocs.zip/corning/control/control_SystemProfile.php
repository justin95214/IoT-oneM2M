<?php
   include("../ih_scripts.php");
   include_once(__DIR__."/control_vars.php");
   include_once(__DIR__."/control_scripts.php");
   
   $sensor = $_POST["sensor"];
   $swirExposureRate = $_POST["swirExposureRate"];
   $vnirExposureRate = $_POST["vnirExposureRate"];
   $eventsTrackFile = $_POST["eventTrack"];
  
   if ($vnirExposureRate)
   {
      $end = strpos($vnirExposureRate, ",");
      if ($end !== false)
      {
         $vnirExposure = substr($vnirExposureRate, 0, $end);
         $vnirRate = substr($vnirExposureRate, $end + 1);
         $_SESSION['vnirExposure_'] = $vnirExposure; 
         $_SESSION['vnirRate_'] = $vnirRate; 
      } 
   }

   if ($swirExposureRate)
   {
      $end = strpos($swirExposureRate, ",");
      if ($end !== false)
      {
         $swirExposure = substr($swirExposureRate, 0, $end);
         $swirRate = substr($swirExposureRate, $end + 1);
         $_SESSION['swirExposure_'] = $swirExposure; 
         $_SESSION['swirRate_'] = $swirRate;
      }  
   }
   

   if ($eventsTrackFile)
   {
      $value = "C:/corningHsi/eventConfig/".$eventsTrackFile;
      SetXmlValue("../config/", "parameters.xml", "eventTracksFile", $value);
      $_SESSION['eventTracksFile_'] = $eventsTrackFile; 
   }

   $sensor = $_POST["sensor"];

   switch( $sensor )
   {
      case "hsi":
         $profile = $_POST["hsiRadio"];
         break;
      case "pan":
         $profile = $_POST["panRadio"];
         break;
      case "ih":
         $profile = $_POST["profile"];
         break;
      default:
         break;
   }
   SetProfile($sensor, $profile);

   echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=control_System.html'\>";
   //$redirect = "control_System.html";
   //include($redirect);
?>