<?php
	require_once("../ih_defines.php");
	require_once("../ih_scripts.php");
	require_once("../SensorClass.php");
   include 'control_vars.php';
	
	//	Determine sensor type
	$sensor = $_POST["sensor"];
	
	// Retrieve variables
	$host = $_POST[$sensor."Host"];
	$port = $_POST[$sensor."Port"];
	$target = $_POST[$sensor."Target"];
	$pass = $_POST[$sensor."Pass"];
	$command = $_POST["command"];
	$calibrate = $_POST["calibrate"];
   $fov = $_POST["FOV"];
   $scans = $_POST["Scans"];
   $updateSaveFile = $_POST["updateSaveFile"];
   $saveFile = $_POST["saveFile"];

   $ihMessage = "";
   $ihMessage1 = "";
   $ihMessage2 = "";
   $ihMessage3 = "";
   $ihMessage4 = "";

   $err = false;
   $delay = 1;
 
   //save current scree settings
   $_SESSION['target_'] = $target;
   $_SESSION['pass_'] = $pass;
   $_SESSION['calibration_'] = $calibrate;
   
   if (!isset($calibrate))
      $calibrate = 0;
 
   //this is test
   if ($calibrate == 3)
      $command = "ihTest";   
 
   if (isset($scans) && is_numeric($scans))
      $_SESSION['scans_'] = $scans;      

   if (isset($fov) && is_numeric($fov) && IsPropServerRunning("ih"))
   {
      $_SESSION['fov_'] = $fov;      

      $propArray[0][0] = "rotary.scan.angle";
      $propArray[0][1] = $fov;
      SetProperty("ih", $propArray);
   }

   if (strcmp($updateSaveFile, "true") == 0)
   {
      $saveArray[0][0] = "swir.file.save";
      $saveArray[0][1] = $saveFile;
      $saveArray[1][0] = "vnir.file.save";
      $saveArray[1][1] = $saveFile;
      SetProperty("ih", $saveArray);
   }
   else
   {
      //	Check that we have all required information before continuing
      if($host == "" || $port == "" || $target == "" || $pass == "")
      {
         echo "Error: Missing parameters. Please enter all required parameters.";
         $err = true;
         $delay +=5;
      }
	
      //	Establish socket connection.  If an error is encountered, send an error message to the user, otherwise,
      //	send a status message to the user.
      $pSocket = new phpSockets($host, $port);
      if($err == false && @ $pSocket->OpenSocket(2) == -1)
	   {
	      //	Get last error message
         $error = $pSocket->GetErrorMessage();
		
         if( $error == "" )
            echo "Failed to open socket to '".$host."'.  Please check host name.;";
	      else
            echo "Error: $error";
      
         $delay +=5;   
      }
      else if ($err == false)
      {
         $pSocket->setTimeout(1);

         // File where the property server host and port number can be found.
         $sensor = new Sensor( $sensor, IH_PROPSERVER_FILE );

         if (strcmp("ihStart", $command) == 0)
         {
            // Create the event ID
            //ensure that the target and pass have three characters
            if (strlen($target) > 3 || strlen($pass) > 3)
            {
               $err = true;
               $delay +=5;
               echo "Error: Target and Pass must be characters.";
            }
            while(strlen($target) < 3)
               $target = "0".$target;
      
            while(strlen($pass) < 3)
               $pass = "0".$pass;

            $_SESSION['target_'] = $target;
            $_SESSION['pass_']= $pass;

            $eventID = $sensor->CreateEventID($target, $pass);

            $ihArray[0][0] = "event.id";
            $ihArray[0][1] = $eventID;
            $_SESSION['calibration_'] = $calibrate;
         }
      
         //The following are messages that can be sent to the system:
         //	1. Initialize
         // 2. Test
         // 3. Darks w/o Start
         // 4. Start w/ or w/o calibration
         //	5. Stop
         //	Determine which message the user wants to send

         //	========== INITIALIZE ==========
         $stMessage = "<?xml version=\"1.0\" encoding=\"ISO-8-859-1\"?><command><sensor>2_HSI</sensor><image>initialize</image></command>";
         @ $pSocket->SendMessage( $stMessage );

         // ========== TEST ==========
         if( strcmp("ihTest", $command) == 0 )
         {
            $stMessage = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><command><sensor>2_HSI</sensor><image>test</image></command>";
         }
	      // ========== STOP ==========
	      elseif( strcmp("ihStop", $command) == 0 )
	      {
            $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>
		                  <command>
		                     <sensor>2_HSI</sensor>
		                     <image>stop</image>
		                  </command>";
         }
	      // ========== DARKS W/O START ==========
         else if($err == false && $calibrate == 2)
         {
            $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>
		                   <command>
		                     <sensor>2_HSI</sensor>
		                     <image>stop</image>
		                  </command>";

            SetProperty("ih", $ihArray);
            $ihMessage =  "Event ID: $eventID";

            $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>
	  	                     <command>
                              <sensor>2_HSI</sensor>
                              <image>calibrate</image>
                              <cal_type>darks</cal_type>
                           </command>";
         }
	      //   ========== START ==========
         elseif($err == false && strcmp("ihStart", $command) == 0 )
         {
            // If the eventID is not included in the message, the sensorcontroller will look for it in the property server.
            // We are going to set the eventID in the property server for this purpose.
            SetProperty("ih", $ihArray);
            $ihMessage =  "Event ID: $eventID";

            // We need to parse out the missionID from the eventID as the coordinator is expecting a mission tag
            $mission = substr($eventID, 0, 14);
	
            // Determine if we need to calibrate the system before starting
            $stMessage =  "";

            switch($calibrate)
            {
               case '0': // None
                  if (isset($scans) && is_numeric($scans))
                  {
                     $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><command>
<sensor>2_HSI</sensor><image>start</image><cal_type>none</cal_type>
<frames>0</frames><mission>$mission</mission><target>$target</target><pass>$pass</pass><scans>$scans</scans>
</command>";
                  }
                  else
                  {
                     $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><command>
<sensor>2_HSI</sensor><image>start</image><cal_type>none</cal_type>
<frames>0</frames><mission>$mission</mission>
<target>$target</target><pass>$pass</pass>
</command>";
                  }
                  break;
               
               case '1': // Darks
                  if (isset($scans) && is_numeric($scans))
                  {
                     $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><command>
<sensor>2_HSI</sensor><image>start</image><cal_type>darks</cal_type><mission>$mission</mission>
<target>$target</target><pass>$pass</pass><scans>$scans</scans>
</command>";  
                  }
                  else
                  {
                     $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><command>
<sensor>2_HSI</sensor><image>start</image><cal_type>darks</cal_type><mission>$mission</mission>
<target>$target</target><pass>$pass</pass>
</command>";  
                  }
               break;
            }
         }
		
         // Send the message over the socket.
         if($err == false)
         { 
            if (@ $pSocket->SendMessage($stMessage) == -1)
               echo "Error: Failed to send message";
            else
            {
               $returnMsg = $pSocket->ReceiveMessage();
               $result = ParseXML($returnMsg, "<result>", "</result>");
               $result = ucfirst($result);   
               $text = ParseXML($returnMsg, "<text>", "</text>");

               if (strlen($result))
               {
                  if (strlen($ihMessage_))
                     $ihMessage1 = "$result: $text";
                  else   
                     $ihMessage2 = "$result: $text";
               }
               else
                  $ihMessage = "Error: failed to receive response message";
            }
         }
      } 
      $_SESSION['ihMessage_'] = $ihMessage;
      $_SESSION['ihMessage1_'] = $ihMessage1;
      $_SESSION['ihMessage2_'] = $ihMessage2;
      $_SESSION['ihMessage3_'] = $ihMessage3;
      $_SESSION['ihMessage4_'] = $ihMessage4;
   }

   echo "<META HTTP-EQUIV='Refresh' CONTENT='$delay; URL=control_Sensor.html'\>";   
?>