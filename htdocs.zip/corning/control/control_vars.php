<?php
//include_once(__DIR__."/../ih_defines.php");
if(!isset($_SESSION)) 
{ 
   session_start(); 
}  

if (!isset($_SESSION['swirExposure_']))
   $_SESSION['swirExposure_'] = "";

if (!isset($_SESSION['vnirExposure_']))
   $_SESSION['vnirExposure_'] = "";

if (!isset($_SESSION['swirRate_']))
   $_SESSION['swirRate_'] = "";

if (!isset($_SESSION['vnirRate_']))
   $_SESSION['vnirRate_'] = "";

if (!isset($_SESSION['host_']))
	$_SESSION['host_'] = "";

if (!isset($_SESSION['port_']))
	$_SESSION['port_'] = "";

if (!isset($_SESSION['scans_']))
	$_SESSION['scans_'] = "1";

if (!isset($_SESSION['fov_']))
	$_SESSION['fov_'] = "60";

if (!isset($_SESSION['target_']))
	$_SESSION['target_'] = "001";
	
if (!isset($_SESSION['pass_']))
	$_SESSION['pass_'] = "001";	

if (!isset($_SESSION['calibration_']))
	$_SESSION['calibration_'] = -1;
	
if (!isset($_SESSION['initial_']))
	$_SESSION['initial_'] = "true";
	
if (!isset($_SESSION['ihMessage_']))
	$_SESSION['ihMessage_'] = "";
					
if (!isset($_SESSION['ihMessage1_']))
	$_SESSION['ihMessage1_'] = "";

if (!isset($_SESSION['ihMessage2_']))
	$_SESSION['ihMessage2_'] = "";

if (!isset($_SESSION['ihMessage3_']))
	$_SESSION['ihMessage3_'] = "";

if (!isset($_SESSION['ihMessage4_']))
	$_SESSION['ihMessage4_'] = "";

if (!isset($_SESSION['ihOnOff_']))
	$_SESSION['ihOnOff_'] = "off";
?>