<!DOCTYPE html>
<?php
require_once(__dir__."/../ih_scripts.php");
include_once(__DIR__."/control_vars.php");
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="stylesheet" type="text/css" href="../style/style.css" />
<title>Corning Hyperspectral</title>
<script src="../ih.js" type="text/javascript"></script>
<script src="/web-files/dtjava.js"></script>
</head>
<body><?php displayMenu();?>
<div class="main">
   <div class="pageTitle">System Control</div>
   <div id="systemControl_shutDown">
      <?php
         //when input images are posted, only the coordinates are passed as name_x/name_y
         $bsubmitOn_x = $_POST['bsubmitOn_x'];			
         $bsubmitOff_x = $_POST['bsubmitOff_x'];	
	        
         if(isset($bsubmitOn_x))
		      $choice = "ON";

	      if(isset($bsubmitOff_x))
		      $choice = "OFF";
   
         // Determine if the user wants to start or stop the pipeline
         switch( $choice )
         {
            case "OFF":
               echo PowerSystemOff("ih");
               $_SESSION['ihOnOff_'] = "off";
      ?>
               <form action="control_System.html">
                  <p class="container">
                     <input class="button" type="submit" name="Submit" value="Return" />
                  </p>
               </form>
      <?php
               break;
      
            case "ON":
               $ihOnOff = $_SESSION['ihOnOff_'];
               if (strcmp($ihOnOff, "off") == 0)
               {
                  $_SESSION['ihOnOff_'] = "on";
                  echo PowerSystemOn("ih");
                  echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=/corning/status/status.html'\>";
               }
               else
               {
                  echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=/corning/control/control_System.html'\>";
               }
               break;
         }
      ?>
   </div>
</div>
</body>
</html>
