<?php
   require_once("../ih_defines.php");
   require_once("../ih_scripts.php");
   require_once("../SensorClass.php");
	
   //	Determine sensor type
   $sensor = $_POST["sensor"];
	
   // Retrieve variables
   $host = $_POST[$sensor."Host"];
   $port = $_POST[$sensor."Port"];
   $target = $_POST[$sensor."Target"];
   $pass = $_POST[$sensor."Pass"];
   $command = $_POST["command"];
   $calibrate = $_POST["calibrate"];

/*
   $sensor = "ih";
   $host = "127.0.0.1";
   $port = 80;
   $target = 001;
   $pass = 001;
   $command = "ihStart";
   $calibrate = "none";
*/

/*
// ===== MIMI TEST =====
   echo "Host: ".$host."\n";
   echo "Port: ".$port."\n";
   echo "Target: ".$target."\n";
   echo "Pass: ".$pass."\n";
   echo "Calibrate: ".$calibrate."\n";
   echo "command: ".$command."\n";
   echo "sensor: ".$sensor."\n";
//	===== MIMI TEST ===== 
*/

   //	Check that we have all required information before continuing
   if($host == "" || $port == "" || $target == "" || $pass == "")
   {
      echo "Error: Missing parameters. Please enter all required parameters.;";
      return;
   }
	
   //	Establish socket connection.  If an error is encountered, send an error message to the user, otherwise,
   //	send a status message to the user.
   $pSocket = new phpSockets($host, $port);

   if(@ $pSocket->OpenSocket(2) == -1)
   {
      echo "Failed to open socket to $host.;";
      return;
	}
	
   // File where the property server host and port number can be found.
   $sensor = new Sensor( $sensor, IH_PROPSERVER_FILE );

   // Create the event ID
   $eventID = $sensor->CreateEventID($target, $pass);

   $ihArray[0][0] = "event.id";
   $ihArray[0][1] = $eventID;
 
   //	The following are messages that can be sent to IRONHORSE:
   //	1. Initialize
   // 2. Test
   // 3. Darks w/o Start
   // 4. Start w/ or w/o calibration
   //	5. Stop
   //	Determine which message the user wants to send

   //	========== INITIALIZE ==========
   $stMessage = "<?xml version=\"1.0\" encoding=\"ISO-8-859-1\"?><command><sensor>SENSOR</sensor><image>initialize</image></command>";
   @ $pSocket->SendMessage( $stMessage );

	// ========== TEST ==========
   if( strcmp("ihTest", $command) == 0 )
   {
      $stMessage = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><command><sensor>SENSOR</sensor><image>test</image></command>";
      $outputMessage = "Sending \"test\" command\n";
   }
   // ========== STOP ==========
   elseif( strcmp("ihStop", $command) == 0 )
   {
      $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>
                     <command>
                     <sensor>SENSOR</sensor>
                     <image>stop</image>
                     </command>";

      $outputMessage = "Stopping Imaging. ";
   }
   // ========== DARKS W/O START ==========
   else if($calibrate == 2)
   {
      SetProperty("ih", $ihArray);
      echo "Event ID: $eventID.;";

      $stMessage = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><command><sensor>SENSOR</sensor><image>calibrate</image><type>darks</type></command>";
      $outputMessage = "Calibrating ... \n";
   }
   //   ========== START ==========
   elseif( strcmp("ihStart", $command) == 0 )
   {
      // If the eventID is not included in the message, the Iron Horse sensorcontroller will look for it in the property server.
      // We are going to set the eventID in the property server for this purpose.
      SetProperty("ih", $ihArray);
      echo "Event ID: $eventID.;";

      // We need to parse out the missionID from the eventID as the coordinator is expecting a mission tag
      $mission = substr($eventID, 0, 14);
	  
      // Determine if we need to calibrate the system before starting
      switch($calibrate)
      {
         case '0': // None
            $calibrate = "none";
            break;
         case '1': // Darks
            $calibrate = "darks";
            $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>
                           <command>
                           <sensor>SENSOR</sensor>
                           <image>calibrate</image>
                           <type>darks</type>
                           </command>";

            $outputMessage = "Calibrating ... ";
            $pSocket->SendMessage($stMessage); 

            // If we are calibrating, we need to wait for the response from the calbration pipeline
            sleep(4);

            if( $calibrate == 2 )
               $pSocket->ReadMessage();
            break;
      }

      $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8-859-1\"?>
                     <command>
                        <sensor>SENSOR</sensor>
                        <image>start</image>
                        <mission>$mission</mission>
                        <target>$target</target>
                        <pass>$pass</pass>
                   </command>";
   }
		
   // Send the message over the socket.
   if(@ $pSocket->SendMessage($stMessage) == -1)
   {
      echo "Error: Failed to send message.;";
   }
   else
   {
      echo "Message sent successfully.;";
      "echo $outputMessage.;";
   }
?>