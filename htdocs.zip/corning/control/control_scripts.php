<?php
include_once(__DIR__."/../includes/phpPropServer.php");
include_once(__DIR__."/../includes/phpSockets.php");
include_once(__DIR__."/control_vars.php");

function UpdateStatus()
//	===========================================================================
{
   $ihMessage = "";
   $ihMessage1 = "";
   $ihMessage2 = "";
   
   $stMessage =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>
   <command>
      <sensor>2_HSI</sensor>
      <type>status</type>
   </command>";

   $host = $_SESSION['host_'];
   $port = $_SESSION['port_'];

   if($host == "" || $port == "")
   {
      echo "Error: Missing parameters. host = $host port = $port<br>";
      return;
   }

   $pSocket = new phpSockets($host, $port);
   if(@ $pSocket->OpenSocket(2) == -1)
   {
      //	Get last error message
      $error = $pSocket->GetErrorMessage();
      if( $error == "" )
         echo "Failed to open socket to '".$host."'.  Please check host name.;";
      else
         echo "Error: $error";
   }
   else
   {
      $pSocket->setTimeout(1);

      if (@ $pSocket->SendMessage($stMessage) == -1)
         echo "Error: Failed to send message";
      else
      {
         $returnMsg = $pSocket->ReceiveMessage();
         $result = ParseXML($returnMsg, "<result>", "</result>");
         $result = ucfirst($result);
         $text = ParseXML($returnMsg, "<text>", "</text>");
         if (strlen($result))
         {
            if (strlen($ihMessage_))
               $ihMessage1 = "$result: $text";
            else
               $ihMessage2 = "$result: $text";
         }
         else
            $ihMessage = "Error: Failed to receive response message";
      }
   }

   $_SESSION['ihMessage_'] = $ihMessage;
   $_SESSION['ihMessage1_'] = $ihMessage1;
   $_SESSION['ihMessage2_'] = $ihMessage2;
}

function displayEventFiles($profile)
//	===========================================================================
{
   $path = getenv("PROFILE_HOME");
   if (!$path)
      return -3;

   $paramfile = sprintf("%s\\%s\\%s", $path, $profile, "parameters.xml");
   if (file_exists($paramfile))
   {
      $useEventTracks = GetXmlValueFile($paramfile, "eventTracks.use");
      if ($useEventTracks == "true")
      {
         $mainPropFile = "c:/corningHsi/config/parameters.xml";
         $curEventsFile = GetXmlValueFile($mainPropFile, "eventTracksFile");
         $curEventsFile = basename($curEventsFile);

         $userSelectedTracksFile = $_SESSION['eventTracksFile_'];
         if (strlen($userSelectedTracksFile) > 0 && strcasecmp($curEventsFile, $userSelectedTracksFile) != 0)
            $curEventsFile = $userSelectedTracksFile;

         echo "<div class=\"eventTracks\">\n";
         echo "<p>Track/Area Files <select name=\"eventTrack\" onChange=\"this.form.submit()\">\n";
         $result = scandir("C:/corningHsi/eventConfig");
         foreach ($result as $file)
         {
            if(is_dir($file) == false)
            {
               if (strcasecmp($curEventsFile, $file) == 0)
                  echo "<option value=\"".$file."\" selected>".$file."</option>\n";
               else
                  echo "<option value=\"".$file."\">".$file."</option>\n";
            }
          }
          echo "</select></p>\n";
          echo "</div>\n";
      }
   }
}
function displayIntegrationTimes($profile)
//	===========================================================================
{
   $path = getenv("PROFILE_HOME");
   if (!$path)
      return -3;
    
   $filename = sprintf("%s\\%s\\%s", $path, $profile, "integrationTimes.xml");
   if (file_exists($filename))
   {
      $handle = fopen($filename, 'r');
      if ($handle)
      {
         $data = fread($handle, 20000);
         fclose ($handle);
      
         $x = 1;
         while(($sensor = getXmlFieldEx($data, "sensor", $x)) == true)
         {
            $name = getXmlField($sensor, "name");
            $paramFilename = sprintf("%s\\%s\\%s", $path, $profile, "parameters.xml");
            $curExp = GetXmlValueFile($paramFilename, "$name.exposure");
            $curRate = GetXmlValueFile($paramFilename, "$name.framerate");
        
            echo "<div class=\"systemExposure\">\n";
            echo "<p>$name Exposure/Frame Rate <select name=\"".$name."ExposureRate\" onChange=\"this.form.submit()\">\n";
         
            $newExposure = "";
            if (strcasecmp($name, "vnir") == 0)
               $newExposure = $_SESSION['vnirExposure_'];
            if (strcasecmp($name, "swir") == 0)
               $newExposure = $_SESSION['swirExposure_'];
 
            $newRate = "";
            if (strcasecmp($name, "vnir") == 0)
               $newRate = $_SESSION['vnirRate_'];
            if (strcasecmp($name, "swir") == 0)
               $newRate = $_SESSION['swirRate_'];


            //determine if the user has selected values from the GUI
            //if so, set what the user has selected.
            $setUserSelection = false;
            $y = 1;
            while(($entry = getXmlFieldEx($sensor, "entry", $y)) == true)
            {
               $time = getXmlField($entry, "time");
               $rate = getXmlField($entry, "rate");
               if ($time == $newExposure && $rate == $newRate)
                  $setUserSelection = true;

               $y++;   
            }

            $y = 1;
            while(($entry = getXmlFieldEx($sensor, "entry", $y)) == true)
            {
               $default = false;
               $time = getXmlField($entry, "time");
               $rate = getXmlField($entry, "rate");

               //the user has selected values from the GUI - use them
               if ($setUserSelection == true)
               {
                  $timeMs = $time/1000;
                  $display = $timeMs."ms/".$rate."Hz";
                  if ($newExposure == $time && $newRate == $rate)
                  {
                     echo "<option value=\"$time,$rate\" selected=\"selected\">$display</option>\n";
                     $key = getXmlField($entry, "key");                  
                     $value = getXmlField($entry, "value");    
                     SetXmlValue($profile, "parameters.xml", $key, $value);

                     $key = "$name.exposure";
                     SetXmlValue($profile, "parameters.xml", $key, $time);
                
                     $key = "$name.framerate";
                     SetXmlValue($profile, "parameters.xml", $key, $rate);
                  }
                  else
                     echo "<option value=\"$time,$rate\">$display</option>\n";
               }
               //The user has not yet selected values from the GUI, use values from parameters.xml
               else
               {
                  $timeMs = $time/1000;
                  $display = $timeMs."ms/".$rate."Hz";

                  //$curExp and $curRate is taken from the parameters.xml file
                  if ($time == $curExp && $rate == $curRate)
                  {
                     echo "<option value=\"$time,$rate\" selected=\"selected\">$display</option>\n";
                     $key = getXmlField($entry, "key");                  
                     $value = getXmlField($entry, "value");                  
                     SetXmlValue($profile, "parameters.xml", $key, $value);
                  }
                  else if ($time)
                     echo "<option value=\"$time,$rate\">$display</option>\n";
               }
               $y++;
            }
            $x++;
            echo "</select></p>\n";
            echo "</div>\n";
         }
      }
   }
}

function getXmlField($data, $tag)
{
   $stag = "<".$tag.">";
   $etag = "</".$tag.">";
   $i = strpos($data, $stag);
   $j = strpos($data, "$etag");
   if (($i >= 0) && ($j > $i))
   {
      $i = $i + strlen($tag) + 2;
      $value = substr($data, $i, $j-$i);
      return $value;
   }
   return false;
}

function getXmlFieldEx($data, $tag, $index)
{
   $stag = "<".$tag.">";
   $etag = "</".$tag.">";

   for ($x = 1; $x < $index; $x++)
   {
      $idx = strpos($data, $stag);
      if ($idx == false)
         return false;
      
      $data = substr($data, $idx + 1);
   }

   $i = strpos($data, "$stag");
   $j = strpos($data, "$etag", $i);
   if ($i && ($i >= 0) && $j && ($j > $i))
   {
      $i = $i + strlen($tag) + 2;
      $value = substr($data, $i, $j-$i);
      return $value;
   }
   return false;
}

function SetXmlValue($profile, $fileName, $key, $value)
// ===========================================================================
{
   $returnValue = 1;
   $path = getenv("PROFILE_HOME");
   if (!$path)
      $returnValue = -3;

   $filename = sprintf("%s\\%s\\%s", $path, $profile, $fileName);
   $handle = fopen($filename, 'r');
   if ($handle)
   {
      $message = fread($handle, 20000);
      fclose($handle);

      //find the frame rate
      $key = "\"$key\"";
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $buf1 = substr($message, 0, $startInt);
         $buf2 = $value;
         $endInt = strpos($message, "\"", $startInt);
         $buf3 = substr($message, $endInt);
         
         $handle = fopen($filename, 'w');
         $newFile = sprintf("%s%s%s", $buf1, $buf2, $buf3);
         if ($handle)
         {
            fwrite($handle, $newFile);
            fclose($handle);
         }
         else
            $returnValue = -4;
      }
      else
         $returnValue = -2;
   }
   else
      $returnValue = -1;

   return $returnValue;
}

/*	===========================================================================
*  This method opens an XML file. 
*  It then reads the file to find current value for the indicated key and returns it.
*  @param $filename - this is the name of the XML file to view.
*  @param $key - this is the key used to search for the value.
*  @return -   the value requested on success,
*              on error:
*                 -1 if the file could not be opened.
*                 -2 if the key could not be found.
*                 -3 if PROFILE_HOME is not set.
*/
function GetXmlValueFile($filename, $key)
//	===========================================================================
{
    $key = "\"$key\"";

   if (!$filename)
      return -3;
      
   $handle = fopen($filename, 'r');
   if ($handle)
   {
   
      $message = fread($handle, 20000);
      
      //find the frame rate
      $startInt = strpos($message, $key);
      if ($startInt)
      {
         $startInt = strpos($message, 'value=', $startInt);
         $startInt = $startInt + 7;
         $endInt = strpos($message, "\"", $startInt);
         $len = $endInt - $startInt;
         $value = substr($message, $startInt, $len);
      }
      else
         $value = -2;
   }
   else
      $value = -1;
   
   fclose($handle);

	return $value;
}

?>